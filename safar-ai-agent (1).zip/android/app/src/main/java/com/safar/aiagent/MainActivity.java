package com.safar.aiagent;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
