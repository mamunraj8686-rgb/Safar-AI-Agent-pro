import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '35mb' }));

// Security headers for API requests
app.use((_req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  next();
});

// Health check endpoint (does not require or leak API key)
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    service: 'Safar AI Agent API',
    hasApiKey: Boolean(process.env.GEMINI_API_KEY),
    timestamp: Date.now(),
  });
});

// API security middleware: Verify Gemini API key is configured before dispatching to LLM
app.use('/api', (req: Request, res: Response, next) => {
  if (req.path === '/health') return next();
  if (!process.env.GEMINI_API_KEY) {
    return res.status(503).json({
      error: 'GEMINI_API_KEY is not configured on the server. Please ensure the API key is attached in your environment or Secrets.',
    });
  }
  next();
});

// Shared Gemini SDK client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
    timeout: 30000,
  },
});

// Chat endpoint
app.post('/api/chat', async (req: Request, res: Response) => {
  try {
    const { messages, agentId, systemPrompt, modelOverride } = req.body;

    if (!messages || !Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: 'Messages array is required and must contain at least one message' });
    }

    const model = modelOverride || 'gemini-3.8-flash';

    const multilingualSystemDirective = `You are Safar AI Agent, a premier, highly capable autonomous companion designed for mobile & Android ergonomics. "Safar" signifies journey, exploration, knowledge, and thoughtful progress.

CRITICAL MULTILINGUAL MANDATE:
Always detect the language of the user's message and reply in that EXACT same language with native fluency, cultural nuance, and natural grammar:
- If the user writes in Bengali (বাংলা, e.g. "কেমন আছো?", "আমাকে একটি ৩ দিনের ভ্রমণ পরিকল্পনা দিন"), respond fluently in Bengali script (বাংলা ভাষা).
- If the user writes in Arabic (العربية, e.g. "مرحباً، كيف يمكنك مساعدتي؟", "خطط لي رحلة إلى إسبانيا"), respond fluently in Arabic.
- If the user writes in English, respond in English.
- If the user writes in any other language, respond in that language.
- If the user asks in one language to translate or answer in another language, honor their requested language.

Style & Formatting:
- Provide structured, elegant responses with clean section headers, bullet lists, and code blocks where applicable.
- Avoid mechanical prefix clutter or robotic filler.
- Prioritize depth, precision, clarity, and empathy.`;

    const effectiveSystemPrompt = systemPrompt 
      ? `${systemPrompt}\n\n${multilingualSystemDirective}`
      : multilingualSystemDirective;

    const contents = messages.map((m: { role: string; content: string }) => ({
      role: m.role === 'user' ? 'user' : 'model',
      parts: [{ text: m.content }],
    }));

    let response;
    let usedModel = model;

    try {
      response = await ai.models.generateContent({
        model: usedModel,
        contents,
        config: {
          systemInstruction: effectiveSystemPrompt,
          temperature: 0.7,
        },
      });
    } catch (primaryErr: any) {
      console.warn(`Primary model ${usedModel} failed, trying fallback model...`, primaryErr?.message);
      // Fallback model for high demand / temporary availability
      const fallbackModel = usedModel === 'gemini-3.8-flash' ? 'gemini-3.1-flash-lite' : 'gemini-3.8-flash';
      usedModel = fallbackModel;
      response = await ai.models.generateContent({
        model: usedModel,
        contents,
        config: {
          systemInstruction: effectiveSystemPrompt,
          temperature: 0.7,
        },
      });
    }

    const reply = response.text || 'I apologize, I could not generate a response. Please try again.';

    res.json({
      text: reply,
      agentId: agentId || 'general',
      model: usedModel,
    });
  } catch (error: any) {
    console.error('Chat API Error:', error);
    let errorDetail = error?.message || 'Failed to process chat message with Safar AI.';
    try {
      const parsed = JSON.parse(errorDetail);
      if (parsed?.error?.message) {
        errorDetail = parsed.error.message;
      }
    } catch {
      // already plain text
    }

    res.status(500).json({
      error: errorDetail,
    });
  }
});

// Image Generation Endpoint (supports 1K, 2K, 4K and nano-banana / gemini-3-pro-image)
app.post('/api/image/generate', async (req: Request, res: Response) => {
  try {
    const { prompt, aspectRatio = '1:1', imageSize = '1K', model = 'gemini-nano-banana-2.1', style = 'cinematic' } = req.body;

    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    // Enhance prompt with style aesthetic if specified
    let enhancedPrompt = prompt;
    if (style && style !== 'none') {
      enhancedPrompt = `${prompt}, styled as ${style}, premium high resolution, masterful lighting, refined textures`;
    }

    // High quality models support 1K, 2K, 4K
    const validSizes = ['1K', '2K', '4K'];
    const chosenSize = validSizes.includes(imageSize) ? imageSize : '1K';
    const chosenAspect = ['1:1', '3:4', '4:3', '9:16', '16:9'].includes(aspectRatio) ? aspectRatio : '1:1';

    let selectedModel = model;
    if (selectedModel === 'gemini-3-pro-image-preview') {
      selectedModel = 'gemini-3-pro-image';
    }

    try {
      const response = await ai.models.generateContent({
        model: selectedModel,
        contents: {
          parts: [{ text: enhancedPrompt }],
        },
        config: {
          imageConfig: {
            aspectRatio: chosenAspect,
            imageSize: chosenSize,
          },
        },
      });

      let imageUrl = '';
      let textNotice = '';

      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData?.data) {
            const mime = part.inlineData.mimeType || 'image/png';
            imageUrl = `data:${mime};base64,${part.inlineData.data}`;
            break;
          } else if (part.text) {
            textNotice += part.text;
          }
        }
      }

      if (!imageUrl) {
        throw new Error(textNotice || 'Model did not return image data');
      }

      res.json({
        imageUrl,
        prompt: enhancedPrompt,
        aspectRatio: chosenAspect,
        imageSize: chosenSize,
        model: selectedModel,
      });
    } catch (modelErr: any) {
      console.warn('Primary image generation failed, trying flash-lite fallback:', modelErr?.message);
      // Fallback to flash-lite image generator
      const fallbackResponse = await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite-image',
        contents: {
          parts: [{ text: enhancedPrompt }],
        },
        config: {
          imageConfig: {
            aspectRatio: chosenAspect,
          },
        },
      });

      let fallbackUrl = '';
      if (fallbackResponse.candidates?.[0]?.content?.parts) {
        for (const part of fallbackResponse.candidates[0].content.parts) {
          if (part.inlineData?.data) {
            const mime = part.inlineData.mimeType || 'image/png';
            fallbackUrl = `data:${mime};base64,${part.inlineData.data}`;
            break;
          }
        }
      }

      if (!fallbackUrl) {
        throw modelErr;
      }

      res.json({
        imageUrl: fallbackUrl,
        prompt: enhancedPrompt,
        aspectRatio: chosenAspect,
        imageSize: chosenSize,
        model: 'gemini-3.1-flash-lite-image',
        fallback: true,
      });
    }
  } catch (error: any) {
    console.error('Image Generation Error:', error);
    res.status(500).json({
      error: error?.message || 'Failed to generate image',
    });
  }
});

// Image Edit Endpoint (uses input image + edit prompt)
app.post('/api/image/edit', async (req: Request, res: Response) => {
  try {
    const { base64Image, mimeType = 'image/png', prompt, model = 'gemini-nano-banana-2.1' } = req.body;

    if (!base64Image || !prompt) {
      return res.status(400).json({ error: 'Base64 image and edit prompt are required' });
    }

    // Clean base64 string if it contains data prefix
    const cleanBase64 = base64Image.replace(/^data:image\/[a-zA-Z0-9+]+;base64,/, '');

    const targetModel = model === 'gemini-3-pro-image-preview' ? 'gemini-3-pro-image' : (model || 'gemini-nano-banana-2.1');

    try {
      const response = await ai.models.generateContent({
        model: targetModel,
        contents: {
          parts: [
            {
              inlineData: {
                data: cleanBase64,
                mimeType,
              },
            },
            {
              text: `Modify this image according to these specific instructions: ${prompt}`,
            },
          ],
        },
      });

      let imageUrl = '';
      if (response.candidates?.[0]?.content?.parts) {
        for (const part of response.candidates[0].content.parts) {
          if (part.inlineData?.data) {
            const partMime = part.inlineData.mimeType || 'image/png';
            imageUrl = `data:${partMime};base64,${part.inlineData.data}`;
            break;
          }
        }
      }

      if (!imageUrl) {
        throw new Error('No edited image was returned');
      }

      res.json({
        imageUrl,
        prompt,
        model: targetModel,
      });
    } catch (editErr: any) {
      console.warn('Primary edit model failed, attempting flash-lite fallback:', editErr?.message);
      const fallback = await ai.models.generateContent({
        model: 'gemini-3.1-flash-lite-image',
        contents: {
          parts: [
            {
              inlineData: {
                data: cleanBase64,
                mimeType,
              },
            },
            {
              text: prompt,
            },
          ],
        },
      });

      let fallbackUrl = '';
      if (fallback.candidates?.[0]?.content?.parts) {
        for (const part of fallback.candidates[0].content.parts) {
          if (part.inlineData?.data) {
            const partMime = part.inlineData.mimeType || 'image/png';
            fallbackUrl = `data:${partMime};base64,${part.inlineData.data}`;
            break;
          }
        }
      }

      if (!fallbackUrl) {
        throw editErr;
      }

      res.json({
        imageUrl: fallbackUrl,
        prompt,
        model: 'gemini-3.1-flash-lite-image',
        fallback: true,
      });
    }
  } catch (error: any) {
    console.error('Image Edit Error:', error);
    res.status(500).json({
      error: error?.message || 'Failed to edit image',
    });
  }
});

// Live Voice Assistant Query Endpoint
app.post('/api/voice/interact', async (req: Request, res: Response) => {
  try {
    const { transcript, agentId, history } = req.body;

    if (!transcript) {
      return res.status(400).json({ error: 'Transcript is required' });
    }

    const voicePrompt = `You are Safar Voice Agent, an intelligent audio companion speaking in real time.
Voice Instructions:
- Answer directly, punchy, conversational, and concise (1 to 3 short sentences max).
- CRITICAL MULTILINGUAL MANDATE: Detect the language spoken by the user and reply in that EXACT same language:
  * If the user spoke in Bengali (বাংলা), respond in spoken Bengali.
  * If the user spoke in Arabic (العربية), respond in spoken Arabic.
  * If the user spoke in English, respond in spoken English.
- STRICT AUDIO FORMAT: Do NOT use markdown symbols, bullet points, asterisks (*), hashtags (#), brackets, or URLs, because this text will be fed directly to speech synthesis.

User said: "${transcript}"`;

    let response;
    let usedModel = 'gemini-3.8-flash';

    try {
      response = await ai.models.generateContent({
        model: usedModel,
        contents: voicePrompt,
        config: {
          temperature: 0.7,
        },
      });
    } catch (primaryErr: any) {
      console.warn('Voice primary model failed, using fallback:', primaryErr?.message);
      usedModel = 'gemini-3.1-flash-lite';
      response = await ai.models.generateContent({
        model: usedModel,
        contents: voicePrompt,
        config: {
          temperature: 0.7,
        },
      });
    }

    const cleanSpokenText = (response.text || "I am with you. How can I assist your journey?")
      .replace(/[*#`_\[\]]/g, '')
      .replace(/\n+/g, ' ')
      .trim();

    res.json({
      spokenText: cleanSpokenText,
      agentId: agentId || 'voice',
      model: usedModel,
    });
  } catch (error: any) {
    console.error('Voice Interact Error:', error);
    res.status(500).json({
      error: error?.message || 'Voice generation failed. Please try again.',
    });
  }
});

// ==========================================
// SMART AGENT HUB TOOL ENDPOINTS (8 TOOLS)
// ==========================================

// Shared resilient generation helper with automatic fallback for high-demand spikes
async function generateContentWithFallback(payload: { contents: any; config?: any }, preferredModel = 'gemini-3.8-flash') {
  try {
    return await ai.models.generateContent({
      model: preferredModel,
      contents: payload.contents,
      config: payload.config,
    });
  } catch (err: any) {
    console.warn(`Model ${preferredModel} encountered issue, trying fallback:`, err?.message);
    const fallbackModel = preferredModel === 'gemini-3.8-flash' ? 'gemini-3.1-flash-lite' : 'gemini-3.8-flash';
    return await ai.models.generateContent({
      model: fallbackModel,
      contents: payload.contents,
      config: payload.config,
    });
  }
}

// 1. AI Writer
app.post('/api/tools/writer', async (req: Request, res: Response) => {
  try {
    const { prompt, format = 'article', tone = 'professional', length = 'medium', language = 'en' } = req.body;
    if (!prompt) return res.status(400).json({ error: 'Writing prompt is required' });

    const systemInstruction = `You are Safar AI Writer, a master craftsman of words.
Generate high quality ${format} in a ${tone} tone and ${length} length.
MULTILINGUAL MANDATE:
- If target language is 'bn' or prompt is in Bengali, write entirely in elegant, natural Bengali (বাংলা).
- If target language is 'ar' or prompt is in Arabic, write entirely in eloquent Arabic (العربية).
- If target language is 'en', write in polished English.
Format with clean titles, subheadings, and cohesive paragraphs.`;

    const response = await generateContentWithFallback({
      contents: prompt,
      config: { systemInstruction, temperature: 0.75 },
    });

    res.json({ result: response.text || 'Unable to generate content.' });
  } catch (error: any) {
    console.error('AI Writer Error:', error);
    res.status(500).json({ error: error?.message || 'Writing generation failed' });
  }
});

// 2. Translator
app.post('/api/tools/translate', async (req: Request, res: Response) => {
  try {
    const { text, fromLang = 'auto', toLang = 'bn', tone = 'natural' } = req.body;
    if (!text) return res.status(400).json({ error: 'Text to translate is required' });

    const systemInstruction = `You are Safar Neural Translator.
Translate the text faithfully from ${fromLang} to ${toLang}.
Tone requested: ${tone}.
Maintain cultural idiom and context.
OUTPUT FORMAT:
Provide the translation directly. Then, if helpful, add a short section 'Notes & Pronunciation' highlighting key vocabulary or transliteration if translating to or from Bengali or Arabic.`;

    const response = await generateContentWithFallback({
      contents: text,
      config: { systemInstruction, temperature: 0.3 },
    });

    res.json({ translation: response.text || '' });
  } catch (error: any) {
    console.error('Translator Error:', error);
    res.status(500).json({ error: error?.message || 'Translation failed' });
  }
});

// 3. Summarizer
app.post('/api/tools/summarize', async (req: Request, res: Response) => {
  try {
    const { content, format = 'bullets', length = 'medium', language = 'auto' } = req.body;
    if (!content) return res.status(400).json({ error: 'Content to summarize is required' });

    const systemInstruction = `You are Safar Executive Summarizer.
Condense the provided text into ${format} format (${length} length).
Highlight core takeaways, actionable items, and critical facts.
MULTILINGUAL: If the input text is in Bengali or Arabic, or requested, output the summary in that same language.`;

    const response = await generateContentWithFallback({
      contents: content,
      config: { systemInstruction, temperature: 0.4 },
    });

    res.json({ summary: response.text || '' });
  } catch (error: any) {
    console.error('Summarizer Error:', error);
    res.status(500).json({ error: error?.message || 'Summarization failed' });
  }
});

// 4. Calculator & Mathematical Problem Solver
app.post('/api/tools/calculate', async (req: Request, res: Response) => {
  try {
    const { query, language = 'en' } = req.body;
    if (!query) return res.status(400).json({ error: 'Mathematical query or formula is required' });

    const systemInstruction = `You are Safar Computational Engine.
Evaluate the mathematical query, equation, or word problem.
Return:
1. FINAL ANSWER (clearly highlighted in bold at top)
2. STEP-BY-STEP SOLUTION with formulas used
3. VERIFICATION / ALTERNATIVE METHOD
Explain in ${language === 'bn' ? 'Bengali' : language === 'ar' ? 'Arabic' : 'English'}.`;

    const response = await generateContentWithFallback({
      contents: query,
      config: { systemInstruction, temperature: 0.1 },
    });

    res.json({ solution: response.text || '' });
  } catch (error: any) {
    console.error('Calculator Error:', error);
    res.status(500).json({ error: error?.message || 'Calculation failed' });
  }
});

// 5. Research Assistant
app.post('/api/tools/research', async (req: Request, res: Response) => {
  try {
    const { topic, depth = 'comprehensive', language = 'en' } = req.body;
    if (!topic) return res.status(400).json({ error: 'Research topic is required' });

    const systemInstruction = `You are Safar Lead Research Scout.
Provide an evidence-based, deep analytical briefing on "${topic}" with ${depth} depth.
Include:
- Executive Overview
- Historical / Technical Foundations
- Current State of the Art & Key Debates
- Real-World Case Studies or Empirical Evidence
- Future Horizon & Strategic Takeaways
Respond in ${language === 'bn' ? 'Bengali (বাংলা)' : language === 'ar' ? 'Arabic (العربية)' : 'English'}.`;

    const response = await generateContentWithFallback({
      contents: topic,
      config: { systemInstruction, temperature: 0.5 },
    });

    res.json({ report: response.text || '' });
  } catch (error: any) {
    console.error('Research Error:', error);
    res.status(500).json({ error: error?.message || 'Research failed' });
  }
});

// 6. PDF and File Assistant
app.post('/api/tools/document', async (req: Request, res: Response) => {
  try {
    const { fileData, fileType = 'text/plain', fileName = 'document', question = 'Summarize and extract key insights from this document.', language = 'en' } = req.body;

    if (!fileData) return res.status(400).json({ error: 'File content is required' });

    let contentsPayload: any;

    if (fileType.includes('pdf')) {
      const cleanBase64 = fileData.replace(/^data:application\/pdf;base64,/, '');
      contentsPayload = {
        parts: [
          {
            inlineData: {
              data: cleanBase64,
              mimeType: 'application/pdf',
            },
          },
          {
            text: `Analyze this document (${fileName}) and answer: ${question}. Respond in ${language === 'bn' ? 'Bengali' : language === 'ar' ? 'Arabic' : 'English'}.`,
          },
        ],
      };
    } else {
      contentsPayload = `Document content (${fileName}):\n${fileData}\n\nUser Question: ${question}\nRespond in ${language === 'bn' ? 'Bengali' : language === 'ar' ? 'Arabic' : 'English'}.`;
    }

    const response = await generateContentWithFallback({
      contents: contentsPayload,
      config: {
        systemInstruction: 'You are Safar Document Intelligence. Provide accurate answers grounded strictly in the provided document, citing page numbers or sections where available.',
        temperature: 0.3,
      },
    });

    res.json({ answer: response.text || 'Unable to parse document.' });
  } catch (error: any) {
    console.error('Document Assistant Error:', error);
    res.status(500).json({ error: error?.message || 'Document analysis failed' });
  }
});

// 7. Image Understanding (Vision)
app.post('/api/tools/vision', async (req: Request, res: Response) => {
  try {
    const { imageBase64, mimeType = 'image/jpeg', prompt = 'What is in this image? Provide detailed breakdown.', mode = 'analyze', language = 'en' } = req.body;

    if (!imageBase64) return res.status(400).json({ error: 'Image data is required' });

    const cleanBase64 = imageBase64.replace(/^data:image\/[a-zA-Z0-9+]+;base64,/, '');
    const promptWithLang = `${prompt}\nRespond in ${language === 'bn' ? 'Bengali' : language === 'ar' ? 'Arabic' : 'English'}.`;

    const response = await generateContentWithFallback({
      contents: {
        parts: [
          {
            inlineData: {
              data: cleanBase64,
              mimeType,
            },
          },
          {
            text: promptWithLang,
          },
        ],
      },
      config: {
        systemInstruction: 'You are Safar Vision Analyst. Inspect image optics, identify objects, transcribe text precisely (OCR), detect patterns, and answer visual queries comprehensively.',
        temperature: 0.4,
      },
    });

    res.json({ analysis: response.text || 'No visual analysis generated.' });
  } catch (error: any) {
    console.error('Vision Error:', error);
    res.status(500).json({ error: error?.message || 'Visual analysis failed' });
  }
});

// 8. QR and Barcode Scanner Analyzer
app.post('/api/tools/scanner-analyze', async (req: Request, res: Response) => {
  try {
    const { codeContent, format = 'QR_CODE', question, language = 'en' } = req.body;
    if (!codeContent) return res.status(400).json({ error: 'Code content is required' });

    const systemInstruction = `You are Safar Code & Optical Scanner Intelligence.
Analyze the scanned ${format} payload: "${codeContent}".
1. Identify payload type (URL, WiFi, Contact vCard, Product UPC/EAN, Plain Text, Crypto, Geo).
2. If URL: Assess safety and intent.
3. If Product Barcode: Identify common product category, manufacturer or standard lookup details.
4. Provide immediate actionable recommendations.
Respond in ${language === 'bn' ? 'Bengali' : language === 'ar' ? 'Arabic' : 'English'}.`;

    const userQuery = question ? `${question}\nScanned payload: ${codeContent}` : `Analyze scanned payload: ${codeContent}`;

    const response = await generateContentWithFallback({
      contents: userQuery,
      config: { systemInstruction, temperature: 0.3 },
    });

    res.json({ analysis: response.text || '' });
  } catch (error: any) {
    console.error('Scanner Analysis Error:', error);
    res.status(500).json({ error: error?.message || 'Scanner analysis failed' });
  }
});

// ==========================================
// 5-AGENT TEAM COLLABORATIVE PIPELINE
// ==========================================
app.post('/api/agent-team/execute-step', async (req: Request, res: Response) => {
  try {
    const { role, objective, language = 'en', previousOutputs = {} } = req.body;

    if (!objective) {
      return res.status(400).json({ error: 'User objective is required' });
    }

    const langInstruction = language === 'bn' 
      ? 'CRITICAL: Output entirely in fluent, natural Bengali (বাংলা).' 
      : language === 'ar' 
      ? 'CRITICAL: Output entirely in eloquent, natural Arabic (العربية).' 
      : 'Output in clear, polished English.';

    let systemInstruction = '';
    let promptContent = '';

    switch (role) {
      case 'coordinator_plan':
        systemInstruction = `You are the Coordinator Agent leading the Safar 5-Agent Swarm.
Your responsibility:
1. Deconstruct the user objective into essential execution phases.
2. Formulate specific directives for the Research Agent, Planning Agent, Writing Agent, and Review Agent.
3. Establish key success criteria.
${langInstruction}`;
        promptContent = `User Objective: "${objective}"\n\nOutline the task distribution and mandate for our team.`;
        break;

      case 'research':
        systemInstruction = `You are the Research Agent of the Safar Agent Team.
Your responsibility:
1. Identify core empirical facts, domain principles, real-world context, and technical or practical constraints.
2. Surface critical insights, trade-offs, and data points that the Planning and Writing agents will need.
${langInstruction}`;
        promptContent = `Objective: "${objective}"
Coordinator Directives:
${previousOutputs.coordinator_plan || 'Comprehensive domain investigation'}

Provide structured, high-signal research findings.`;
        break;

      case 'planning':
        systemInstruction = `You are the Planning Agent of the Safar Agent Team.
Your responsibility:
1. Synthesize the objective and the Research Agent's findings into a concrete structural architecture.
2. Outline section-by-section requirements, narrative pacing, and technical flow for the Writing Agent.
${langInstruction}`;
        promptContent = `Objective: "${objective}"
Research Agent Findings:
${previousOutputs.research || 'Standard domain principles'}

Formulate the definitive blueprint and section architecture.`;
        break;

      case 'writing':
        systemInstruction = `You are the Writing Agent of the Safar Agent Team.
Your responsibility:
1. Draft the complete, articulate, high-value solution or document adhering strictly to the Planning Agent's blueprint.
2. Integrate the factual depth provided by the Research Agent.
${langInstruction}`;
        promptContent = `Objective: "${objective}"
Structural Plan:
${previousOutputs.planning || 'Structured outline'}

Research Foundation:
${previousOutputs.research || 'Factual data'}

Draft the comprehensive deliverable in full.`;
        break;

      case 'review':
        systemInstruction = `You are the Review Agent of the Safar Agent Team.
Your responsibility:
1. Rigorously critique the Writing Agent's draft for accuracy, clarity, completeness, and tone.
2. Correct omissions, eliminate fluff, and propose polished refinements.
${langInstruction}`;
        promptContent = `Objective: "${objective}"
Draft under Review:
${previousOutputs.writing || 'Initial draft'}

Provide an editorial critique followed by polished improvements.`;
        break;

      case 'coordinator_finalize':
        systemInstruction = `You are the Coordinator Agent delivering the executive final deliverable of the Safar 5-Agent Swarm.
Your responsibility:
1. Conduct final executive sign-off incorporating the Review Agent's refinements and the team's combined efforts.
2. Present ONE definitive, beautifully structured, final answer to the user.
${langInstruction}`;
        promptContent = `User Objective: "${objective}"
Writing Draft & Critique:
${previousOutputs.review || previousOutputs.writing || 'Complete solution'}

Deliver the final, unified executive answer.`;
        break;

      default:
        return res.status(400).json({ error: `Unknown team role: ${role}` });
    }

    const response = await generateContentWithFallback({
      contents: promptContent,
      config: {
        systemInstruction,
        temperature: role === 'writing' ? 0.7 : 0.4,
      },
    });

    res.json({
      role,
      output: response.text || 'Step completed.',
    });
  } catch (error: any) {
    console.error('Agent Team Step Error:', error);
    res.status(500).json({
      error: error?.message || 'Agent team step execution failed',
    });
  }
});

// ==========================================
// SAFAR FLOW AUTOMATION PIPELINE
// 1. Write content
// 2. Translate it
// 3. Summarize it
// 4. Review the result
// ==========================================
app.post('/api/flow/execute-step', async (req: Request, res: Response) => {
  try {
    const { 
      step, 
      workflowType = 'custom', 
      inputTopic = '', 
      stepInputs = {}, 
      previousOutputs = {},
      language = 'en'
    } = req.body;

    if (!step) {
      return res.status(400).json({ error: 'Workflow step is required' });
    }

    const langDirective = (langCode: string) => {
      if (langCode === 'bn') return 'CRITICAL: Output entirely in fluent, natural Bengali (বাংলা).';
      if (langCode === 'ar') return 'CRITICAL: Output entirely in eloquent, modern standard Arabic (العربية).';
      if (langCode === 'es') return 'CRITICAL: Output in clear, fluent Spanish (Español).';
      if (langCode === 'fr') return 'CRITICAL: Output in refined, natural French (Français).';
      if (langCode === 'de') return 'CRITICAL: Output in precise German (Deutsch).';
      if (langCode === 'ur') return 'CRITICAL: Output in eloquent Urdu (اردو).';
      return 'CRITICAL: Output in clear, professional English.';
    };

    let systemInstruction = '';
    let promptContent = '';
    let temperature = 0.5;

    switch (step) {
      case 'write': {
        const tone = stepInputs.tone || 'professional';
        const targetLang = stepInputs.writeLanguage || language || 'en';
        temperature = 0.7;

        if (workflowType === 'business_writing') {
          systemInstruction = `You are Safar Flow Automation Engine specialized in Executive Business Writing.
Craft a comprehensive, polished business proposal, corporate memo, or executive briefing based on the user topic.
Structure with:
1. Executive Summary
2. Strategic Objectives & Scope
3. Core Proposal / Solution
4. Expected Outcomes & Milestones
5. Recommendation & Next Steps
Maintain an authoritative, clear corporate tone.
${langDirective(targetLang)}`;
          promptContent = `Business Topic / Request: "${inputTopic || stepInputs.topic || 'Strategic business initiative'}"
Tone: ${tone}
Instructions: ${stepInputs.customInstructions || 'Create an executive-grade proposal with complete actionable detail.'}`;
        } else if (workflowType === 'social_media') {
          systemInstruction = `You are Safar Flow Automation Engine specialized in Social Media Campaigns & Viral Copywriting.
Craft a high-engagement, multi-format social campaign post based on the user topic.
Include:
1. Attention Hook (1-2 lines)
2. Core Story / Key Insights with readability spacing & emoji accents
3. Bulleted Highlights or Key Takeaways
4. Clear Call to Action (CTA)
5. Optimized Hashtag Cluster for LinkedIn & X (Twitter)
${langDirective(targetLang)}`;
          promptContent = `Campaign Subject: "${inputTopic || stepInputs.topic || 'Product launch'}"
Tone: ${tone}
Instructions: ${stepInputs.customInstructions || 'Create engaging, conversion-optimized copy with strong hooks.'}`;
        } else if (workflowType === 'document_translation') {
          systemInstruction = `You are Safar Flow Automation Engine specialized in Structured Document Authoring.
Generate a structured, formal document (agreement, brief, policy, or official notice) based on the topic, prepared specifically with clean section headers and terminology for subsequent translation.
${langDirective(targetLang)}`;
          promptContent = `Document Subject: "${inputTopic || stepInputs.topic || 'Official document'}"
Tone: ${tone}
Instructions: ${stepInputs.customInstructions || 'Draft complete, structured documentation with clear numbered clauses.'}`;
        } else if (workflowType === 'study_notes') {
          systemInstruction = `You are Safar Flow Automation Engine specialized in Academic Pedagogy and Study Digests.
Create a structured study guide and master notes on the requested subject.
Include:
1. Core Conceptual Definitions & Overview
2. Deep-Dive Section Breakdown with real-world examples & analogies
3. High-Yield Exam Takeaways & Key Formulas/Facts
4. Common Pitfalls & Clarifications
${langDirective(targetLang)}`;
          promptContent = `Academic Subject / Topic: "${inputTopic || stepInputs.topic || 'Advanced topic'}"
Tone: Educational, explanatory, structured
Instructions: ${stepInputs.customInstructions || 'Create exhaustive, intuitive study notes for high retention.'}`;
        } else {
          // Custom workflow
          systemInstruction = `You are Safar Flow Automation Engine for Content Creation.
Generate comprehensive, high-quality, well-structured content based on the user's prompt.
${langDirective(targetLang)}`;
          promptContent = `Topic / Request: "${inputTopic || stepInputs.topic || 'Custom content task'}"
Tone: ${tone}
Instructions: ${stepInputs.customInstructions || 'Draft a high-quality written piece meeting the specified requirements.'}`;
        }
        break;
      }

      case 'translate': {
        const sourceLang = stepInputs.sourceLanguage || 'auto';
        const targetLang = stepInputs.targetLanguage || (language === 'bn' ? 'bn' : language === 'ar' ? 'ar' : 'bn');
        const contentToTranslate = stepInputs.content || previousOutputs.write || inputTopic;

        if (!contentToTranslate || !contentToTranslate.trim()) {
          return res.status(400).json({ error: 'No content provided to translate' });
        }

        temperature = 0.3;
        systemInstruction = `You are Safar Flow Automation Neural Translator.
Your task is to provide an accurate, high-fidelity translation of the source text.
Rules:
1. Preserve all markdown structure, headings, bold emphasis, and bullet lists.
2. Maintain domain-specific terminology accurately (business, legal, technical, medical).
3. Ensure natural phrasing and cultural resonance, avoiding awkward word-for-word transliteration.
4. Translate the content faithfully into the requested target language.
${langDirective(targetLang)}`;

        promptContent = `Source Language: ${sourceLang}
Target Language: ${targetLang}

Text to Translate:
"""
${contentToTranslate}
"""`;
        break;
      }

      case 'summarize': {
        const targetLang = stepInputs.summaryLanguage || language || 'en';
        const contentToSummarize = stepInputs.content || previousOutputs.translate || previousOutputs.write || inputTopic;
        const format = stepInputs.format || 'executive_brief';

        if (!contentToSummarize || !contentToSummarize.trim()) {
          return res.status(400).json({ error: 'No content provided to summarize' });
        }

        temperature = 0.4;
        systemInstruction = `You are Safar Flow Automation Executive Summarizer.
Condense the input content into a clear, high-signal summary.
Structure:
1. Executive Snapshot (1-2 sentences capturing the essence)
2. Core Takeaways (3-5 concise, impactful bullet points)
3. Actionable Insights or Next Steps
Format: ${format}
${langDirective(targetLang)}`;

        promptContent = `Content to Summarize:
"""
${contentToSummarize}
"""`;
        break;
      }

      case 'review': {
        const targetLang = stepInputs.reviewLanguage || language || 'en';
        const contentToReview = stepInputs.content || previousOutputs.summarize || previousOutputs.translate || previousOutputs.write || inputTopic;

        if (!contentToReview || !contentToReview.trim()) {
          return res.status(400).json({ error: 'No content provided to review' });
        }

        temperature = 0.4;
        systemInstruction = `You are Safar Flow Automation Chief Editorial & Quality Reviewer.
Your role:
1. Perform a thorough quality evaluation across Clarity, Precision, Tone, Linguistic Fidelity, and Completeness.
2. Provide a brief "Quality Scorecard & Editorial Polish Notes".
3. Provide the definitive, polished "Final Master Output" ready for immediate export and distribution.
${langDirective(targetLang)}`;

        promptContent = `Workflow Objective: "${inputTopic || 'General content workflow'}"
Workflow Type: ${workflowType}

Content for Final Review:
"""
${contentToReview}
"""

Context / Previous Steps:
- Original Written Content Available: ${previousOutputs.write ? 'Yes' : 'No'}
- Translation Available: ${previousOutputs.translate ? 'Yes' : 'No'}
- Summary Available: ${previousOutputs.summarize ? 'Yes' : 'No'}

Perform the editorial review and deliver the polished final master version.`;
        break;
      }

      default:
        return res.status(400).json({ error: `Unknown flow step: ${step}` });
    }

    const response = await generateContentWithFallback({
      contents: promptContent,
      config: {
        systemInstruction,
        temperature,
      },
    });

    res.json({
      step,
      output: response.text || 'Step completed successfully.',
    });
  } catch (error: any) {
    console.error('Flow Automation Step Error:', error);
    res.status(500).json({
      error: error?.message || 'Flow automation step execution failed',
    });
  }
});

async function main() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Safar AI Agent Server running on http://0.0.0.0:${PORT}`);
  });
}

main().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
