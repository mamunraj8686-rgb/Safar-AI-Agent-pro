export type NavigationTab = 'home' | 'chat' | 'voice' | 'agents' | 'flow' | 'images' | 'history' | 'settings';

export type FlowStepType = 'write' | 'translate' | 'summarize' | 'review' | 'export';
export type FlowStepStatus = 'idle' | 'running' | 'completed' | 'error' | 'edited';
export type WorkflowPresetId = 'business_writing' | 'social_media' | 'document_translation' | 'study_notes' | 'custom';

export interface FlowStepData {
  id: FlowStepType;
  title: string;
  subtitle: string;
  description: string;
  status: FlowStepStatus;
  output: string;
  error?: string | null;
  edited?: boolean;
}

export interface WorkflowPreset {
  id: WorkflowPresetId;
  name: string;
  category: string;
  tagline: string;
  description: string;
  defaultTopic: string;
  defaultTargetLanguage: string;
  recommendedTone: string;
  examples: string[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
  agentId?: string;
  imageUrl?: string;
  imageMeta?: {
    size?: string;
    aspectRatio?: string;
    model?: string;
  };
  isError?: boolean;
}

export interface ChatSession {
  id: string;
  title: string;
  agentId: string;
  messages: ChatMessage[];
  createdAt: number;
  updatedAt: number;
  pinned?: boolean;
}

export type AppTheme = 'dark' | 'light';
export type AppLanguage = 'auto' | 'en' | 'bn' | 'ar';

export interface AppSettings {
  theme: AppTheme;
  language: AppLanguage;
  defaultAgentId: string;
  speechRate: number;
  speechPitch: number;
  autoSpeak: boolean;
  voiceLanguage: string;
  defaultResolution: '1K' | '2K' | '4K';
  haptics: boolean;
}

export interface StorageStatus {
  available: boolean;
  storageType: 'localStorage' | 'memory';
  sessionCount: number;
  historyCount: number;
  estimatedBytes: number;
  limitationMessage?: string;
}

export interface SmartAgent {
  id: string;
  name: string;
  title: string;
  description: string;
  icon: string;
  badge: string;
  systemPrompt: string;
  starterPrompts: string[];
  color: string;
}

export interface GeneratedImageItem {
  id: string;
  prompt: string;
  imageUrl: string;
  model: string;
  size: '1K' | '2K' | '4K';
  aspectRatio: string;
  timestamp: number;
  isEdit?: boolean;
}
