import { AppSettings, ChatSession, StorageStatus } from '../types';

const SETTINGS_KEY = 'safar_agent_settings_v1';
const CHAT_SESSIONS_KEY = 'safar_chat_sessions_v1';
const SAVED_ITEMS_KEY = 'safar_saved_history_items_v1';

export const DEFAULT_SETTINGS: AppSettings = {
  theme: 'dark',
  language: 'auto',
  defaultAgentId: 'safar-travel',
  speechRate: 1.0,
  speechPitch: 1.0,
  autoSpeak: false,
  voiceLanguage: 'auto',
  defaultResolution: '2K',
  haptics: true,
};

// In-memory fallback if localStorage is disabled or throws QuotaExceeded
const memoryStore: Record<string, string> = {};

let isStorageAvailableCache: boolean | null = null;
let storageErrorReason: string | undefined = undefined;

export function testStorageAvailability(): { available: boolean; reason?: string } {
  if (isStorageAvailableCache !== null) {
    return { available: isStorageAvailableCache, reason: storageErrorReason };
  }

  try {
    if (typeof window === 'undefined' || !window.localStorage) {
      isStorageAvailableCache = false;
      storageErrorReason = 'Window localStorage API not supported in current environment.';
      return { available: false, reason: storageErrorReason };
    }
    const testKey = '__safar_storage_test__';
    window.localStorage.setItem(testKey, '1');
    window.localStorage.removeItem(testKey);
    isStorageAvailableCache = true;
    return { available: true };
  } catch (err: any) {
    isStorageAvailableCache = false;
    storageErrorReason = err?.message || 'Access to localStorage was denied or restricted by browser security policies.';
    return { available: false, reason: storageErrorReason };
  }
}

function getItem(key: string): string | null {
  const { available } = testStorageAvailability();
  if (available) {
    try {
      return window.localStorage.getItem(key);
    } catch {
      return memoryStore[key] ?? null;
    }
  }
  return memoryStore[key] ?? null;
}

function setItem(key: string, value: string): boolean {
  const { available } = testStorageAvailability();
  memoryStore[key] = value;
  if (available) {
    try {
      window.localStorage.setItem(key, value);
      return true;
    } catch (err) {
      console.warn('LocalStorage write failed, using memory store fallback:', err);
      return false;
    }
  }
  return true;
}

function removeItem(key: string): void {
  delete memoryStore[key];
  const { available } = testStorageAvailability();
  if (available) {
    try {
      window.localStorage.removeItem(key);
    } catch {
      // Ignore
    }
  }
}

// ----------------- Settings API -----------------

export function loadSettings(): AppSettings {
  try {
    const raw = getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw);
    return {
      ...DEFAULT_SETTINGS,
      ...parsed,
    };
  } catch (err) {
    console.error('Failed to parse settings from storage:', err);
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: AppSettings): { success: boolean; storageType: 'localStorage' | 'memory'; error?: string } {
  const { available, reason } = testStorageAvailability();
  try {
    const serialized = JSON.stringify(settings);
    const wrote = setItem(SETTINGS_KEY, serialized);
    return {
      success: true,
      storageType: available && wrote ? 'localStorage' : 'memory',
      error: !available ? reason : undefined,
    };
  } catch (err: any) {
    return {
      success: false,
      storageType: available ? 'localStorage' : 'memory',
      error: err?.message || 'Failed to serialize and save settings.',
    };
  }
}

// ----------------- Chat Sessions API -----------------

export const INITIAL_DEFAULT_SESSION: ChatSession = {
  id: 'session-default',
  title: 'Welcome to Safar AI',
  agentId: 'safar-travel',
  createdAt: Date.now() - 3600000,
  updatedAt: Date.now() - 1800000,
  pinned: true,
  messages: [
    {
      id: 'msg-init-1',
      role: 'assistant',
      content: `Greetings! I am **Safar AI Explorer**, your intelligent multi-agent guide.

I can converse with you fluently in **English**, **বাংলা (Bengali)**, and **العربية (Arabic)**.

How may I assist your voyage today?`,
      timestamp: Date.now() - 3600000,
      agentId: 'safar-travel',
    },
  ],
};

export function loadChatSessions(): ChatSession[] {
  try {
    const raw = getItem(CHAT_SESSIONS_KEY);
    if (!raw) {
      // Seed initial default session
      return [INITIAL_DEFAULT_SESSION];
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed;
    }
    return [INITIAL_DEFAULT_SESSION];
  } catch (err) {
    console.error('Failed to parse chat sessions from storage:', err);
    return [INITIAL_DEFAULT_SESSION];
  }
}

export function saveAllChatSessions(sessions: ChatSession[]): { success: boolean; count: number } {
  try {
    const serialized = JSON.stringify(sessions);
    setItem(CHAT_SESSIONS_KEY, serialized);
    return { success: true, count: sessions.length };
  } catch (err) {
    console.error('Failed to save chat sessions to storage:', err);
    return { success: false, count: sessions.length };
  }
}

export function createNewChatSession(agentId: string = 'safar-travel', initialTitle?: string): ChatSession {
  const newSession: ChatSession = {
    id: `session-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    title: initialTitle || 'New Expedition',
    agentId,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    pinned: false,
    messages: [],
  };

  const sessions = loadChatSessions();
  const updated = [newSession, ...sessions];
  saveAllChatSessions(updated);
  return newSession;
}

export function updateChatSession(updatedSession: ChatSession): ChatSession[] {
  const sessions = loadChatSessions();
  const exists = sessions.some(s => s.id === updatedSession.id);
  let updatedList: ChatSession[];

  if (exists) {
    updatedList = sessions.map(s => s.id === updatedSession.id ? { ...updatedSession, updatedAt: Date.now() } : s);
  } else {
    updatedList = [{ ...updatedSession, updatedAt: Date.now() }, ...sessions];
  }

  saveAllChatSessions(updatedList);
  return updatedList;
}

export function renameChatSession(sessionId: string, newTitle: string): { success: boolean; sessions: ChatSession[] } {
  const trimmed = newTitle.trim();
  if (!trimmed) return { success: false, sessions: loadChatSessions() };

  const sessions = loadChatSessions();
  const updated = sessions.map(s => s.id === sessionId ? { ...s, title: trimmed, updatedAt: Date.now() } : s);
  saveAllChatSessions(updated);
  return { success: true, sessions: updated };
}

export function deleteChatSession(sessionId: string): { success: boolean; remainingCount: number; sessions: ChatSession[] } {
  const sessions = loadChatSessions();
  const updated = sessions.filter(s => s.id !== sessionId);
  saveAllChatSessions(updated);
  return { success: true, remainingCount: updated.length, sessions: updated };
}

export function togglePinChatSession(sessionId: string): ChatSession[] {
  const sessions = loadChatSessions();
  const updated = sessions.map(s => s.id === sessionId ? { ...s, pinned: !s.pinned } : s);
  saveAllChatSessions(updated);
  return updated;
}

export function clearAllChatHistory(): { success: boolean; clearedSessions: number } {
  const sessions = loadChatSessions();
  const count = sessions.length;
  removeItem(CHAT_SESSIONS_KEY);
  return { success: true, clearedSessions: count };
}

// ----------------- Saved Vault Items (Expedition / Studio / Notes) -----------------

export interface SavedVaultItem {
  id: string;
  title: string;
  type: 'voyage' | 'code' | 'task' | 'image' | 'voice' | 'chat';
  summary: string;
  timestamp: string;
  pinned?: boolean;
  sessionId?: string;
}

const DEFAULT_VAULT_ITEMS: SavedVaultItem[] = [
  {
    id: 'hist-1',
    title: '5-Day Kyoto & Arashiyama Tea Route',
    type: 'voyage',
    summary: 'Complete itinerary with morning bamboo grove visits, Uji matcha workshops, and mountain transit.',
    timestamp: '2 hours ago',
    pinned: true,
  },
  {
    id: 'hist-2',
    title: 'Neon Oasis in the Dunes (4K Render)',
    type: 'image',
    summary: 'High-res architectural visualization generated with Gemini 3 Pro at 4096px resolution.',
    timestamp: 'Yesterday',
    pinned: true,
  },
  {
    id: 'hist-3',
    title: 'Mobile App Store Launch 30-Day Sequencer',
    type: 'task',
    summary: 'Multi-phase milestones covering beta distribution, metadata localization, and CI/CD pipelines.',
    timestamp: '3 days ago',
  },
  {
    id: 'hist-4',
    title: 'Resilient TypeScript WebSocket Manager',
    type: 'code',
    summary: 'Full-stack client architecture with exponential backoff and message deduplication.',
    timestamp: '5 days ago',
  },
  {
    id: 'hist-5',
    title: 'Voice Briefing: Global Clean Tech Horizons',
    type: 'voice',
    summary: 'Real-time spoken synthesis discussing battery solid-state scaling in 2026.',
    timestamp: '1 week ago',
  },
];

export function loadSavedVaultItems(): SavedVaultItem[] {
  try {
    const raw = getItem(SAVED_ITEMS_KEY);
    if (!raw) return DEFAULT_VAULT_ITEMS;
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : DEFAULT_VAULT_ITEMS;
  } catch {
    return DEFAULT_VAULT_ITEMS;
  }
}

export function saveVaultItems(items: SavedVaultItem[]): boolean {
  try {
    setItem(SAVED_ITEMS_KEY, JSON.stringify(items));
    return true;
  } catch {
    return false;
  }
}

export function clearAllVaultHistory(): { success: boolean; clearedCount: number } {
  const items = loadSavedVaultItems();
  const count = items.length;
  removeItem(SAVED_ITEMS_KEY);
  return { success: true, clearedCount: count };
}

// ----------------- Storage Diagnostics -----------------

export function getStorageDiagnostics(): StorageStatus {
  const { available, reason } = testStorageAvailability();
  const sessions = loadChatSessions();
  const vaultItems = loadSavedVaultItems();

  let estimatedBytes = 0;
  if (available && typeof window !== 'undefined' && window.localStorage) {
    try {
      for (let i = 0; i < window.localStorage.length; i++) {
        const k = window.localStorage.key(i);
        if (k && k.startsWith('safar_')) {
          const val = window.localStorage.getItem(k) || '';
          estimatedBytes += (k.length + val.length) * 2; // UTF-16
        }
      }
    } catch {
      // Ignore
    }
  }

  return {
    available,
    storageType: available ? 'localStorage' : 'memory',
    sessionCount: sessions.length,
    historyCount: vaultItems.length,
    estimatedBytes,
    limitationMessage: available
      ? undefined
      : `Browser LocalStorage is unavailable or restricted (${reason || 'Security Sandbox'}). Conversations and settings are stored in-memory and will reset upon page refresh.`,
  };
}

// ----------------- Export Backup -----------------

export function exportAllDataAsJSON(): string {
  const payload = {
    app: 'Safar AI Agent',
    version: '2.4.0',
    exportedAt: new Date().toISOString(),
    settings: loadSettings(),
    chatSessions: loadChatSessions(),
    vaultHistory: loadSavedVaultItems(),
  };
  return JSON.stringify(payload, null, 2);
}
