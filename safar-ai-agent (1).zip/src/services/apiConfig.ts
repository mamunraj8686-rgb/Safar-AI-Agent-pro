/**
 * Safar AI Agent API Resolver
 * Dynamically resolves API endpoints for web browsers, dev preview,
 * and native Android APK environments (Capacitor/WebView).
 */

export const PROD_BACKEND_URL = 'https://ais-pre-bdkwws2hsayfl6vy6oklzr-148549843505.europe-west1.run.app';

export function getApiUrl(path: string): string {
  const cleanPath = path.startsWith('/') ? path : `/${path}`;

  // Check if running inside Capacitor Android native environment or custom scheme
  const isNative = typeof window !== 'undefined' && (
    Boolean((window as any).Capacitor?.isNativePlatform?.()) ||
    window.location.protocol === 'capacitor:' ||
    (window.location.hostname === 'localhost' && !window.location.port)
  );

  const envBase = (import.meta as any).env?.VITE_BACKEND_URL || (import.meta as any).env?.VITE_API_BASE_URL;
  const baseUrl = envBase || (isNative ? PROD_BACKEND_URL : '');

  return `${baseUrl}${cleanPath}`;
}
