import React, { useState, useRef } from 'react';
import { Eye, Upload, Camera, Copy, Check, Sparkles, RefreshCw, ArrowLeft, MessageSquare, X } from 'lucide-react';
import { getApiUrl } from '../../services/apiConfig';

interface VisionToolProps {
  onBack: () => void;
  onSendToChat?: (text: string) => void;
}

export const VisionTool: React.FC<VisionToolProps> = ({ onBack, onSendToChat }) => {
  const [imageBase64, setImageBase64] = useState<string | null>(null);
  const [mimeType, setMimeType] = useState<string>('image/jpeg');
  const [prompt, setPrompt] = useState<string>('Describe this image in detail and identify key objects, text, and scene context.');
  const [mode, setMode] = useState<'analyze' | 'ocr' | 'objects' | 'qa'>('analyze');
  const [language, setLanguage] = useState<string>('en');
  const [analysis, setAnalysis] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setError('Please upload a valid image file');
      return;
    }

    setMimeType(file.type);
    setError(null);

    const reader = new FileReader();
    reader.onload = () => {
      setImageBase64(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleAnalyze = async (customPrompt?: string) => {
    if (!imageBase64) {
      setError('Please upload or capture an image first');
      return;
    }
    setLoading(true);
    setError(null);

    const activePrompt = customPrompt || prompt;

    try {
      const res = await fetch(getApiUrl('/api/tools/vision'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64,
          mimeType,
          prompt: activePrompt,
          mode,
          language,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Visual analysis failed');
      setAnalysis(data.analysis);
    } catch (err: any) {
      setError(err?.message || 'Failed to inspect image');
    } finally {
      setLoading(false);
    }
  };

  const setModeAndRun = (m: 'analyze' | 'ocr' | 'objects' | 'qa') => {
    setMode(m);
    let p = '';
    if (m === 'analyze') p = 'Provide a comprehensive breakdown of this scene, objects, lighting, and composition.';
    else if (m === 'ocr') p = 'Transcribe every visible text, sign, label, or handwriting in this image word-for-word.';
    else if (m === 'objects') p = 'Identify all distinct items, products, landmarks, and organisms in this image.';
    else p = 'Answer my specific question regarding this image:';
    setPrompt(p);
    if (imageBase64) {
      handleAnalyze(p);
    }
  };

  const copyResult = () => {
    navigator.clipboard.writeText(analysis);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex-1 flex flex-col overflow-y-auto bg-[#0B0B0C] p-4 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-2 border-b border-white/[0.08]">
        <div className="flex items-center gap-2">
          <button onClick={onBack} className="p-1.5 rounded-xl bg-white/5 text-zinc-300 hover:text-white">
            <ArrowLeft size={16} />
          </button>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
              <Eye size={15} className="text-orange-400" />
              <span>Safar Image Understanding</span>
            </h3>
            <p className="text-[10px] text-zinc-400">Multimodal vision analysis, OCR extraction & visual QA</p>
          </div>
        </div>
      </div>

      {error && (
        <div className="p-2.5 rounded-xl bg-red-950/40 border border-red-500/30 text-xs text-red-200 flex items-center justify-between gap-2 animate-in fade-in">
          <span>{error}</span>
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={() => handleAnalyze()}
              disabled={loading || !imageBase64}
              className="px-2 py-0.5 rounded-lg bg-orange-500 hover:bg-orange-600 text-white font-medium text-[11px] flex items-center gap-1 transition-colors"
            >
              <RefreshCw size={11} className={loading ? 'animate-spin' : ''} />
              <span>Retry</span>
            </button>
            <button onClick={() => setError(null)} className="text-red-400 hover:text-white p-0.5 text-xs">
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Image Preview & Upload */}
      <div className="space-y-3 bg-[#141418] p-3.5 rounded-2xl border border-white/[0.08]">
        {!imageBase64 ? (
          <div
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-white/15 rounded-xl p-6 text-center cursor-pointer hover:border-orange-500/50 bg-[#16161B] transition-colors"
          >
            <Camera size={26} className="mx-auto text-orange-400 mb-1.5" />
            <p className="text-xs font-semibold text-white">Tap to upload or capture an image</p>
            <p className="text-[10px] text-zinc-400 mt-0.5">Supports PNG, JPG, WEBP photos & camera snapshots</p>
          </div>
        ) : (
          <div className="relative rounded-xl overflow-hidden bg-black max-h-56 border border-white/10 flex items-center justify-center">
            <img src={imageBase64} alt="Upload" className="max-h-56 max-w-full object-contain" />
            <button
              onClick={() => {
                setImageBase64(null);
                setAnalysis('');
              }}
              className="absolute top-2 right-2 p-1.5 rounded-lg bg-black/75 text-white hover:bg-red-600 transition-colors"
              title="Remove Image"
            >
              <X size={14} />
            </button>
          </div>
        )}

        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleImageUpload}
          className="hidden"
        />

        {/* Vision Mode Buttons */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 text-xs">
          <button
            onClick={() => setModeAndRun('analyze')}
            className={`py-1.5 px-2 rounded-xl border text-center transition-all ${
              mode === 'analyze'
                ? 'bg-orange-500 text-white border-orange-500 font-semibold'
                : 'bg-white/5 text-zinc-300 border-white/5 hover:border-white/20'
            }`}
          >
            Scene Breakdown
          </button>
          <button
            onClick={() => setModeAndRun('ocr')}
            className={`py-1.5 px-2 rounded-xl border text-center transition-all ${
              mode === 'ocr'
                ? 'bg-orange-500 text-white border-orange-500 font-semibold'
                : 'bg-white/5 text-zinc-300 border-white/5 hover:border-white/20'
            }`}
          >
            OCR Text Extract
          </button>
          <button
            onClick={() => setModeAndRun('objects')}
            className={`py-1.5 px-2 rounded-xl border text-center transition-all ${
              mode === 'objects'
                ? 'bg-orange-500 text-white border-orange-500 font-semibold'
                : 'bg-white/5 text-zinc-300 border-white/5 hover:border-white/20'
            }`}
          >
            Detect Objects
          </button>
          <button
            onClick={() => setMode('qa')}
            className={`py-1.5 px-2 rounded-xl border text-center transition-all ${
              mode === 'qa'
                ? 'bg-orange-500 text-white border-orange-500 font-semibold'
                : 'bg-white/5 text-zinc-300 border-white/5 hover:border-white/20'
            }`}
          >
            Ask Question
          </button>
        </div>

        {/* Custom Prompt Input */}
        <div>
          <label className="block text-xs font-medium text-zinc-300 mb-1">Visual Query or Instruction</label>
          <input
            type="text"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="What should Safar analyze in this photo?"
            className="w-full bg-[#18181D] border border-white/10 rounded-xl px-2.5 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-orange-500"
          />
        </div>

        {/* Language selector */}
        <div className="flex items-center justify-between text-xs pt-1">
          <span className="text-zinc-400">Response Language:</span>
          <select
            value={language}
            onChange={(e) => setLanguage(e.target.value)}
            className="bg-[#18181D] text-xs text-white border border-white/10 rounded-lg px-2.5 py-1"
          >
            <option value="en">English</option>
            <option value="bn">বাংলা (Bengali)</option>
            <option value="ar">العربية (Arabic)</option>
          </select>
        </div>

        <button
          onClick={() => handleAnalyze()}
          disabled={loading || !imageBase64}
          className="w-full py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 disabled:bg-zinc-800 disabled:text-zinc-500 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md shadow-orange-500/20"
        >
          {loading ? (
            <>
              <RefreshCw size={14} className="animate-spin" />
              <span>Analyzing image with Gemini Vision...</span>
            </>
          ) : (
            <>
              <Sparkles size={14} />
              <span>Inspect with Gemini 3.8 Flash</span>
            </>
          )}
        </button>
      </div>

      {/* Visual Analysis Output */}
      {analysis && (
        <div className="space-y-2 bg-[#141418] p-3.5 rounded-2xl border border-orange-500/30 animate-in fade-in">
          <div className="flex items-center justify-between text-xs pb-1 border-b border-white/5">
            <span className="font-semibold text-orange-400">Visual Intelligence Analysis</span>
            <div className="flex items-center gap-1.5">
              <button onClick={copyResult} className="p-1.5 rounded-lg bg-white/5 text-zinc-300 hover:text-white" title="Copy Analysis">
                {copied ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
              </button>
              {onSendToChat && (
                <button
                  onClick={() => onSendToChat(`Image Analysis (${prompt}):\n\n${analysis}`)}
                  className="p-1.5 rounded-lg bg-orange-500 text-white hover:bg-orange-600"
                  title="Send to Chat"
                >
                  <MessageSquare size={13} />
                </button>
              )}
            </div>
          </div>
          <div
            dir={language === 'ar' ? 'rtl' : 'ltr'}
            className={`text-xs text-zinc-200 whitespace-pre-line leading-relaxed ${language === 'ar' ? 'text-right' : 'text-left'}`}
          >
            {analysis}
          </div>
        </div>
      )}
    </div>
  );
};
