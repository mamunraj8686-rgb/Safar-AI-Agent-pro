import React, { useState, useRef, useEffect } from 'react';
import { 
  QrCode, 
  Camera, 
  Upload, 
  Copy, 
  Check, 
  ExternalLink, 
  Sparkles, 
  RefreshCw, 
  ArrowLeft, 
  MessageSquare, 
  ShieldCheck, 
  AlertCircle,
  Video,
  VideoOff
} from 'lucide-react';
import jsQR from 'jsqr';
import { getApiUrl } from '../../services/apiConfig';

interface ScannerToolProps {
  onBack: () => void;
  onSendToChat?: (text: string) => void;
}

export const ScannerTool: React.FC<ScannerToolProps> = ({ onBack, onSendToChat }) => {
  const [cameraActive, setCameraActive] = useState<boolean>(false);
  const [scanResult, setScanResult] = useState<string | null>(null);
  const [codeType, setCodeType] = useState<string>('QR_CODE');
  const [aiAnalysis, setAiAnalysis] = useState<string>('');
  const [analyzing, setAnalyzing] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [language, setLanguage] = useState<string>('en');

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animFrameRef = useRef<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Stop camera stream cleanly
  const stopCamera = () => {
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach((track) => track.stop());
      videoRef.current.srcObject = null;
    }
    setCameraActive(false);
  };

  // Start real camera stream
  const startCamera = async () => {
    setCameraError(null);
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Camera API is not supported in this browser environment');
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' },
        audio: false,
      });

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.setAttribute('playsinline', 'true');
        await videoRef.current.play();
        setCameraActive(true);
        scanFrame();
      }
    } catch (err: any) {
      console.warn('Camera stream error:', err);
      setCameraError(err?.message || 'Unable to access device camera. Please check permissions or upload an image instead.');
      setCameraActive(false);
    }
  };

  // Continual frame scanning with canvas and jsQR
  const scanFrame = () => {
    if (!videoRef.current || !canvasRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d', { willReadFrequently: true });

    if (video.readyState === video.HAVE_ENOUGH_DATA && ctx) {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const code = jsQR(imageData.data, imageData.width, imageData.height, {
        inversionAttempts: 'attemptBoth',
      });

      if (code && code.data) {
        setScanResult(code.data);
        setCodeType('QR_CODE');
        stopCamera();
        analyzeCode(code.data, 'QR_CODE');
        return;
      }
    }

    animFrameRef.current = requestAnimationFrame(scanFrame);
  };

  // Decode from uploaded image
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setCameraError(null);
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0);
          const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
          const code = jsQR(imageData.data, imageData.width, imageData.height);
          if (code && code.data) {
            setScanResult(code.data);
            setCodeType('QR_CODE');
            analyzeCode(code.data, 'QR_CODE');
          } else {
            // Fallback: If jsQR didn't catch standard QR, analyze image using Gemini Vision for barcode / QR
            analyzeImageForBarcodes(reader.result as string, file.type);
          }
        }
      };
      img.src = reader.result as string;
    };
    reader.readAsDataURL(file);
  };

  // Fallback to Gemini Vision to decode barcode/QR from photo
  const analyzeImageForBarcodes = async (base64: string, mimeType: string) => {
    setAnalyzing(true);
    try {
      const res = await fetch(getApiUrl('/api/tools/vision'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: base64,
          mimeType,
          prompt: 'Read any QR code, barcode, or product UPC in this image. State the decoded payload, verify what it is, and provide details.',
          language,
        }),
      });
      const data = await res.json();
      setScanResult('Extracted via Optical AI');
      setAiAnalysis(data.analysis || 'No barcode could be identified in the image.');
    } catch (err: any) {
      setCameraError('Could not decode barcode from this image. Please try a clearer picture.');
    } finally {
      setAnalyzing(false);
    }
  };

  // Analyze decoded barcode/QR payload with Safar AI
  const analyzeCode = async (content: string, format = 'QR_CODE') => {
    setAnalyzing(true);
    try {
      const res = await fetch(getApiUrl('/api/tools/scanner-analyze'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          codeContent: content,
          format,
          language,
        }),
      });
      const data = await res.json();
      setAiAnalysis(data.analysis || 'Analysis complete.');
    } catch (err: any) {
      console.warn('Analysis error:', err);
    } finally {
      setAnalyzing(false);
    }
  };

  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  const copyResult = () => {
    if (!scanResult) return;
    navigator.clipboard.writeText(scanResult);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const isUrl = (str: string) => /^https?:\/\//i.test(str.trim());

  return (
    <div className="flex-1 flex flex-col overflow-y-auto bg-[#0B0B0C] p-4 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-2 border-b border-white/[0.08]">
        <div className="flex items-center gap-2">
          <button onClick={onBack} className="p-1.5 rounded-xl bg-white/5 text-zinc-300 hover:text-white">
            <ArrowLeft size={16} />
          </button>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
              <QrCode size={15} className="text-orange-400" />
              <span>Safar Optical QR & Barcode Scanner</span>
            </h3>
            <p className="text-[10px] text-zinc-400">Live camera scanner, barcode lookup & safety check</p>
          </div>
        </div>
      </div>

      {cameraError && (
        <div className="p-2.5 rounded-xl bg-red-950/40 border border-red-500/30 text-xs text-red-200 flex items-center justify-between gap-2 animate-in fade-in">
          <div className="flex items-start gap-2">
            <AlertCircle size={15} className="text-red-400 shrink-0 mt-0.5" />
            <p>{cameraError}</p>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={startCamera}
              className="px-2 py-0.5 rounded-lg bg-orange-500 hover:bg-orange-600 text-white font-medium text-[11px] flex items-center gap-1 transition-colors"
            >
              <RefreshCw size={11} />
              <span>Retry</span>
            </button>
            <button onClick={() => setCameraError(null)} className="text-red-400 hover:text-white p-0.5 text-xs">
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Camera Viewfinder / Scanner Area */}
      <div className="space-y-3 bg-[#141418] p-3.5 rounded-2xl border border-white/[0.08]">
        <div className="relative rounded-2xl overflow-hidden bg-black aspect-video sm:aspect-[4/3] flex items-center justify-center border border-white/10">
          <video ref={videoRef} className={`w-full h-full object-cover ${cameraActive ? 'block' : 'hidden'}`} />
          <canvas ref={canvasRef} className="hidden" />

          {/* Viewfinder Overlay when camera active */}
          {cameraActive && (
            <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
              <div className="w-48 h-48 sm:w-56 sm:h-56 border-2 border-orange-500/60 rounded-2xl relative shadow-[0_0_40px_rgba(249,115,22,0.3)]">
                <div className="absolute -top-1 -left-1 w-4 h-4 border-t-2 border-l-2 border-orange-400"></div>
                <div className="absolute -top-1 -right-1 w-4 h-4 border-t-2 border-r-2 border-orange-400"></div>
                <div className="absolute -bottom-1 -left-1 w-4 h-4 border-b-2 border-l-2 border-orange-400"></div>
                <div className="absolute -bottom-1 -right-1 w-4 h-4 border-b-2 border-r-2 border-orange-400"></div>
                <div className="w-full h-0.5 bg-orange-500/70 absolute top-1/2 -translate-y-1/2 animate-pulse shadow-[0_0_10px_#F97316]"></div>
              </div>
            </div>
          )}

          {/* Fallback Idle Display */}
          {!cameraActive && (
            <div className="text-center p-6 space-y-2">
              <QrCode size={36} className="mx-auto text-orange-400/80 mb-1" />
              <p className="text-xs font-semibold text-white">Camera Viewfinder Ready</p>
              <p className="text-[10px] text-zinc-400 max-w-xs mx-auto">
                Tap Start Camera to scan QR codes and barcodes with live optical recognition.
              </p>
            </div>
          )}
        </div>

        {/* Scanner Action Controls */}
        <div className="grid grid-cols-2 gap-2 text-xs">
          {cameraActive ? (
            <button
              onClick={stopCamera}
              className="py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-semibold flex items-center justify-center gap-1.5 transition-colors"
            >
              <VideoOff size={14} />
              <span>Stop Camera</span>
            </button>
          ) : (
            <button
              onClick={startCamera}
              className="py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-semibold flex items-center justify-center gap-1.5 transition-all shadow-md shadow-orange-500/25"
            >
              <Video size={14} />
              <span>Start Camera Scanner</span>
            </button>
          )}

          <button
            onClick={() => fileInputRef.current?.click()}
            className="py-2.5 rounded-xl bg-[#1C1C22] hover:bg-white/10 text-zinc-200 border border-white/10 font-semibold flex items-center justify-center gap-1.5 transition-colors"
          >
            <Upload size={14} />
            <span>Upload QR Image</span>
          </button>
        </div>

        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileUpload}
          className="hidden"
        />

        {/* Quick Sample Demo codes */}
        <div className="pt-1 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          <span className="text-[10px] text-zinc-500 font-mono">Demo:</span>
          <button
            onClick={() => {
              setScanResult('https://safar.ai/expeditions/kyoto-trail');
              analyzeCode('https://safar.ai/expeditions/kyoto-trail', 'URL_QR');
            }}
            className="text-[11px] whitespace-nowrap shrink-0 px-2.5 py-1 rounded-lg bg-white/5 text-zinc-300 hover:text-orange-400"
          >
            Travel URL QR
          </button>
          <button
            onClick={() => {
              setScanResult('012345678905');
              analyzeCode('012345678905', 'UPC_BARCODE');
            }}
            className="text-[11px] whitespace-nowrap shrink-0 px-2.5 py-1 rounded-lg bg-white/5 text-zinc-300 hover:text-orange-400"
          >
            Product UPC Barcode
          </button>
        </div>
      </div>

      {/* Scan Result Output Card */}
      {scanResult && (
        <div className="space-y-3 bg-[#141418] p-3.5 rounded-2xl border border-orange-500/30 animate-in fade-in">
          <div className="flex items-center justify-between text-xs pb-1 border-b border-white/5">
            <span className="font-semibold text-orange-400 flex items-center gap-1.5">
              <ShieldCheck size={14} />
              <span>Scanned Payload Decoded</span>
            </span>
            <span className="text-[10px] font-mono text-zinc-400">{codeType}</span>
          </div>

          <div className="p-2.5 rounded-xl bg-black/60 border border-white/10 font-mono text-xs text-white break-all">
            {scanResult}
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2 text-xs">
            {isUrl(scanResult) && (
              <a
                href={scanResult}
                target="_blank"
                rel="noreferrer"
                className="flex-1 py-1.5 rounded-lg bg-orange-500 text-white font-medium hover:bg-orange-600 transition-colors flex items-center justify-center gap-1"
              >
                <ExternalLink size={13} />
                <span>Open URL</span>
              </a>
            )}

            <button
              onClick={copyResult}
              className="py-1.5 px-3 rounded-lg bg-white/5 border border-white/10 text-zinc-300 hover:text-white transition-colors flex items-center gap-1"
            >
              {copied ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>

            {onSendToChat && (
              <button
                onClick={() => onSendToChat(`I scanned this barcode/QR code: "${scanResult}". What can you tell me about it?`)}
                className="py-1.5 px-3 rounded-lg bg-white/5 border border-white/10 text-zinc-300 hover:text-orange-400 transition-colors flex items-center gap-1"
              >
                <MessageSquare size={13} />
                <span>Chat</span>
              </button>
            )}
          </div>

          {/* Safar AI Payload Analysis */}
          {analyzing ? (
            <div className="p-3 rounded-xl bg-[#18181D] border border-white/5 text-xs text-zinc-400 flex items-center gap-2">
              <RefreshCw size={13} className="animate-spin text-orange-400" />
              <span>Safar AI is verifying payload safety and product data...</span>
            </div>
          ) : aiAnalysis ? (
            <div className="p-3 rounded-xl bg-[#18181D] border border-white/5 text-xs text-zinc-300 space-y-1.5">
              <div className="font-semibold text-orange-400 flex items-center gap-1">
                <Sparkles size={13} />
                <span>Safar Security & Payload Intelligence</span>
              </div>
              <p className="whitespace-pre-line leading-relaxed">{aiAnalysis}</p>
            </div>
          ) : null}
        </div>
      )}
    </div>
  );
};
