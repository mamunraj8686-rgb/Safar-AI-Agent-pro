import React, { useState } from 'react';
import { Languages, ArrowLeftRight, Copy, Check, Volume2, ArrowLeft, RefreshCw, Sparkles, MessageSquare } from 'lucide-react';
import { getApiUrl } from '../../services/apiConfig';

interface TranslatorToolProps {
  onBack: () => void;
  onSendToChat?: (text: string) => void;
}

export const TranslatorTool: React.FC<TranslatorToolProps> = ({ onBack, onSendToChat }) => {
  const [sourceText, setSourceText] = useState<string>('');
  const [fromLang, setFromLang] = useState<string>('auto');
  const [toLang, setToLang] = useState<string>('bn');
  const [translation, setTranslation] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleTranslate = async () => {
    if (!sourceText.trim()) return;
    setLoading(true);
    setError(null);

    try {
      const res = await fetch(getApiUrl('/api/tools/translate'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: sourceText,
          fromLang,
          toLang,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Translation failed');
      setTranslation(data.translation);
    } catch (err: any) {
      setError(err?.message || 'Translation failed');
    } finally {
      setLoading(false);
    }
  };

  const swapLanguages = () => {
    if (fromLang === 'auto') return;
    const temp = fromLang;
    setFromLang(toLang);
    setToLang(temp);
    if (translation) {
      setSourceText(translation.split('\n\nNotes')[0].trim());
      setTranslation('');
    }
  };

  const copyResult = () => {
    navigator.clipboard.writeText(translation);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const playSpeech = (text: string, lang: string) => {
    if (!('speechSynthesis' in window) || !text) return;
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(text);
    if (lang === 'bn') utter.lang = 'bn-BD';
    else if (lang === 'ar') utter.lang = 'ar-SA';
    else utter.lang = 'en-US';
    window.speechSynthesis.speak(utter);
  };

  return (
    <div className="flex-1 flex flex-col overflow-y-auto bg-[#0B0B0C] p-4 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-2 border-b border-white/[0.08]">
        <div className="flex items-center gap-2">
          <button onClick={onBack} className="p-1.5 rounded-xl bg-white/5 text-zinc-300 hover:text-white">
            <ArrowLeft size={16} />
          </button>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
              <Languages size={15} className="text-orange-400" />
              <span>Safar Neural Translator</span>
            </h3>
            <p className="text-[10px] text-zinc-400">Contextual translation for Bengali, Arabic, English & global tongues</p>
          </div>
        </div>
      </div>

      {error && (
        <div className="p-2.5 rounded-xl bg-red-950/40 border border-red-500/30 text-xs text-red-200 flex items-center justify-between gap-2 animate-in fade-in">
          <span>{error}</span>
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={handleTranslate}
              disabled={loading || !sourceText.trim()}
              className="px-2 py-0.5 rounded-lg bg-orange-500 hover:bg-orange-600 text-white font-medium text-[11px] flex items-center gap-1 transition-colors"
            >
              <RefreshCw size={11} className={loading ? 'animate-spin' : ''} />
              <span>Retry</span>
            </button>
            <button onClick={() => setError(null)} className="text-red-400 hover:text-white p-0.5 text-xs">
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Language Bar */}
      <div className="flex items-center justify-between bg-[#141418] p-2 rounded-2xl border border-white/10 text-xs">
        <select
          value={fromLang}
          onChange={(e) => setFromLang(e.target.value)}
          className="bg-transparent text-white focus:outline-none text-xs font-medium cursor-pointer"
        >
          <option value="auto">Detect Language</option>
          <option value="en">English (UK/US)</option>
          <option value="bn">বাংলা (Bengali)</option>
          <option value="ar">العربية (Arabic)</option>
          <option value="es">Spanish</option>
          <option value="fr">French</option>
          <option value="de">German</option>
          <option value="ja">Japanese</option>
        </select>

        <button
          onClick={swapLanguages}
          disabled={fromLang === 'auto'}
          className="p-1.5 rounded-lg bg-white/5 text-zinc-300 hover:text-orange-400 disabled:opacity-30"
          title="Swap Languages"
        >
          <ArrowLeftRight size={14} />
        </button>

        <select
          value={toLang}
          onChange={(e) => setToLang(e.target.value)}
          className="bg-transparent text-orange-400 focus:outline-none text-xs font-semibold cursor-pointer"
        >
          <option value="bn">বাংলা (Bengali)</option>
          <option value="ar">العربية (Arabic)</option>
          <option value="en">English</option>
          <option value="es">Spanish</option>
          <option value="fr">French</option>
          <option value="de">German</option>
          <option value="ja">Japanese</option>
        </select>
      </div>

      {/* Source Text Input */}
      <div className="space-y-2 bg-[#141418] p-3.5 rounded-2xl border border-white/[0.08]">
        <textarea
          value={sourceText}
          onChange={(e) => setSourceText(e.target.value)}
          placeholder="Enter text to translate..."
          rows={4}
          className="w-full bg-[#18181D] border border-white/10 rounded-xl p-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-orange-500"
        />

        {/* Quick sample chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          <button
            onClick={() => {
              setSourceText('The journey of a thousand miles begins with a single step.');
              setFromLang('en');
              setToLang('bn');
            }}
            className="text-[11px] whitespace-nowrap shrink-0 px-2 py-1 rounded-lg bg-white/5 text-zinc-300 hover:text-white"
          >
            EN → বাংলা: Journey quote
          </button>
          <button
            onClick={() => {
              setSourceText('Welcome traveler to Safar AI. Where would you like to travel?');
              setFromLang('en');
              setToLang('ar');
            }}
            className="text-[11px] whitespace-nowrap shrink-0 px-2 py-1 rounded-lg bg-white/5 text-zinc-300 hover:text-white"
          >
            EN → العربية: Welcome
          </button>
        </div>

        <button
          onClick={handleTranslate}
          disabled={loading || !sourceText.trim()}
          className="w-full py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 disabled:bg-zinc-800 disabled:text-zinc-500 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md shadow-orange-500/20"
        >
          {loading ? (
            <>
              <RefreshCw size={14} className="animate-spin" />
              <span>Translating...</span>
            </>
          ) : (
            <>
              <Sparkles size={14} />
              <span>Translate Text</span>
            </>
          )}
        </button>
      </div>

      {/* Translation Output */}
      {translation && (
        <div className="space-y-2 bg-[#141418] p-3.5 rounded-2xl border border-orange-500/30 animate-in fade-in">
          <div className="flex items-center justify-between text-xs pb-1 border-b border-white/5">
            <span className="font-semibold text-orange-400">Translation</span>
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => playSpeech(translation, toLang)}
                className="p-1.5 rounded-lg bg-white/5 text-zinc-300 hover:text-white"
                title="Pronounce Translation"
              >
                <Volume2 size={13} />
              </button>
              <button onClick={copyResult} className="p-1.5 rounded-lg bg-white/5 text-zinc-300 hover:text-white" title="Copy Translation">
                {copied ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
              </button>
              {onSendToChat && (
                <button
                  onClick={() => onSendToChat(`Here is the translated text:\n\n${translation}`)}
                  className="p-1.5 rounded-lg bg-orange-500 text-white hover:bg-orange-600"
                  title="Send to Chat"
                >
                  <MessageSquare size={13} />
                </button>
              )}
            </div>
          </div>
          <div
            dir={toLang === 'ar' ? 'rtl' : 'ltr'}
            className={`text-xs text-zinc-200 whitespace-pre-line leading-relaxed ${toLang === 'ar' ? 'text-right' : 'text-left'}`}
          >
            {translation}
          </div>
        </div>
      )}
    </div>
  );
};
