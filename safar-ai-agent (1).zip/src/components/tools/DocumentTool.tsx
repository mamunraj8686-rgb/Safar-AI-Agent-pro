import React, { useState, useRef } from 'react';
import { FileText, Upload, Copy, Check, Sparkles, RefreshCw, ArrowLeft, MessageSquare, X, FileUp } from 'lucide-react';
import { getApiUrl } from '../../services/apiConfig';

interface DocumentToolProps {
  onBack: () => void;
  onSendToChat?: (text: string) => void;
}

export const DocumentTool: React.FC<DocumentToolProps> = ({ onBack, onSendToChat }) => {
  const [file, setFile] = useState<{ name: string; size: string; type: string; data: string } | null>(null);
  const [question, setQuestion] = useState<string>('Summarize the critical points and conclusions of this document.');
  const [language, setLanguage] = useState<string>('en');
  const [answer, setAnswer] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFile = e.target.files?.[0];
    if (!uploadedFile) return;

    setError(null);
    const sizeKB = (uploadedFile.size / 1024).toFixed(1) + ' KB';

    const reader = new FileReader();
    if (uploadedFile.type.includes('pdf')) {
      reader.onload = () => {
        setFile({
          name: uploadedFile.name,
          size: sizeKB,
          type: 'application/pdf',
          data: reader.result as string,
        });
      };
      reader.readAsDataURL(uploadedFile);
    } else {
      reader.onload = () => {
        setFile({
          name: uploadedFile.name,
          size: sizeKB,
          type: uploadedFile.type || 'text/plain',
          data: reader.result as string,
        });
      };
      reader.readAsText(uploadedFile);
    }
  };

  const handleAnalyze = async () => {
    if (!file) {
      setError('Please select or upload a document first');
      return;
    }
    setLoading(true);
    setError(null);

    try {
      const res = await fetch(getApiUrl('/api/tools/document'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fileData: file.data,
          fileType: file.type,
          fileName: file.name,
          question,
          language,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Document processing failed');
      setAnswer(data.answer);
    } catch (err: any) {
      setError(err?.message || 'Failed to process document');
    } finally {
      setLoading(false);
    }
  };

  const copyResult = () => {
    navigator.clipboard.writeText(answer);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex-1 flex flex-col overflow-y-auto bg-[#0B0B0C] p-4 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-2 border-b border-white/[0.08]">
        <div className="flex items-center gap-2">
          <button onClick={onBack} className="p-1.5 rounded-xl bg-white/5 text-zinc-300 hover:text-white">
            <ArrowLeft size={16} />
          </button>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
              <FileText size={15} className="text-orange-400" />
              <span>Safar PDF & File Assistant</span>
            </h3>
            <p className="text-[10px] text-zinc-400">Deep inspection, QA & extraction for PDF, CSV, TXT & Docs</p>
          </div>
        </div>
      </div>

      {error && (
        <div className="p-2.5 rounded-xl bg-red-950/40 border border-red-500/30 text-xs text-red-200 flex items-center justify-between gap-2 animate-in fade-in">
          <span>{error}</span>
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={handleAnalyze}
              disabled={loading || !file}
              className="px-2 py-0.5 rounded-lg bg-orange-500 hover:bg-orange-600 text-white font-medium text-[11px] flex items-center gap-1 transition-colors"
            >
              <RefreshCw size={11} className={loading ? 'animate-spin' : ''} />
              <span>Retry</span>
            </button>
            <button onClick={() => setError(null)} className="text-red-400 hover:text-white p-0.5 text-xs">
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Upload Box */}
      <div className="space-y-3 bg-[#141418] p-3.5 rounded-2xl border border-white/[0.08]">
        {!file ? (
          <div
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-white/15 rounded-xl p-5 text-center cursor-pointer hover:border-orange-500/50 bg-[#16161B] transition-colors"
          >
            <FileUp size={24} className="mx-auto text-orange-400 mb-1.5" />
            <p className="text-xs font-semibold text-white">Tap to upload a document</p>
            <p className="text-[10px] text-zinc-400 mt-0.5">Supports PDF, TXT, CSV, MD, JSON files</p>
          </div>
        ) : (
          <div className="flex items-center justify-between p-3 rounded-xl bg-[#18181D] border border-white/10">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-8 h-8 rounded-lg bg-orange-500/10 text-orange-400 flex items-center justify-center shrink-0">
                <FileText size={16} />
              </div>
              <div className="min-w-0">
                <p className="text-xs font-semibold text-white truncate">{file.name}</p>
                <p className="text-[10px] text-zinc-400 font-mono">{file.size} · {file.type}</p>
              </div>
            </div>
            <button
              onClick={() => setFile(null)}
              className="p-1 rounded-lg text-zinc-400 hover:text-red-400 transition-colors"
            >
              <X size={15} />
            </button>
          </div>
        )}

        <input
          ref={fileInputRef}
          type="file"
          accept=".pdf,.txt,.md,.csv,.json"
          onChange={handleFileChange}
          className="hidden"
        />

        {/* Question & Actions */}
        <div>
          <label className="block text-xs font-medium text-zinc-300 mb-1">
            Question or Instruction for this Document
          </label>
          <textarea
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="Ask anything about the document contents..."
            rows={2}
            className="w-full bg-[#18181D] border border-white/10 rounded-xl p-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-orange-500"
          />
        </div>

        {/* Quick Question Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          {[
            'Summarize key findings',
            'Extract dates and action deadlines',
            'Explain in simple beginner terms',
            'বাংলায় মূল বক্তব্য ব্যাখ্যা করুন',
            'لخص النقاط الجوهرية بالعربية',
          ].map((q, idx) => (
            <button
              key={idx}
              onClick={() => setQuestion(q)}
              className="text-[11px] whitespace-nowrap shrink-0 px-2.5 py-1 rounded-lg bg-white/5 text-zinc-300 hover:text-orange-400"
            >
              {q}
            </button>
          ))}
        </div>

        {/* Language selector */}
        <div className="flex items-center justify-between text-xs pt-1">
          <span className="text-zinc-400">Response Language:</span>
          <select
            value={language}
            onChange={(e) => setLanguage(e.target.value)}
            className="bg-[#18181D] text-xs text-white border border-white/10 rounded-lg px-2.5 py-1"
          >
            <option value="en">English</option>
            <option value="bn">বাংলা (Bengali)</option>
            <option value="ar">العربية (Arabic)</option>
          </select>
        </div>

        <button
          onClick={handleAnalyze}
          disabled={loading || !file}
          className="w-full py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 disabled:bg-zinc-800 disabled:text-zinc-500 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md shadow-orange-500/20"
        >
          {loading ? (
            <>
              <RefreshCw size={14} className="animate-spin" />
              <span>Analyzing document with Gemini 3.8 Flash...</span>
            </>
          ) : (
            <>
              <Sparkles size={14} />
              <span>Inspect & Answer from Document</span>
            </>
          )}
        </button>
      </div>

      {/* Answer Output */}
      {answer && (
        <div className="space-y-2 bg-[#141418] p-3.5 rounded-2xl border border-orange-500/30 animate-in fade-in">
          <div className="flex items-center justify-between text-xs pb-1 border-b border-white/5">
            <span className="font-semibold text-orange-400">Document Insights</span>
            <div className="flex items-center gap-1.5">
              <button onClick={copyResult} className="p-1.5 rounded-lg bg-white/5 text-zinc-300 hover:text-white" title="Copy Answer">
                {copied ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
              </button>
              {onSendToChat && (
                <button
                  onClick={() => onSendToChat(`Document Analysis (${file?.name}):\n\n${answer}`)}
                  className="p-1.5 rounded-lg bg-orange-500 text-white hover:bg-orange-600"
                  title="Send to Chat"
                >
                  <MessageSquare size={13} />
                </button>
              )}
            </div>
          </div>
          <div
            dir={language === 'ar' ? 'rtl' : 'ltr'}
            className={`text-xs text-zinc-200 whitespace-pre-line leading-relaxed ${language === 'ar' ? 'text-right' : 'text-left'}`}
          >
            {answer}
          </div>
        </div>
      )}
    </div>
  );
};
