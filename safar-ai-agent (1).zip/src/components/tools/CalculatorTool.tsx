import React, { useState } from 'react';
import { Calculator as CalcIcon, Copy, Check, Sparkles, RefreshCw, ArrowLeft, MessageSquare, Equal, Delete } from 'lucide-react';
import { getApiUrl } from '../../services/apiConfig';

interface CalculatorToolProps {
  onBack: () => void;
  onSendToChat?: (text: string) => void;
}

export const CalculatorTool: React.FC<CalculatorToolProps> = ({ onBack, onSendToChat }) => {
  const [display, setDisplay] = useState<string>('');
  const [quickResult, setQuickResult] = useState<string>('');
  const [wordProblem, setWordProblem] = useState<string>('');
  const [aiSolution, setAiSolution] = useState<string>('');
  const [language, setLanguage] = useState<string>('en');
  const [loading, setLoading] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleKeypadPress = (val: string) => {
    setDisplay((prev) => prev + val);
  };

  const clearKeypad = () => {
    setDisplay('');
    setQuickResult('');
  };

  const backspaceKeypad = () => {
    setDisplay((prev) => prev.slice(0, -1));
  };

  const evaluateKeypad = () => {
    try {
      if (!display.trim()) return;
      // Sanitize input for basic math evaluation
      const sanitized = display
        .replace(/×/g, '*')
        .replace(/÷/g, '/')
        .replace(/\^/g, '**');

      if (!/^[0-9+\-*/().%\s**e]+$/.test(sanitized)) {
        throw new Error('Invalid math expression');
      }

      // Safe evaluation using Function
      const res = Function(`'use strict'; return (${sanitized})`)();
      setQuickResult(String(res));
    } catch {
      setQuickResult('Error');
    }
  };

  const handleSolveWithAI = async (queryText?: string) => {
    const q = queryText || wordProblem || display;
    if (!q.trim()) return;
    setLoading(true);
    setError(null);

    try {
      const res = await fetch(getApiUrl('/api/tools/calculate'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: q, language }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Math solve failed');
      setAiSolution(data.solution);
    } catch (err: any) {
      setError(err?.message || 'Calculation failed');
    } finally {
      setLoading(false);
    }
  };

  const copySolution = () => {
    navigator.clipboard.writeText(aiSolution);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex-1 flex flex-col overflow-y-auto bg-[#0B0B0C] p-4 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-2 border-b border-white/[0.08]">
        <div className="flex items-center gap-2">
          <button onClick={onBack} className="p-1.5 rounded-xl bg-white/5 text-zinc-300 hover:text-white">
            <ArrowLeft size={16} />
          </button>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
              <CalcIcon size={15} className="text-orange-400" />
              <span>Safar Computational Calculator</span>
            </h3>
            <p className="text-[10px] text-zinc-400">Scientific keypad & AI step-by-step problem solver</p>
          </div>
        </div>
      </div>

      {error && (
        <div className="p-2.5 rounded-xl bg-red-950/40 border border-red-500/30 text-xs text-red-200 flex items-center justify-between gap-2 animate-in fade-in">
          <span>{error}</span>
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={() => handleSolveWithAI()}
              disabled={loading}
              className="px-2 py-0.5 rounded-lg bg-orange-500 hover:bg-orange-600 text-white font-medium text-[11px] flex items-center gap-1 transition-colors"
            >
              <RefreshCw size={11} className={loading ? 'animate-spin' : ''} />
              <span>Retry</span>
            </button>
            <button onClick={() => setError(null)} className="text-red-400 hover:text-white p-0.5 text-xs">
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Calculator Keypad View */}
      <div className="bg-[#141418] p-3.5 rounded-2xl border border-white/[0.08] space-y-3">
        {/* Screen */}
        <div className="bg-black/60 p-3 rounded-xl border border-white/10 text-right space-y-1">
          <div className="text-xs text-zinc-400 font-mono overflow-x-auto min-h-[16px]">
            {display || '0'}
          </div>
          <div className="text-xl font-bold font-mono text-orange-400">
            {quickResult || '0'}
          </div>
        </div>

        {/* Buttons Grid */}
        <div className="grid grid-cols-4 gap-1.5 text-xs font-mono font-semibold">
          {['C', '(', ')', '÷'].map((btn) => (
            <button
              key={btn}
              onClick={() => {
                if (btn === 'C') clearKeypad();
                else handleKeypadPress(btn);
              }}
              className="py-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-orange-400 active:scale-95 transition-all"
            >
              {btn}
            </button>
          ))}

          {['7', '8', '9', '×'].map((btn) => (
            <button
              key={btn}
              onClick={() => handleKeypadPress(btn)}
              className="py-2.5 rounded-xl bg-[#1C1C22] hover:bg-white/10 text-white active:scale-95 transition-all"
            >
              {btn}
            </button>
          ))}

          {['4', '5', '6', '-'].map((btn) => (
            <button
              key={btn}
              onClick={() => handleKeypadPress(btn)}
              className="py-2.5 rounded-xl bg-[#1C1C22] hover:bg-white/10 text-white active:scale-95 transition-all"
            >
              {btn}
            </button>
          ))}

          {['1', '2', '3', '+'].map((btn) => (
            <button
              key={btn}
              onClick={() => handleKeypadPress(btn)}
              className="py-2.5 rounded-xl bg-[#1C1C22] hover:bg-white/10 text-white active:scale-95 transition-all"
            >
              {btn}
            </button>
          ))}

          {['0', '.', '%', '='].map((btn) => (
            <button
              key={btn}
              onClick={() => {
                if (btn === '=') evaluateKeypad();
                else handleKeypadPress(btn);
              }}
              className={`py-2.5 rounded-xl active:scale-95 transition-all ${
                btn === '='
                  ? 'bg-orange-500 text-white shadow-md shadow-orange-500/25'
                  : 'bg-[#1C1C22] text-white hover:bg-white/10'
              }`}
            >
              {btn}
            </button>
          ))}
        </div>

        {/* Fast Action: Solve formula on keypad with AI */}
        {display && (
          <button
            onClick={() => handleSolveWithAI(display)}
            disabled={loading}
            className="w-full py-2 rounded-xl bg-orange-500/10 text-orange-400 hover:bg-orange-500 hover:text-white border border-orange-500/30 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
          >
            <Sparkles size={13} />
            <span>Explain & Solve "{display}" with Step-by-Step AI</span>
          </button>
        )}
      </div>

      {/* Natural Language Math & Word Problems */}
      <div className="bg-[#141418] p-3.5 rounded-2xl border border-white/[0.08] space-y-3">
        <div className="flex items-center justify-between text-xs text-zinc-300">
          <span className="font-semibold text-white">AI Word Problems & Algebra</span>
          <select
            value={language}
            onChange={(e) => setLanguage(e.target.value)}
            className="bg-[#18181D] text-xs text-zinc-300 border border-white/10 rounded-lg px-2 py-0.5"
          >
            <option value="en">English explanation</option>
            <option value="bn">বাংলা ব্যাখ্যা</option>
            <option value="ar">شرح بالعربية</option>
          </select>
        </div>

        <textarea
          value={wordProblem}
          onChange={(e) => setWordProblem(e.target.value)}
          placeholder="Type an algebra equation, physics calculation, mortgage formula, or word problem..."
          rows={3}
          className="w-full bg-[#18181D] border border-white/10 rounded-xl p-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-orange-500"
        />

        {/* Quick sample chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setWordProblem('A train travels 450 km in 3 hours 45 minutes. What is its average speed in km/h and m/s?')}
            className="text-[11px] whitespace-nowrap shrink-0 px-2 py-1 rounded-lg bg-white/5 text-zinc-300 hover:text-white"
          >
            Train speed problem
          </button>
          <button
            onClick={() => setWordProblem('Solve 2x^2 + 5x - 12 = 0 for all roots using quadratic formula')}
            className="text-[11px] whitespace-nowrap shrink-0 px-2 py-1 rounded-lg bg-white/5 text-zinc-300 hover:text-white"
          >
            Quadratic roots
          </button>
        </div>

        <button
          onClick={() => handleSolveWithAI()}
          disabled={loading || (!wordProblem.trim() && !display.trim())}
          className="w-full py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 disabled:bg-zinc-800 disabled:text-zinc-500 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md shadow-orange-500/20"
        >
          {loading ? (
            <>
              <RefreshCw size={14} className="animate-spin" />
              <span>Computing mathematical proof...</span>
            </>
          ) : (
            <>
              <Sparkles size={14} />
              <span>Solve with Step-by-Step Breakdown</span>
            </>
          )}
        </button>
      </div>

      {/* Step-by-Step AI Solution */}
      {aiSolution && (
        <div className="space-y-2 bg-[#141418] p-3.5 rounded-2xl border border-orange-500/30 animate-in fade-in">
          <div className="flex items-center justify-between text-xs pb-1 border-b border-white/5">
            <span className="font-semibold text-orange-400">Step-by-Step Solution</span>
            <div className="flex items-center gap-1.5">
              <button onClick={copySolution} className="p-1.5 rounded-lg bg-white/5 text-zinc-300 hover:text-white" title="Copy Solution">
                {copied ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
              </button>
              {onSendToChat && (
                <button
                  onClick={() => onSendToChat(`Mathematical Solution:\n\n${aiSolution}`)}
                  className="p-1.5 rounded-lg bg-orange-500 text-white hover:bg-orange-600"
                  title="Send to Chat"
                >
                  <MessageSquare size={13} />
                </button>
              )}
            </div>
          </div>
          <div className="text-xs text-zinc-200 whitespace-pre-line leading-relaxed font-sans">
            {aiSolution}
          </div>
        </div>
      )}
    </div>
  );
};
