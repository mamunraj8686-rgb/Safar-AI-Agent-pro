import React, { useState } from 'react';
import { Search, Copy, Check, Sparkles, RefreshCw, ArrowLeft, MessageSquare, BookOpen, Layers } from 'lucide-react';
import { getApiUrl } from '../../services/apiConfig';

interface ResearchToolProps {
  onBack: () => void;
  onSendToChat?: (text: string) => void;
}

export const ResearchTool: React.FC<ResearchToolProps> = ({ onBack, onSendToChat }) => {
  const [topic, setTopic] = useState<string>('');
  const [depth, setDepth] = useState<string>('comprehensive');
  const [language, setLanguage] = useState<string>('en');
  const [report, setReport] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleResearch = async () => {
    if (!topic.trim()) return;
    setLoading(true);
    setError(null);

    try {
      const res = await fetch(getApiUrl('/api/tools/research'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic, depth, language }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Research failed');
      setReport(data.report);
    } catch (err: any) {
      setError(err?.message || 'Failed to conduct research');
    } finally {
      setLoading(false);
    }
  };

  const copyResult = () => {
    navigator.clipboard.writeText(report);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const sampleTopics = [
    { label: 'Next-Gen Solid State Batteries', text: 'Solid-state battery commercialization bottlenecks, leading electrolyte chemistries, and EV scaling timeline' },
    { label: 'বাংলা: মহাকাশ বিজ্ঞান', text: 'জেমস ওয়েব স্পেস টেলিস্কোপের সাম্প্রতিক আবিষ্কার এবং মহাবিশ্বের প্রথম গ্যালাক্সি', lang: 'bn' },
    { label: 'العربية: الطاقة المتجددة', text: 'مستقبل إنتاج الهيدروجين الأخضر في الشرق الأوسط وشمال أفريقيا', lang: 'ar' },
  ];

  return (
    <div className="flex-1 flex flex-col overflow-y-auto bg-[#0B0B0C] p-4 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-2 border-b border-white/[0.08]">
        <div className="flex items-center gap-2">
          <button onClick={onBack} className="p-1.5 rounded-xl bg-white/5 text-zinc-300 hover:text-white">
            <ArrowLeft size={16} />
          </button>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
              <BookOpen size={15} className="text-orange-400" />
              <span>Safar Research Assistant</span>
            </h3>
            <p className="text-[10px] text-zinc-400">Deep structured intelligence briefs & literature synthesis</p>
          </div>
        </div>
      </div>

      {error && (
        <div className="p-2.5 rounded-xl bg-red-950/40 border border-red-500/30 text-xs text-red-200 flex items-center justify-between gap-2 animate-in fade-in">
          <span>{error}</span>
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={handleResearch}
              disabled={loading || !topic.trim()}
              className="px-2 py-0.5 rounded-lg bg-orange-500 hover:bg-orange-600 text-white font-medium text-[11px] flex items-center gap-1 transition-colors"
            >
              <RefreshCw size={11} className={loading ? 'animate-spin' : ''} />
              <span>Retry</span>
            </button>
            <button onClick={() => setError(null)} className="text-red-400 hover:text-white p-0.5 text-xs">
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Input */}
      <div className="space-y-3 bg-[#141418] p-3.5 rounded-2xl border border-white/[0.08]">
        <div>
          <label className="block text-xs font-medium text-zinc-300 mb-1">Research Subject / Hypothesis</label>
          <textarea
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="E.g., Quantum error correction breakthroughs in superconducting vs neutral atom qubits..."
            rows={3}
            className="w-full bg-[#18181D] border border-white/10 rounded-xl p-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-orange-500"
          />
        </div>

        {/* Quick Samples */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          {sampleTopics.map((st, i) => (
            <button
              key={i}
              onClick={() => {
                setTopic(st.text);
                if (st.lang) setLanguage(st.lang);
              }}
              className="text-[11px] whitespace-nowrap shrink-0 px-2.5 py-1 rounded-lg bg-white/5 text-zinc-300 hover:text-orange-400 transition-colors"
            >
              {st.label}
            </button>
          ))}
        </div>

        {/* Options */}
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div>
            <label className="block text-[11px] text-zinc-400 mb-1">Depth of Briefing</label>
            <select
              value={depth}
              onChange={(e) => setDepth(e.target.value)}
              className="w-full bg-[#18181D] border border-white/10 rounded-xl p-2 text-xs text-white focus:outline-none"
            >
              <option value="concise">Concise Brief (~3 key pillars)</option>
              <option value="comprehensive">Comprehensive Analytical Report</option>
              <option value="academic">Academic & Technical Deep-Dive</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] text-zinc-400 mb-1">Output Language</label>
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              className="w-full bg-[#18181D] border border-white/10 rounded-xl p-2 text-xs text-white focus:outline-none"
            >
              <option value="en">English</option>
              <option value="bn">বাংলা (Bengali)</option>
              <option value="ar">العربية (Arabic)</option>
            </select>
          </div>
        </div>

        <button
          onClick={handleResearch}
          disabled={loading || !topic.trim()}
          className="w-full py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 disabled:bg-zinc-800 disabled:text-zinc-500 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md shadow-orange-500/20"
        >
          {loading ? (
            <>
              <RefreshCw size={14} className="animate-spin" />
              <span>Investigating evidence & literature...</span>
            </>
          ) : (
            <>
              <Sparkles size={14} />
              <span>Conduct Structured Research</span>
            </>
          )}
        </button>
      </div>

      {/* Research Output */}
      {report && (
        <div className="space-y-2 bg-[#141418] p-3.5 rounded-2xl border border-orange-500/30 animate-in fade-in">
          <div className="flex items-center justify-between text-xs pb-1 border-b border-white/5">
            <span className="font-semibold text-orange-400">Research Briefing</span>
            <div className="flex items-center gap-1.5">
              <button onClick={copyResult} className="p-1.5 rounded-lg bg-white/5 text-zinc-300 hover:text-white" title="Copy Report">
                {copied ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
              </button>
              {onSendToChat && (
                <button
                  onClick={() => onSendToChat(`Research Brief:\n\n${report}`)}
                  className="p-1.5 rounded-lg bg-orange-500 text-white hover:bg-orange-600"
                  title="Send to Chat"
                >
                  <MessageSquare size={13} />
                </button>
              )}
            </div>
          </div>
          <div
            dir={language === 'ar' ? 'rtl' : 'ltr'}
            className={`text-xs text-zinc-200 whitespace-pre-line leading-relaxed ${language === 'ar' ? 'text-right' : 'text-left'}`}
          >
            {report}
          </div>
        </div>
      )}
    </div>
  );
};
