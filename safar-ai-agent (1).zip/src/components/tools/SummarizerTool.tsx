import React, { useState } from 'react';
import { AlignLeft, Copy, Check, Sparkles, RefreshCw, Volume2, ArrowLeft, MessageSquare } from 'lucide-react';
import { getApiUrl } from '../../services/apiConfig';

interface SummarizerToolProps {
  onBack: () => void;
  onSendToChat?: (text: string) => void;
}

export const SummarizerTool: React.FC<SummarizerToolProps> = ({ onBack, onSendToChat }) => {
  const [content, setContent] = useState<string>('');
  const [format, setFormat] = useState<string>('bullets');
  const [length, setLength] = useState<string>('medium');
  const [summary, setSummary] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSummarize = async () => {
    if (!content.trim()) return;
    setLoading(true);
    setError(null);

    try {
      const res = await fetch(getApiUrl('/api/tools/summarize'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content, format, length }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Summarization failed');
      setSummary(data.summary);
    } catch (err: any) {
      setError(err?.message || 'Failed to summarize content');
    } finally {
      setLoading(false);
    }
  };

  const copyResult = () => {
    navigator.clipboard.writeText(summary);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex-1 flex flex-col overflow-y-auto bg-[#0B0B0C] p-4 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-2 border-b border-white/[0.08]">
        <div className="flex items-center gap-2">
          <button onClick={onBack} className="p-1.5 rounded-xl bg-white/5 text-zinc-300 hover:text-white">
            <ArrowLeft size={16} />
          </button>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
              <AlignLeft size={15} className="text-orange-400" />
              <span>Safar Summarizer</span>
            </h3>
            <p className="text-[10px] text-zinc-400">Extract high-signal insights, briefs & action takeaways</p>
          </div>
        </div>
      </div>

      {error && (
        <div className="p-2.5 rounded-xl bg-red-950/40 border border-red-500/30 text-xs text-red-200 flex items-center justify-between gap-2 animate-in fade-in">
          <span>{error}</span>
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={handleSummarize}
              disabled={loading || !content.trim()}
              className="px-2 py-0.5 rounded-lg bg-orange-500 hover:bg-orange-600 text-white font-medium text-[11px] flex items-center gap-1 transition-colors"
            >
              <RefreshCw size={11} className={loading ? 'animate-spin' : ''} />
              <span>Retry</span>
            </button>
            <button onClick={() => setError(null)} className="text-red-400 hover:text-white p-0.5 text-xs">
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Input Form */}
      <div className="space-y-3 bg-[#141418] p-3.5 rounded-2xl border border-white/[0.08]">
        <div>
          <div className="flex items-center justify-between text-xs text-zinc-300 mb-1">
            <span>Paste Text or Article</span>
            <span className="text-[10px] text-zinc-500 font-mono">{content.length} chars</span>
          </div>
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Paste article, notes, research papers, or transcript here..."
            rows={5}
            className="w-full bg-[#18181D] border border-white/10 rounded-xl p-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-orange-500"
          />
        </div>

        {/* Options */}
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div>
            <label className="block text-[11px] text-zinc-400 mb-1">Summary Format</label>
            <select
              value={format}
              onChange={(e) => setFormat(e.target.value)}
              className="w-full bg-[#18181D] border border-white/10 rounded-xl p-2 text-xs text-white focus:outline-none"
            >
              <option value="bullets">Key Takeaways (Bullet Points)</option>
              <option value="executive">Executive Brief (High-level overview)</option>
              <option value="one-paragraph">Single Dense Paragraph</option>
              <option value="action-items">Action Items & Next Steps</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] text-zinc-400 mb-1">Detail Level</label>
            <select
              value={length}
              onChange={(e) => setLength(e.target.value)}
              className="w-full bg-[#18181D] border border-white/10 rounded-xl p-2 text-xs text-white focus:outline-none"
            >
              <option value="concise">Quick Snapshot (Fast read)</option>
              <option value="medium">Balanced (Recommended)</option>
              <option value="detailed">Thorough & Comprehensive</option>
            </select>
          </div>
        </div>

        <button
          onClick={handleSummarize}
          disabled={loading || !content.trim()}
          className="w-full py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 disabled:bg-zinc-800 disabled:text-zinc-500 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md shadow-orange-500/20"
        >
          {loading ? (
            <>
              <RefreshCw size={14} className="animate-spin" />
              <span>Synthesizing core insights...</span>
            </>
          ) : (
            <>
              <Sparkles size={14} />
              <span>Condense & Summarize</span>
            </>
          )}
        </button>
      </div>

      {/* Summary Output */}
      {summary && (
        <div className="space-y-2 bg-[#141418] p-3.5 rounded-2xl border border-orange-500/30 animate-in fade-in">
          <div className="flex items-center justify-between text-xs pb-1 border-b border-white/5">
            <span className="font-semibold text-orange-400">Executive Summary</span>
            <div className="flex items-center gap-1.5">
              <button onClick={copyResult} className="p-1.5 rounded-lg bg-white/5 text-zinc-300 hover:text-white" title="Copy Summary">
                {copied ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
              </button>
              {onSendToChat && (
                <button
                  onClick={() => onSendToChat(`Summary:\n\n${summary}`)}
                  className="p-1.5 rounded-lg bg-orange-500 text-white hover:bg-orange-600"
                  title="Discuss in Chat"
                >
                  <MessageSquare size={13} />
                </button>
              )}
            </div>
          </div>
          <div className="text-xs text-zinc-200 whitespace-pre-line leading-relaxed">
            {summary}
          </div>
        </div>
      )}
    </div>
  );
};
