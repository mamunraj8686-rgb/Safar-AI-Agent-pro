import React, { useState } from 'react';
import { PenTool, Copy, Check, Sparkles, RefreshCw, Volume2, MessageSquare, ArrowLeft } from 'lucide-react';
import { getApiUrl } from '../../services/apiConfig';

interface AIWriterToolProps {
  onBack: () => void;
  onSendToChat?: (text: string) => void;
}

export const AIWriterTool: React.FC<AIWriterToolProps> = ({ onBack, onSendToChat }) => {
  const [prompt, setPrompt] = useState<string>('');
  const [format, setFormat] = useState<string>('article');
  const [tone, setTone] = useState<string>('professional');
  const [length, setLength] = useState<string>('medium');
  const [language, setLanguage] = useState<string>('en');
  const [result, setResult] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    setError(null);

    try {
      const res = await fetch(getApiUrl('/api/tools/writer'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, format, tone, length, language }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Writing failed');
      setResult(data.result);
    } catch (err: any) {
      setError(err?.message || 'Failed to generate writing');
    } finally {
      setLoading(false);
    }
  };

  const copyResult = () => {
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const playSpeech = () => {
    if (!('speechSynthesis' in window) || !result) return;
    window.speechSynthesis.cancel();
    const cleanText = result.replace(/[*#`_\[\]]/g, '');
    const utter = new SpeechSynthesisUtterance(cleanText);
    if (language === 'bn') utter.lang = 'bn-BD';
    else if (language === 'ar') utter.lang = 'ar-SA';
    else utter.lang = 'en-US';
    window.speechSynthesis.speak(utter);
  };

  const quickPrompts = [
    { label: 'Executive Welcome Note', text: 'Welcome email for new team members joining our global engineering unit', format: 'email', tone: 'warm' },
    { label: 'বাংলা: ভ্রমণ ব্লগ', text: 'সুন্দরবন ও ম্যানগ্রোভ বনের প্রাকৃতিক সৌন্দর্য নিয়ে একটি সুন্দর ভ্রমণ ব্লগ', format: 'blog', language: 'bn' },
    { label: 'العربية: خطاب رسمي', text: 'رسالة شكر وتقدير رسمية لشركاء النجاح في مشروع التحول الرقمي', format: 'letter', language: 'ar' },
  ];

  return (
    <div className="flex-1 flex flex-col overflow-y-auto bg-[#0B0B0C] p-4 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-2 border-b border-white/[0.08]">
        <div className="flex items-center gap-2">
          <button onClick={onBack} className="p-1.5 rounded-xl bg-white/5 text-zinc-300 hover:text-white">
            <ArrowLeft size={16} />
          </button>
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-1.5">
              <PenTool size={15} className="text-orange-400" />
              <span>Safar AI Writer</span>
            </h3>
            <p className="text-[10px] text-zinc-400">Craft essays, correspondence, scripts & creative prose</p>
          </div>
        </div>
      </div>

      {error && (
        <div className="p-2.5 rounded-xl bg-red-950/40 border border-red-500/30 text-xs text-red-200 flex items-center justify-between gap-2 animate-in fade-in">
          <span>{error}</span>
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={handleGenerate}
              disabled={loading || !prompt.trim()}
              className="px-2 py-0.5 rounded-lg bg-orange-500 hover:bg-orange-600 text-white font-medium text-[11px] flex items-center gap-1 transition-colors"
            >
              <RefreshCw size={11} className={loading ? 'animate-spin' : ''} />
              <span>Retry</span>
            </button>
            <button onClick={() => setError(null)} className="text-red-400 hover:text-white p-0.5 text-xs">
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Input Form */}
      <div className="space-y-3 bg-[#141418] p-3.5 rounded-2xl border border-white/[0.08]">
        <div>
          <label className="block text-xs font-medium text-zinc-300 mb-1">Topic or Instructions</label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="What would you like Safar to write? (E.g. A compelling keynote speech on renewable energy in 2026...)"
            rows={3}
            className="w-full bg-[#18181D] border border-white/10 rounded-xl p-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-orange-500"
          />
        </div>

        {/* Quick Starters */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          {quickPrompts.map((qp, i) => (
            <button
              key={i}
              onClick={() => {
                setPrompt(qp.text);
                setFormat(qp.format || 'article');
                if (qp.language) setLanguage(qp.language);
              }}
              className="text-[11px] whitespace-nowrap shrink-0 px-2.5 py-1 rounded-lg bg-white/5 border border-white/5 text-zinc-300 hover:text-orange-400 transition-colors"
            >
              {qp.label}
            </button>
          ))}
        </div>

        {/* Options grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
          <div>
            <label className="block text-[11px] text-zinc-400 mb-1">Format</label>
            <select
              value={format}
              onChange={(e) => setFormat(e.target.value)}
              className="w-full bg-[#18181D] border border-white/10 rounded-xl p-2 text-xs text-white focus:outline-none"
            >
              <option value="article">Article / Essay</option>
              <option value="email">Formal Email</option>
              <option value="blog">Blog Post</option>
              <option value="story">Creative Story</option>
              <option value="letter">Official Letter</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] text-zinc-400 mb-1">Tone</label>
            <select
              value={tone}
              onChange={(e) => setTone(e.target.value)}
              className="w-full bg-[#18181D] border border-white/10 rounded-xl p-2 text-xs text-white focus:outline-none"
            >
              <option value="professional">Professional</option>
              <option value="persuasive">Persuasive</option>
              <option value="creative">Creative & Evocative</option>
              <option value="concise">Concise & Direct</option>
              <option value="academic">Academic</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] text-zinc-400 mb-1">Length</label>
            <select
              value={length}
              onChange={(e) => setLength(e.target.value)}
              className="w-full bg-[#18181D] border border-white/10 rounded-xl p-2 text-xs text-white focus:outline-none"
            >
              <option value="concise">Concise (~150 words)</option>
              <option value="medium">Medium (~350 words)</option>
              <option value="comprehensive">Comprehensive (~650+ words)</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] text-zinc-400 mb-1">Language</label>
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              className="w-full bg-[#18181D] border border-white/10 rounded-xl p-2 text-xs text-white focus:outline-none"
            >
              <option value="en">English</option>
              <option value="bn">বাংলা (Bengali)</option>
              <option value="ar">العربية (Arabic)</option>
            </select>
          </div>
        </div>

        <button
          onClick={handleGenerate}
          disabled={loading || !prompt.trim()}
          className="w-full py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 disabled:bg-zinc-800 disabled:text-zinc-500 text-white font-semibold text-xs flex items-center justify-center gap-1.5 transition-all shadow-md shadow-orange-500/20"
        >
          {loading ? (
            <>
              <RefreshCw size={14} className="animate-spin" />
              <span>Generating masterpiece...</span>
            </>
          ) : (
            <>
              <Sparkles size={14} />
              <span>Write with Safar AI</span>
            </>
          )}
        </button>
      </div>

      {/* Result Display */}
      {result && (
        <div className="space-y-2 bg-[#141418] p-3.5 rounded-2xl border border-orange-500/30 animate-in fade-in">
          <div className="flex items-center justify-between text-xs pb-1 border-b border-white/5">
            <span className="font-semibold text-orange-400">Generated Writing</span>
            <div className="flex items-center gap-1.5">
              <button onClick={playSpeech} className="p-1.5 rounded-lg bg-white/5 text-zinc-300 hover:text-white" title="Read Aloud">
                <Volume2 size={13} />
              </button>
              <button onClick={copyResult} className="p-1.5 rounded-lg bg-white/5 text-zinc-300 hover:text-white" title="Copy Text">
                {copied ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
              </button>
              {onSendToChat && (
                <button onClick={() => onSendToChat(result)} className="p-1.5 rounded-lg bg-orange-500 text-white hover:bg-orange-600" title="Send to Chat">
                  <MessageSquare size={13} />
                </button>
              )}
            </div>
          </div>
          <div
            dir={language === 'ar' ? 'rtl' : 'ltr'}
            className={`text-xs text-zinc-200 whitespace-pre-line leading-relaxed ${language === 'ar' ? 'text-right' : 'text-left'}`}
          >
            {result}
          </div>
        </div>
      )}
    </div>
  );
};
