import React from 'react';
import { Home, MessageSquare, Mic, Bot, GitBranch, History, Image as ImageIcon, Settings } from 'lucide-react';
import { NavigationTab, AppTheme } from '../types';

interface BottomNavBarProps {
  currentTab: NavigationTab;
  theme?: AppTheme;
  onSelectTab: (tab: NavigationTab) => void;
  onOpenSettings: () => void;
}

export const BottomNavBar: React.FC<BottomNavBarProps> = ({
  currentTab,
  theme = 'dark',
  onSelectTab,
  onOpenSettings,
}) => {
  const isLight = theme === 'light';

  const tabs = [
    { id: 'home' as NavigationTab, label: 'Home', icon: Home },
    { id: 'chat' as NavigationTab, label: 'Chat', icon: MessageSquare },
    { id: 'voice' as NavigationTab, label: 'Voice', icon: Mic },
    { id: 'flow' as NavigationTab, label: 'Flow', icon: GitBranch },
    { id: 'agents' as NavigationTab, label: 'Agents', icon: Bot },
    { id: 'images' as NavigationTab, label: 'Studio', icon: ImageIcon },
    { id: 'history' as NavigationTab, label: 'History', icon: History },
  ];

  return (
    <nav 
      aria-label="Bottom Navigation" 
      className={`shrink-0 backdrop-blur-xl border-t px-2 py-1.5 z-30 transition-colors ${
        isLight 
          ? 'bg-white/95 border-slate-200' 
          : 'bg-[#101013]/95 border-white/[0.08]'
      }`}
    >
      <div className="flex items-center justify-around max-w-lg mx-auto">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = currentTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onSelectTab(tab.id)}
              className={`flex flex-col items-center justify-center min-w-[48px] min-h-[44px] rounded-xl transition-all duration-200 relative ${
                isActive
                  ? 'text-orange-500 scale-105'
                  : isLight
                  ? 'text-slate-500 hover:text-slate-900 active:scale-95'
                  : 'text-zinc-400 hover:text-zinc-200 active:scale-95'
              }`}
            >
              {isActive && (
                <span className="absolute -top-1 w-5 h-0.5 rounded-full bg-orange-500 shadow-[0_0_8px_#F97316]"></span>
              )}
              <div
                className={`p-1 rounded-lg transition-colors ${
                  isActive ? 'bg-orange-500/10' : 'bg-transparent'
                }`}
              >
                <Icon size={19} strokeWidth={isActive ? 2.3 : 1.8} />
              </div>
              <span className={`text-[10px] mt-0.5 tracking-tight font-medium ${
                isActive ? 'text-orange-500 font-bold' : isLight ? 'text-slate-500' : 'text-zinc-400'
              }`}>
                {tab.label}
              </span>
            </button>
          );
        })}

        {/* Quick Settings trigger */}
        <button
          onClick={onOpenSettings}
          className={`flex flex-col items-center justify-center min-w-[44px] min-h-[44px] rounded-xl transition-all duration-200 ${
            currentTab === 'settings' 
              ? 'text-orange-500 scale-105 font-bold' 
              : isLight 
              ? 'text-slate-500 hover:text-slate-900' 
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
          title="Settings"
        >
          <div className={`p-1 rounded-lg ${currentTab === 'settings' ? 'bg-orange-500/10' : ''}`}>
            <Settings size={18} strokeWidth={currentTab === 'settings' ? 2.3 : 1.8} />
          </div>
          <span className={`text-[10px] mt-0.5 tracking-tight font-medium ${
            currentTab === 'settings' ? 'text-orange-500 font-bold' : isLight ? 'text-slate-500' : 'text-zinc-400'
          }`}>
            Settings
          </span>
        </button>
      </div>
    </nav>
  );
};
