import React, { useState, useRef } from 'react';
import { 
  Sparkles, 
  Image as ImageIcon, 
  Wand2, 
  Download, 
  Upload, 
  RefreshCw, 
  Maximize2, 
  Check, 
  Copy, 
  Sliders, 
  Layers, 
  X,
  MessageSquare,
  AlertCircle
} from 'lucide-react';
import { GeneratedImageItem } from '../types';
import { getApiUrl } from '../services/apiConfig';

interface ImageStudioScreenProps {
  initialPrompt?: string;
  onSendToChat?: (imageUrl: string, prompt: string) => void;
  onBackToHome?: () => void;
}

export const ImageStudioScreen: React.FC<ImageStudioScreenProps> = ({
  initialPrompt = '',
  onSendToChat,
  onBackToHome,
}) => {
  const [mode, setMode] = useState<'create' | 'edit'>('create');
  const [prompt, setPrompt] = useState<string>(initialPrompt);
  const [editPrompt, setEditPrompt] = useState<string>('');
  
  // Model selection: gemini-nano-banana-2.1 and gemini-3-pro-image-preview
  const [selectedModel, setSelectedModel] = useState<string>('gemini-nano-banana-2.1');
  
  // Resolution affordance: 1K, 2K, 4K
  const [imageSize, setImageSize] = useState<'1K' | '2K' | '4K'>('2K');
  
  // Aspect ratio
  const [aspectRatio, setAspectRatio] = useState<string>('1:1');
  
  // Style preset
  const [selectedStyle, setSelectedStyle] = useState<string>('cinematic');
  
  // Image to edit (base64)
  const [inputImageBase64, setInputImageBase64] = useState<string | null>(null);
  
  // State
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [currentResult, setCurrentResult] = useState<GeneratedImageItem | null>(null);
  const [recentCreations, setRecentCreations] = useState<GeneratedImageItem[]>([
    {
      id: 'demo-1',
      prompt: 'Futuristic solar observatory on Martian dunes at dawn, cinematic lighting, 4K photorealistic',
      imageUrl: 'https://images.unsplash.com/photo-1541185933-ef5d8ed016c2?auto=format&fit=crop&w=1000&q=80',
      model: 'gemini-nano-banana-2.1',
      size: '4K',
      aspectRatio: '16:9',
      timestamp: Date.now() - 3600000,
    },
    {
      id: 'demo-2',
      prompt: 'Minimalist obsidian kinetic sculpture with warm amber refraction core',
      imageUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1000&q=80',
      model: 'gemini-3-pro-image-preview',
      size: '2K',
      aspectRatio: '1:1',
      timestamp: Date.now() - 7200000,
    }
  ]);
  const [copied, setCopied] = useState<boolean>(false);
  const [fullscreenImage, setFullscreenImage] = useState<GeneratedImageItem | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const stylePresets = [
    { id: 'cinematic', label: 'Cinematic' },
    { id: 'photorealistic', label: 'Photoreal' },
    { id: 'cyberpunk', label: 'Cyberpunk' },
    { id: 'minimalist', label: 'Minimalist' },
    { id: 'architectural', label: 'Architectural' },
    { id: 'none', label: 'Raw Prompt' },
  ];

  const aspectRatios = [
    { id: '1:1', label: '1:1 Square' },
    { id: '16:9', label: '16:9 Cinema' },
    { id: '9:16', label: '9:16 Mobile' },
    { id: '4:3', label: '4:3 Standard' },
    { id: '3:4', label: '3:4 Portrait' },
  ];

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setError('Please select a valid image file');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setInputImageBase64(reader.result as string);
      setMode('edit');
      setError(null);
    };
    reader.readAsDataURL(file);
  };

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      setError('Please provide an image prompt');
      return;
    }

    setIsGenerating(true);
    setError(null);

    try {
      const res = await fetch(getApiUrl('/api/image/generate'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: prompt.trim(),
          aspectRatio,
          imageSize,
          model: selectedModel,
          style: selectedStyle,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Image generation failed');
      }

      const newItem: GeneratedImageItem = {
        id: `img-${Date.now()}`,
        prompt: prompt.trim(),
        imageUrl: data.imageUrl,
        model: data.model || selectedModel,
        size: imageSize,
        aspectRatio,
        timestamp: Date.now(),
      };

      setCurrentResult(newItem);
      setRecentCreations(prev => [newItem, ...prev]);
    } catch (err: any) {
      console.error(err);
      setError(err?.message || 'Failed to generate image. Please check API credentials or try another model.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleEdit = async () => {
    if (!inputImageBase64) {
      setError('Please upload or select an image to edit');
      return;
    }
    if (!editPrompt.trim()) {
      setError('Please describe the modifications you wish to make');
      return;
    }

    setIsGenerating(true);
    setError(null);

    try {
      const res = await fetch(getApiUrl('/api/image/edit'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          base64Image: inputImageBase64,
          prompt: editPrompt.trim(),
          model: selectedModel,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Image modification failed');
      }

      const newItem: GeneratedImageItem = {
        id: `img-edit-${Date.now()}`,
        prompt: `Edited: ${editPrompt.trim()}`,
        imageUrl: data.imageUrl,
        model: data.model || selectedModel,
        size: imageSize,
        aspectRatio,
        timestamp: Date.now(),
        isEdit: true,
      };

      setCurrentResult(newItem);
      setRecentCreations(prev => [newItem, ...prev]);
    } catch (err: any) {
      console.error(err);
      setError(err?.message || 'Failed to edit image');
    } finally {
      setIsGenerating(false);
    }
  };

  const copyPromptText = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadImage = (url: string, filename = 'safar-creation.png') => {
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="flex-1 flex flex-col overflow-y-auto bg-[#0B0B0C] px-4 py-4 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-2 border-b border-white/[0.08]">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-white tracking-tight">Safar Studio</h2>
            <span className="text-[10px] font-mono uppercase bg-orange-500/10 text-orange-400 border border-orange-500/30 px-1.5 py-0.5 rounded">
              High-Fidelity
            </span>
          </div>
          <p className="text-xs text-zinc-400 mt-0.5">
            Create with Gemini 3 Pro & Nano Banana 2.1 in 1K, 2K, or 4K.
          </p>
        </div>

        {/* Mode Toggle: Create vs Edit */}
        <div className="flex items-center p-1 rounded-xl bg-[#141418] border border-white/10 text-xs">
          <button
            onClick={() => setMode('create')}
            className={`px-3 py-1 rounded-lg font-medium transition-all ${
              mode === 'create'
                ? 'bg-orange-500 text-white shadow-sm'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            Create
          </button>
          <button
            onClick={() => setMode('edit')}
            className={`px-3 py-1 rounded-lg font-medium transition-all ${
              mode === 'edit'
                ? 'bg-orange-500 text-white shadow-sm'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            Edit Image
          </button>
        </div>
      </div>

      {/* Error Banner with Retry */}
      {error && (
        <div className="p-3 rounded-xl bg-red-950/40 border border-red-500/30 text-xs text-red-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2 animate-in fade-in">
          <div className="flex items-start gap-2">
            <AlertCircle size={15} className="text-red-400 shrink-0 mt-0.5" />
            <span className="leading-snug">{error}</span>
          </div>
          <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
            <button
              onClick={mode === 'create' ? handleGenerate : handleEdit}
              disabled={isGenerating}
              className="px-2.5 py-1 rounded-lg bg-orange-500 hover:bg-orange-600 disabled:opacity-50 text-white font-medium text-[11px] flex items-center gap-1 transition-colors"
            >
              <RefreshCw size={11} className={isGenerating ? 'animate-spin' : ''} />
              <span>Retry</span>
            </button>
            <button onClick={() => setError(null)} className="text-red-400 hover:text-white p-1">
              <X size={14} />
            </button>
          </div>
        </div>
      )}

      {/* CREATE MODE CONTROLS */}
      {mode === 'create' && (
        <div className="space-y-3 bg-[#121215] p-3.5 rounded-2xl border border-white/[0.08]">
          {/* Prompt textarea */}
          <div>
            <label className="block text-xs font-medium text-zinc-300 mb-1.5 flex items-center justify-between">
              <span>Text Prompt</span>
              <span className="text-[11px] text-zinc-500">Be descriptive with lighting & textures</span>
            </label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="E.g., An ancient cosmic observatory in the dunes under twin amber moons, cinematic lighting, ultra-detailed..."
              rows={3}
              className="w-full bg-[#18181D] border border-white/10 rounded-xl p-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-orange-500/50 resize-none"
            />
          </div>

          {/* Model Selection */}
          <div className="space-y-1.5">
            <label className="block text-xs font-medium text-zinc-300">
              AI Generation Engine
            </label>
            <div className="grid grid-cols-3 gap-1.5">
              <button
                type="button"
                onClick={() => setSelectedModel('gemini-3.1-flash-lite-image')}
                className={`p-2 rounded-xl text-left border transition-all text-xs ${
                  selectedModel === 'gemini-3.1-flash-lite-image'
                    ? 'border-orange-500/80 bg-orange-500/10 text-white'
                    : 'border-white/10 bg-[#16161A] text-zinc-400 hover:border-white/20'
                }`}
              >
                <div className="font-semibold text-white truncate">Flash Lite</div>
                <div className="text-[10px] text-zinc-400 mt-0.5 line-clamp-1">Fast & Standard</div>
              </button>

              <button
                type="button"
                onClick={() => setSelectedModel('gemini-nano-banana-2.1')}
                className={`p-2 rounded-xl text-left border transition-all text-xs ${
                  selectedModel === 'gemini-nano-banana-2.1'
                    ? 'border-orange-500/80 bg-orange-500/10 text-white'
                    : 'border-white/10 bg-[#16161A] text-zinc-400 hover:border-white/20'
                }`}
              >
                <div className="font-semibold text-white truncate">Nano Banana 2.1</div>
                <div className="text-[10px] text-zinc-400 mt-0.5 line-clamp-1">High-Res 1K-4K</div>
              </button>

              <button
                type="button"
                onClick={() => setSelectedModel('gemini-3-pro-image')}
                className={`p-2 rounded-xl text-left border transition-all text-xs ${
                  selectedModel === 'gemini-3-pro-image'
                    ? 'border-orange-500/80 bg-orange-500/10 text-white'
                    : 'border-white/10 bg-[#16161A] text-zinc-400 hover:border-white/20'
                }`}
              >
                <div className="font-semibold text-white truncate">3 Pro Image</div>
                <div className="text-[10px] text-zinc-400 mt-0.5 line-clamp-1">Flagship Detail</div>
              </button>
            </div>
          </div>

          {/* Size Affordance: 1K, 2K, 4K (EXPLICIT USER REQUIREMENT) */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-medium text-zinc-300 flex items-center gap-1.5">
                <Sliders size={13} className="text-orange-400" />
                <span>Image Resolution Affordance</span>
              </label>
              <span className="text-[11px] font-mono text-orange-400 font-semibold">{imageSize} Resolution</span>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {(['1K', '2K', '4K'] as const).map((size) => (
                <button
                  key={size}
                  type="button"
                  onClick={() => setImageSize(size)}
                  className={`py-2 px-3 rounded-xl text-center border font-mono text-xs font-semibold transition-all ${
                    imageSize === size
                      ? 'bg-orange-500 text-white border-orange-500 shadow-md shadow-orange-500/25'
                      : 'bg-[#18181D] text-zinc-300 border-white/10 hover:border-white/20'
                  }`}
                >
                  {size}
                  <span className="block text-[9px] font-normal text-zinc-400 mt-0.5">
                    {size === '1K' ? '1024px' : size === '2K' ? '2048px' : '4096px Ultra'}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Aspect Ratio & Style */}
          <div className="grid grid-cols-2 gap-2 pt-1">
            {/* Aspect */}
            <div>
              <label className="block text-xs font-medium text-zinc-300 mb-1">Aspect Ratio</label>
              <select
                value={aspectRatio}
                onChange={(e) => setAspectRatio(e.target.value)}
                className="w-full bg-[#18181D] border border-white/10 rounded-xl p-2 text-xs text-white focus:outline-none focus:border-orange-500"
              >
                {aspectRatios.map(r => (
                  <option key={r.id} value={r.id}>{r.label}</option>
                ))}
              </select>
            </div>

            {/* Style */}
            <div>
              <label className="block text-xs font-medium text-zinc-300 mb-1">Aesthetic Style</label>
              <select
                value={selectedStyle}
                onChange={(e) => setSelectedStyle(e.target.value)}
                className="w-full bg-[#18181D] border border-white/10 rounded-xl p-2 text-xs text-white focus:outline-none focus:border-orange-500"
              >
                {stylePresets.map(s => (
                  <option key={s.id} value={s.id}>{s.label}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Generate Button */}
          <button
            onClick={handleGenerate}
            disabled={isGenerating || !prompt.trim()}
            className={`w-full py-2.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all mt-2 ${
              isGenerating || !prompt.trim()
                ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                : 'bg-orange-500 hover:bg-orange-600 text-white shadow-lg shadow-orange-500/25 active:scale-98'
            }`}
          >
            {isGenerating ? (
              <>
                <RefreshCw size={14} className="animate-spin" />
                <span>Synthesizing in {imageSize} ({selectedModel})...</span>
              </>
            ) : (
              <>
                <Wand2 size={14} />
                <span>Generate {imageSize} Image with Safar AI</span>
              </>
            )}
          </button>
        </div>
      )}

      {/* EDIT MODE CONTROLS */}
      {mode === 'edit' && (
        <div className="space-y-3 bg-[#121215] p-3.5 rounded-2xl border border-white/[0.08]">
          {/* Source Image Selector */}
          <div>
            <label className="block text-xs font-medium text-zinc-300 mb-1.5 flex items-center justify-between">
              <span>Source Image to Edit</span>
              <span className="text-[10px] font-mono text-orange-400">gemini-nano-banana-2.1</span>
            </label>

            {inputImageBase64 ? (
              <div className="relative rounded-xl overflow-hidden border border-white/10 bg-black aspect-video flex items-center justify-center group">
                <img
                  src={inputImageBase64}
                  alt="Source for editing"
                  className="max-h-full max-w-full object-contain"
                />
                <button
                  type="button"
                  onClick={() => setInputImageBase64(null)}
                  className="absolute top-2 right-2 p-1.5 rounded-lg bg-black/70 text-white hover:bg-red-600 transition-colors"
                  title="Remove Image"
                >
                  <X size={14} />
                </button>
              </div>
            ) : (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-white/15 rounded-xl p-4 text-center cursor-pointer hover:border-orange-500/50 bg-[#16161A] transition-colors"
              >
                <Upload size={22} className="mx-auto text-zinc-400 mb-1.5" />
                <p className="text-xs font-medium text-zinc-300">Tap to upload an image from device</p>
                <p className="text-[10px] text-zinc-500 mt-0.5">PNG, JPG, or WEBP up to 25MB</p>
              </div>
            )}

            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileUpload}
              className="hidden"
            />
          </div>

          {/* Edit Prompt Instructions */}
          <div>
            <label className="block text-xs font-medium text-zinc-300 mb-1">
              Edit Instructions
            </label>
            <textarea
              value={editPrompt}
              onChange={(e) => setEditPrompt(e.target.value)}
              placeholder="Describe modifications: E.g., 'Add a glowing warm amber compass in the center' or 'Change sky to a dramatic sunset over dunes'..."
              rows={3}
              className="w-full bg-[#18181D] border border-white/10 rounded-xl p-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-orange-500/50 resize-none"
            />
          </div>

          <button
            onClick={handleEdit}
            disabled={isGenerating || !inputImageBase64 || !editPrompt.trim()}
            className={`w-full py-2.5 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all mt-2 ${
              isGenerating || !inputImageBase64 || !editPrompt.trim()
                ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                : 'bg-orange-500 hover:bg-orange-600 text-white shadow-lg shadow-orange-500/25 active:scale-98'
            }`}
          >
            {isGenerating ? (
              <>
                <RefreshCw size={14} className="animate-spin" />
                <span>Modifying Image with Safar AI...</span>
              </>
            ) : (
              <>
                <Wand2 size={14} />
                <span>Apply Edits with Nano Banana 2.1</span>
              </>
            )}
          </button>
        </div>
      )}

      {/* Latest Creation Card */}
      {currentResult && (
        <div className="space-y-2 bg-[#141418] p-3 rounded-2xl border border-orange-500/30">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-orange-400 flex items-center gap-1">
              <Sparkles size={13} />
              Generated {currentResult.size} Result
            </span>
            <span className="text-[10px] font-mono text-zinc-400">{currentResult.model}</span>
          </div>

          <div className="relative rounded-xl overflow-hidden bg-black border border-white/10 group">
            <img
              src={currentResult.imageUrl}
              alt={currentResult.prompt}
              className="w-full h-auto object-cover max-h-[340px]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-3 justify-between">
              <button
                onClick={() => setFullscreenImage(currentResult)}
                className="p-1.5 rounded-lg bg-black/60 text-white hover:bg-orange-500 transition-colors"
                title="Fullscreen Inspection"
              >
                <Maximize2 size={15} />
              </button>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => downloadImage(currentResult.imageUrl)}
                  className="p-1.5 rounded-lg bg-black/60 text-white hover:bg-orange-500 transition-colors"
                  title="Download Image"
                >
                  <Download size={15} />
                </button>
                {onSendToChat && (
                  <button
                    onClick={() => onSendToChat(currentResult.imageUrl, currentResult.prompt)}
                    className="p-1.5 rounded-lg bg-orange-500 text-white hover:bg-orange-600 transition-colors flex items-center gap-1 text-[11px] font-medium"
                    title="Discuss in Chat"
                  >
                    <MessageSquare size={13} />
                    Chat
                  </button>
                )}
              </div>
            </div>
          </div>

          <div className="text-xs text-zinc-300 font-sans line-clamp-2">
            "{currentResult.prompt}"
          </div>

          <div className="flex items-center gap-2 pt-1">
            <button
              onClick={() => {
                setInputImageBase64(currentResult.imageUrl);
                setMode('edit');
                setEditPrompt('');
              }}
              className="flex-1 py-1.5 rounded-lg bg-white/5 border border-white/10 text-[11px] text-zinc-300 hover:text-white hover:border-orange-500/40 transition-colors flex items-center justify-center gap-1"
            >
              <Layers size={13} />
              Use as Edit Source
            </button>
            <button
              onClick={() => copyPromptText(currentResult.prompt)}
              className="py-1.5 px-3 rounded-lg bg-white/5 border border-white/10 text-[11px] text-zinc-300 hover:text-white transition-colors flex items-center gap-1"
            >
              {copied ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
              {copied ? 'Copied' : 'Copy'}
            </button>
          </div>
        </div>
      )}

      {/* Gallery of Creations */}
      <div className="space-y-2 pt-2">
        <h3 className="text-xs font-semibold text-zinc-300 flex items-center justify-between">
          <span>Gallery & History</span>
          <span className="text-[10px] text-zinc-500">{recentCreations.length} creations</span>
        </h3>

        <div className="grid grid-cols-2 gap-2">
          {recentCreations.map((item) => (
            <div
              key={item.id}
              onClick={() => setFullscreenImage(item)}
              className="group relative rounded-xl overflow-hidden bg-[#141417] border border-white/10 cursor-pointer aspect-square hover:border-orange-500/50 transition-all"
            >
              <img
                src={item.imageUrl}
                alt={item.prompt}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-90 p-2 flex flex-col justify-end">
                <span className="text-[9px] font-mono uppercase text-orange-400">
                  {item.size || '2K'} · {item.model.includes('banana') ? 'Banana 2.1' : '3 Pro'}
                </span>
                <p className="text-[10px] text-white line-clamp-1 mt-0.5">
                  {item.prompt}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Fullscreen Inspection Lightbox */}
      {fullscreenImage && (
        <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex flex-col p-4 animate-in fade-in duration-200">
          <div className="flex items-center justify-between pb-3 text-white">
            <div className="text-xs">
              <span className="font-mono text-orange-400 font-bold">{fullscreenImage.size} Resolution</span>
              <span className="mx-2 text-zinc-600">·</span>
              <span className="text-zinc-400">{fullscreenImage.model}</span>
            </div>
            <button
              onClick={() => setFullscreenImage(null)}
              className="p-1.5 rounded-full bg-white/10 text-white hover:bg-white/20"
            >
              <X size={18} />
            </button>
          </div>

          <div className="flex-1 flex items-center justify-center overflow-hidden py-2">
            <img
              src={fullscreenImage.imageUrl}
              alt={fullscreenImage.prompt}
              className="max-h-full max-w-full object-contain rounded-xl shadow-2xl"
            />
          </div>

          <div className="pt-3 border-t border-white/10 flex items-center justify-between text-xs">
            <p className="text-zinc-300 text-xs line-clamp-2 max-w-md">
              {fullscreenImage.prompt}
            </p>
            <div className="flex items-center gap-2">
              <button
                onClick={() => downloadImage(fullscreenImage.imageUrl)}
                className="px-3 py-1.5 rounded-lg bg-orange-500 text-white font-medium hover:bg-orange-600 transition-colors flex items-center gap-1.5 text-xs"
              >
                <Download size={14} />
                Download
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
