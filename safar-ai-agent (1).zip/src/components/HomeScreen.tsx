import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  ArrowUp, 
  Mic, 
  Compass, 
  Code2, 
  ListChecks, 
  Image as ImageIcon, 
  Radio, 
  Settings,
  Flame,
  ChevronRight,
  Users,
  GitBranch
} from 'lucide-react';
import { SmartAgent, NavigationTab, WorkflowPresetId } from '../types';
import { SMART_AGENTS } from '../data/agents';

interface HomeScreenProps {
  onNavigate: (tab: NavigationTab) => void;
  onStartChatWithPrompt: (prompt: string, agentId?: string) => void;
  onOpenVoice: () => void;
  onOpenImageStudio: (initialPrompt?: string) => void;
  onOpenSettings: () => void;
  onOpenFlow?: (presetId?: WorkflowPresetId) => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  onNavigate,
  onStartChatWithPrompt,
  onOpenVoice,
  onOpenImageStudio,
  onOpenSettings,
  onOpenFlow,
}) => {
  const [greeting, setGreeting] = useState<string>('Welcome, Traveler');
  const [chatPrompt, setChatPrompt] = useState<string>('');
  const [activeHeroMode, setActiveHeroMode] = useState<'voice' | 'travel' | 'tasks' | 'studio'>('voice');
  const [isSummoning, setIsSummoning] = useState<boolean>(false);

  useEffect(() => {
    const hour = new Date().getHours();
    if (hour >= 5 && hour < 12) {
      setGreeting('Good morning, Traveler');
    } else if (hour >= 12 && hour < 17) {
      setGreeting('Good afternoon, Traveler');
    } else if (hour >= 17 && hour < 22) {
      setGreeting('Good evening, Traveler');
    } else {
      setGreeting('Good night, Explorer');
    }
  }, []);

  const handleSendPrompt = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatPrompt.trim()) return;
    onStartChatWithPrompt(chatPrompt.trim());
    setChatPrompt('');
  };

  const handleHeroButtonClick = () => {
    setIsSummoning(true);
    setTimeout(() => {
      setIsSummoning(false);
      if (activeHeroMode === 'voice') {
        onOpenVoice();
      } else if (activeHeroMode === 'travel') {
        onStartChatWithPrompt('I need your help planning an unforgettable journey. Where should we begin?', 'safar-travel');
      } else if (activeHeroMode === 'tasks') {
        onStartChatWithPrompt('Break down my top priorities and create an actionable milestone roadmap.', 'safar-task');
      } else if (activeHeroMode === 'studio') {
        onOpenImageStudio();
      }
    }, 350);
  };

  const promptChips = [
    { label: 'Plan a 5-day Kyoto hidden gem tour', agentId: 'safar-travel' },
    { label: 'Deconstruct a 30-day mobile app roadmap', agentId: 'safar-task' },
    { label: 'Generate a 4K neon desert sanctuary', isImage: true },
    { label: 'Debug React performance re-renders', agentId: 'safar-code' },
  ];

  return (
    <div className="flex-1 overflow-y-auto px-4 py-5 flex flex-col justify-between scroll-smooth bg-[#0B0B0C]">
      {/* Top Header & Branding */}
      <div className="space-y-4">
        <header className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {/* Safar Emblem */}
            <div className="relative w-11 h-11 rounded-2xl bg-gradient-to-br from-zinc-800 to-black p-0.5 border border-white/10 shadow-lg flex items-center justify-center">
              <div className="w-full h-full rounded-[14px] bg-[#121214] flex items-center justify-center relative overflow-hidden">
                <span className="absolute inset-0 bg-gradient-to-tr from-orange-500/20 to-transparent"></span>
                <Compass className="w-6 h-6 text-orange-500 relative z-10 animate-pulse" />
              </div>
            </div>

            {/* Brand Title */}
            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="text-xl font-extrabold tracking-tight text-white font-sans">
                  SAFAR
                </h1>
                <span className="text-[10px] font-mono tracking-widest text-orange-400 font-semibold uppercase px-1.5 py-0.5 rounded bg-orange-500/10 border border-orange-500/20">
                  AI AGENT
                </span>
              </div>
              <div className="flex items-center gap-1.5 text-xs text-zinc-400">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                <span>Fleet v3.8</span>
                <span aria-hidden="true">·</span>
                <span>Autonomous Ready</span>
              </div>
            </div>
          </div>

          {/* Quick Header Action */}
          <div className="flex items-center gap-2">
            <button
              onClick={onOpenVoice}
              className="w-9 h-9 rounded-xl bg-[#18181B] border border-white/10 flex items-center justify-center text-zinc-300 hover:text-orange-400 hover:border-orange-500/40 transition-colors"
              title="Quick Voice Session"
              aria-label="Open Voice Session"
            >
              <Radio size={16} className="text-orange-400" />
            </button>
            <button
              onClick={onOpenSettings}
              className="w-9 h-9 rounded-xl bg-[#18181B] border border-white/10 flex items-center justify-center text-zinc-300 hover:text-white hover:border-white/20 transition-colors"
              title="Settings"
              aria-label="Settings"
            >
              <Settings size={16} />
            </button>
          </div>
        </header>

        {/* Welcome Message */}
        <div className="pt-2">
          <p className="text-xs font-mono uppercase tracking-widest text-orange-500 font-medium">
            Intelligence in Motion
          </p>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mt-1 text-balance">
            {greeting}
          </h2>
          <p className="text-sm text-zinc-400 mt-1 max-w-sm leading-relaxed">
            Where shall we journey today? Your autonomous multi-agent intelligence is ready to explore, code, and create.
          </p>
        </div>
      </div>

      {/* CENTERPIECE: ONE LARGE AI ACTION BUTTON */}
      <section aria-label="Primary AI Action Core" className="my-6 flex flex-col items-center justify-center relative">
        {/* Ambient Radar Rings */}
        <div className="relative flex items-center justify-center">
          <div className="absolute w-52 h-52 rounded-full border border-orange-500/20 radar-ring pointer-events-none"></div>
          <div className="absolute w-64 h-64 rounded-full border border-orange-500/10 radar-ring pointer-events-none" style={{ animationDelay: '0.8s' }}></div>

          {/* Main Hero Glowing Button */}
          <button
            onClick={handleHeroButtonClick}
            className={`w-36 h-36 rounded-full bg-gradient-to-b from-[#1E1E24] via-[#141417] to-[#0D0D0E] border-2 border-orange-500/50 p-2 relative group flex flex-col items-center justify-center transition-all duration-300 active:scale-95 cursor-pointer shadow-[0_0_50px_rgba(249,115,22,0.35)] ${
              isSummoning ? 'scale-90 ring-4 ring-orange-500' : 'hover:border-orange-400'
            }`}
            aria-label="Activate Safar AI Core"
          >
            {/* Inner Glowing Core */}
            <div className="w-full h-full rounded-full bg-[#121215] flex flex-col items-center justify-center relative overflow-hidden border border-white/10 group-hover:bg-[#18181D]">
              <div className="absolute inset-0 bg-radial from-orange-500/25 via-transparent to-transparent opacity-80 group-hover:opacity-100 transition-opacity"></div>
              
              {/* Dynamic Icon based on active mode */}
              <div className="relative z-10 w-11 h-11 rounded-full bg-orange-500/15 flex items-center justify-center border border-orange-500/30 text-orange-400 mb-1.5 group-hover:scale-110 transition-transform">
                {activeHeroMode === 'voice' && <Mic size={22} className="text-orange-400 animate-pulse" />}
                {activeHeroMode === 'travel' && <Compass size={22} className="text-orange-400" />}
                {activeHeroMode === 'tasks' && <ListChecks size={22} className="text-orange-400" />}
                {activeHeroMode === 'studio' && <Sparkles size={22} className="text-orange-400" />}
              </div>

              <span className="relative z-10 text-[11px] font-mono tracking-wider font-bold text-white uppercase">
                {activeHeroMode === 'voice' ? 'Talk Live' : activeHeroMode === 'travel' ? 'Plan Trip' : activeHeroMode === 'tasks' ? 'Sequencer' : 'Image 4K'}
              </span>
              <span className="relative z-10 text-[9px] text-orange-400 font-medium">
                Tap to Summon
              </span>
            </div>
          </button>
        </div>

        {/* Hero Mode Selector Dial */}
        <div className="mt-5 flex items-center gap-1.5 p-1 rounded-full bg-[#141418] border border-white/10 text-xs shadow-inner">
          <button
            onClick={() => setActiveHeroMode('voice')}
            className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
              activeHeroMode === 'voice'
                ? 'bg-orange-500 text-white shadow-sm'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            Live Voice
          </button>
          <button
            onClick={() => setActiveHeroMode('travel')}
            className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
              activeHeroMode === 'travel'
                ? 'bg-orange-500 text-white shadow-sm'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            Safar Voyage
          </button>
          <button
            onClick={() => setActiveHeroMode('tasks')}
            className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
              activeHeroMode === 'tasks'
                ? 'bg-orange-500 text-white shadow-sm'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            Task Map
          </button>
          <button
            onClick={() => setActiveHeroMode('studio')}
            className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
              activeHeroMode === 'studio'
                ? 'bg-orange-500 text-white shadow-sm'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            Studio
          </button>
        </div>
      </section>

      {/* Agent Team Swarm Feature Banner */}
      <div 
        onClick={() => onNavigate('agents')}
        className="cursor-pointer p-3.5 rounded-2xl bg-gradient-to-r from-[#201810] via-[#16161B] to-[#121215] border border-orange-500/30 hover:border-orange-500/60 transition-all mb-3 flex items-center justify-between group shadow-lg shadow-orange-500/5"
      >
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-orange-500/20 text-orange-400 border border-orange-500/30 flex items-center justify-center font-bold group-hover:scale-105 transition-transform">
            ⚡
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h3 className="text-xs font-bold text-white group-hover:text-orange-300 transition-colors">
                Safar 5-Agent Swarm Team
              </h3>
              <span className="text-[9px] font-mono uppercase bg-orange-500/20 text-orange-400 px-1.5 py-0.2 rounded font-semibold">
                Multi-Agent
              </span>
            </div>
            <p className="text-[11px] text-zinc-400 mt-0.5">
              Coordinator · Research · Planning · Writing · Review
            </p>
          </div>
        </div>

        <div className="flex items-center text-orange-400 text-xs font-semibold group-hover:translate-x-1 transition-transform">
          <span>Deploy</span>
          <ChevronRight size={14} />
        </div>
      </div>

      {/* Smart Agents Quick Grid */}
      <section aria-label="Smart Agent Fleet" className="space-y-2 mb-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-zinc-300">
            <Flame size={14} className="text-orange-500" />
            <span>Specialized Autonomous Agents</span>
          </div>
          <button
            onClick={() => onNavigate('agents')}
            className="text-xs text-orange-400 hover:text-orange-300 font-medium flex items-center gap-0.5"
          >
            View all ({SMART_AGENTS.length})
            <ChevronRight size={13} />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-2">
          {SMART_AGENTS.slice(0, 4).map((agent: SmartAgent) => {
            const getIcon = () => {
              switch (agent.icon) {
                case 'Compass': return Compass;
                case 'ListChecks': return ListChecks;
                case 'Code2': return Code2;
                default: return Sparkles;
              }
            };
            const Icon = getIcon();

            return (
              <button
                key={agent.id}
                onClick={() => onStartChatWithPrompt(`Hello ${agent.name}, let's start a session.`, agent.id)}
                className="p-3 rounded-2xl bg-[#141417] border border-white/[0.08] hover:border-orange-500/40 text-left transition-all group flex flex-col justify-between hover:bg-[#18181C]"
              >
                <div className="flex items-center justify-between w-full mb-2">
                  <div className="w-8 h-8 rounded-xl bg-orange-500/10 border border-orange-500/20 flex items-center justify-center text-orange-400 group-hover:scale-105 transition-transform">
                    <Icon size={16} />
                  </div>
                  <span className="text-[10px] font-mono text-zinc-500 group-hover:text-zinc-400">
                    {agent.badge}
                  </span>
                </div>
                <div>
                  <h4 className="text-xs font-semibold text-white group-hover:text-orange-300 transition-colors">
                    {agent.name}
                  </h4>
                  <p className="text-[11px] text-zinc-400 line-clamp-1 mt-0.5">
                    {agent.title}
                  </p>
                </div>
              </button>
            );
          })}
        </div>

        {/* Safar Flow Automation Featured Card */}
        <div className="pt-2">
          <div className="p-3.5 rounded-2xl bg-gradient-to-r from-[#17141E] via-[#15131A] to-[#101014] border border-orange-500/35 hover:border-orange-500/60 transition-all shadow-lg space-y-2.5">
            <button
              onClick={() => onOpenFlow ? onOpenFlow('business_writing') : onNavigate('flow')}
              className="w-full text-left group flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-orange-500/15 border border-orange-500/30 text-orange-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                  <GitBranch size={20} />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <h4 className="text-xs font-bold text-white group-hover:text-orange-300 transition-colors">
                      Safar Flow Automation
                    </h4>
                    <span className="text-[9px] font-mono uppercase px-1.5 py-0.5 rounded bg-orange-500/20 text-orange-400 font-semibold border border-orange-500/30">
                      5-Step Pipeline
                    </span>
                  </div>
                  <p className="text-[11px] text-zinc-400 mt-0.5">
                    1. Write · 2. Translate · 3. Summarize · 4. Review · 5. Export
                  </p>
                </div>
              </div>
              <ChevronRight size={16} className="text-zinc-500 group-hover:text-orange-400 transition-colors shrink-0" />
            </button>

            {/* Ready-made workflows quick chips */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 pt-1 border-t border-white/[0.06]">
              <button
                onClick={() => onOpenFlow ? onOpenFlow('business_writing') : onNavigate('flow')}
                className="p-1.5 rounded-lg bg-white/5 hover:bg-orange-500/15 border border-white/5 hover:border-orange-500/30 text-[10px] text-zinc-300 hover:text-white transition-all text-left flex items-center gap-1"
              >
                <span>💼</span>
                <span className="truncate">Business Writing</span>
              </button>

              <button
                onClick={() => onOpenFlow ? onOpenFlow('social_media') : onNavigate('flow')}
                className="p-1.5 rounded-lg bg-white/5 hover:bg-orange-500/15 border border-white/5 hover:border-orange-500/30 text-[10px] text-zinc-300 hover:text-white transition-all text-left flex items-center gap-1"
              >
                <span>🚀</span>
                <span className="truncate">Social Media</span>
              </button>

              <button
                onClick={() => onOpenFlow ? onOpenFlow('document_translation') : onNavigate('flow')}
                className="p-1.5 rounded-lg bg-white/5 hover:bg-orange-500/15 border border-white/5 hover:border-orange-500/30 text-[10px] text-zinc-300 hover:text-white transition-all text-left flex items-center gap-1"
              >
                <span>🌐</span>
                <span className="truncate">Doc Translation</span>
              </button>

              <button
                onClick={() => onOpenFlow ? onOpenFlow('study_notes') : onNavigate('flow')}
                className="p-1.5 rounded-lg bg-white/5 hover:bg-orange-500/15 border border-white/5 hover:border-orange-500/30 text-[10px] text-zinc-300 hover:text-white transition-all text-left flex items-center gap-1"
              >
                <span>📚</span>
                <span className="truncate">Study Notes</span>
              </button>
            </div>
          </div>
        </div>

        {/* 5-Agent Swarm Team Featured Card */}
        <div className="pt-2">
          <button
            onClick={() => onNavigate('agents')}
            className="w-full p-3 rounded-2xl bg-gradient-to-r from-[#1F1610] via-[#161419] to-[#111116] border border-orange-500/30 hover:border-orange-500/60 text-left transition-all group flex items-center justify-between shadow-lg"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-orange-500/15 border border-orange-500/30 text-orange-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                <Users size={20} />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h4 className="text-xs font-bold text-white group-hover:text-orange-300 transition-colors">
                    Safar 5-Agent Swarm
                  </h4>
                  <span className="text-[9px] font-mono uppercase px-1.5 py-0.5 rounded bg-orange-500/20 text-orange-400 font-semibold border border-orange-500/30">
                    Coordinated
                  </span>
                </div>
                <p className="text-[11px] text-zinc-400 mt-0.5">
                  Coordinator · Research · Planning · Writing · Review
                </p>
              </div>
            </div>
            <ChevronRight size={16} className="text-zinc-500 group-hover:text-orange-400 transition-colors shrink-0" />
          </button>
        </div>

        {/* AI Tools Hub Quick Launcher Row */}
        <div className="pt-2">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[11px] font-semibold text-zinc-300">Smart Agent AI Tools</span>
            <button
              onClick={() => onNavigate('agents')}
              className="text-[10px] text-orange-400 hover:text-orange-300 font-medium"
            >
              All 8 Tools →
            </button>
          </div>
          <div className="grid grid-cols-4 gap-1.5 text-center text-[10px]">
            <button
              onClick={() => onNavigate('agents')}
              className="p-2 rounded-xl bg-[#141418] border border-white/5 hover:border-orange-500/40 text-zinc-300 hover:text-white transition-all flex flex-col items-center gap-1"
            >
              <div className="w-6 h-6 rounded-lg bg-orange-500/10 text-orange-400 flex items-center justify-center">
                ✍️
              </div>
              <span className="truncate w-full">AI Writer</span>
            </button>

            <button
              onClick={() => onNavigate('agents')}
              className="p-2 rounded-xl bg-[#141418] border border-white/5 hover:border-orange-500/40 text-zinc-300 hover:text-white transition-all flex flex-col items-center gap-1"
            >
              <div className="w-6 h-6 rounded-lg bg-orange-500/10 text-orange-400 flex items-center justify-center">
                🌐
              </div>
              <span className="truncate w-full">Translator</span>
            </button>

            <button
              onClick={() => onNavigate('agents')}
              className="p-2 rounded-xl bg-[#141418] border border-white/5 hover:border-orange-500/40 text-zinc-300 hover:text-white transition-all flex flex-col items-center gap-1"
            >
              <div className="w-6 h-6 rounded-lg bg-orange-500/10 text-orange-400 flex items-center justify-center">
                📄
              </div>
              <span className="truncate w-full">PDF Assistant</span>
            </button>

            <button
              onClick={() => onNavigate('agents')}
              className="p-2 rounded-xl bg-[#141418] border border-white/5 hover:border-orange-500/40 text-zinc-300 hover:text-white transition-all flex flex-col items-center gap-1"
            >
              <div className="w-6 h-6 rounded-lg bg-orange-500/10 text-orange-400 flex items-center justify-center">
                📷
              </div>
              <span className="truncate w-full">QR Scanner</span>
            </button>
          </div>
        </div>
      </section>

      {/* Quick Prompt Chips */}
      <div className="space-y-2 mb-3">
        <p className="text-[11px] text-zinc-400 font-medium">Quick Starters</p>
        <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
          {promptChips.map((chip, idx) => (
            <button
              key={idx}
              onClick={() => {
                if (chip.isImage) {
                  onOpenImageStudio(chip.label);
                } else {
                  onStartChatWithPrompt(chip.label, chip.agentId);
                }
              }}
              className="whitespace-nowrap shrink-0 text-xs px-3 py-1.5 rounded-xl bg-[#141418] border border-white/10 text-zinc-300 hover:text-white hover:border-orange-500/40 transition-colors active:scale-95"
            >
              {chip.label}
            </button>
          ))}
        </div>
      </div>

      {/* CHAT INPUT BAR */}
      <div className="sticky bottom-0 bg-[#0B0B0C]/95 backdrop-blur-md pt-2 pb-1 z-20">
        <form
          onSubmit={handleSendPrompt}
          className="relative flex items-center bg-[#15151A] border border-white/12 rounded-2xl p-1.5 pl-3 shadow-xl focus-within:border-orange-500/60 focus-within:ring-2 focus-within:ring-orange-500/20 transition-all"
        >
          {/* Studio quick trigger */}
          <button
            type="button"
            onClick={() => onOpenImageStudio()}
            className="w-8 h-8 rounded-xl text-zinc-400 hover:text-orange-400 hover:bg-white/5 flex items-center justify-center transition-colors shrink-0 mr-1"
            title="Image Studio (1K/2K/4K)"
          >
            <ImageIcon size={18} />
          </button>

          {/* Text Input */}
          <input
            type="text"
            value={chatPrompt}
            onChange={(e) => setChatPrompt(e.target.value)}
            placeholder="Ask Safar or describe your journey..."
            className="flex-1 bg-transparent text-sm text-white placeholder-zinc-500 focus:outline-none min-w-0 pr-2"
          />

          {/* Voice trigger inside input */}
          <button
            type="button"
            onClick={onOpenVoice}
            className="w-8 h-8 rounded-xl text-zinc-400 hover:text-orange-400 hover:bg-white/5 flex items-center justify-center transition-colors shrink-0 mr-1"
            title="Live Voice"
          >
            <Mic size={18} />
          </button>

          {/* Send Button */}
          <button
            type="submit"
            disabled={!chatPrompt.trim()}
            className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 transition-all ${
              chatPrompt.trim()
                ? 'bg-orange-500 hover:bg-orange-600 text-white shadow-md shadow-orange-500/30 active:scale-95'
                : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
            }`}
            title="Send prompt"
          >
            <ArrowUp size={18} strokeWidth={2.4} />
          </button>
        </form>
      </div>
    </div>
  );
};
