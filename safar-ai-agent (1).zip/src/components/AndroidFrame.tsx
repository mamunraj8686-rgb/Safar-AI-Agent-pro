import React, { useState, useEffect } from 'react';
import { Wifi, BatteryCharging, Smartphone, Monitor, Sun, Moon, Globe } from 'lucide-react';
import { AppTheme, AppLanguage } from '../types';

interface AndroidFrameProps {
  children: React.ReactNode;
  activeTab: string;
  theme?: AppTheme;
  language?: AppLanguage;
  onToggleTheme?: () => void;
}

export const AndroidFrame: React.FC<AndroidFrameProps> = ({ 
  children,
  activeTab,
  theme = 'dark',
  language = 'auto',
  onToggleTheme
}) => {
  const [currentTime, setCurrentTime] = useState<string>('');
  const [deviceFrameMode, setDeviceFrameMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return window.innerWidth >= 768;
    }
    return false;
  });

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
      );
    };
    updateClock();
    const interval = setInterval(updateClock, 1000);
    return () => clearInterval(interval);
  }, []);

  const isLight = theme === 'light';
  const isArabicRTL = language === 'ar';

  return (
    <div 
      dir={isArabicRTL ? 'rtl' : 'ltr'} 
      className={`min-h-screen flex flex-col items-center justify-center relative font-sans selection:bg-orange-500/30 selection:text-orange-200 transition-colors ${
        isLight ? 'bg-[#EEF2F6] text-slate-900 theme-light' : 'bg-[#060607] text-white'
      }`}
    >
      {/* Viewport switch & Quick Controls toolbar on larger screens */}
      <aside aria-label="Device view toggle" className={`hidden md:flex fixed top-4 right-4 z-50 items-center gap-1.5 px-3 py-1.5 rounded-full backdrop-blur-md border text-xs shadow-xl transition-colors ${
        isLight ? 'bg-white/95 border-slate-300 text-slate-700' : 'bg-[#141416]/90 border-white/10 text-zinc-300'
      }`}>
        <span className="text-zinc-400 mr-1 text-[11px]">View:</span>
        <button
          onClick={() => setDeviceFrameMode(true)}
          className={`px-2 py-0.5 rounded-full flex items-center gap-1 transition-all text-xs font-medium ${
            deviceFrameMode
              ? 'bg-orange-500 text-white shadow-sm'
              : 'text-zinc-400 hover:text-white'
          }`}
          title="Android Device Frame"
        >
          <Smartphone size={12} />
          <span>Phone</span>
        </button>
        <button
          onClick={() => setDeviceFrameMode(false)}
          className={`px-2 py-0.5 rounded-full flex items-center gap-1 transition-all text-xs font-medium ${
            !deviceFrameMode
              ? 'bg-orange-500 text-white shadow-sm'
              : 'text-zinc-400 hover:text-white'
          }`}
          title="Full-Width Responsive"
        >
          <Monitor size={12} />
          <span>Full</span>
        </button>

        {onToggleTheme && (
          <div className="flex items-center border-l border-zinc-500/30 pl-2 ml-1">
            <button
              onClick={onToggleTheme}
              className="p-1 rounded-full hover:bg-orange-500/20 text-orange-400 transition-colors"
              title={isLight ? 'Switch to Dark Mode' : 'Switch to Light Mode'}
            >
              {isLight ? <Moon size={14} /> : <Sun size={14} />}
            </button>
          </div>
        )}
      </aside>

      {/* Main Container - either Android phone frame or fluid edge-to-edge container */}
      <div
        className={`w-full transition-all duration-300 app-container ${
          deviceFrameMode
            ? `max-w-[430px] my-3 md:my-6 h-[93vh] max-h-[920px] rounded-[48px] border-[6px] shadow-[0_25px_70px_rgba(0,0,0,0.85),0_0_50px_rgba(249,115,22,0.12)] overflow-hidden flex flex-col relative ${
                isLight ? 'bg-white border-[#D2D6DC]' : 'bg-[#0B0B0C] border-[#222226]'
              }`
            : `max-w-4xl min-h-screen flex flex-col shadow-2xl relative ${
                isLight ? 'bg-white' : 'bg-[#0B0B0C]'
              }`
        }`}
      >
        {/* Android Status Bar */}
        <header className={`h-10 px-6 pt-1 flex items-center justify-between text-xs font-medium select-none z-30 shrink-0 backdrop-blur-md transition-colors ${
          isLight ? 'bg-white/95 text-slate-700 border-b border-slate-200' : 'bg-[#0B0B0C]/90 text-zinc-300 border-b border-white/[0.03]'
        }`}>
          {/* Time & Android notification badges */}
          <div className="flex items-center gap-2">
            <span className={`font-mono font-semibold tracking-tight text-[13px] ${isLight ? 'text-slate-900' : 'text-white'}`}>
              {currentTime || '12:00'}
            </span>
            <div className="flex items-center gap-1 opacity-70">
              <span className="inline-block w-1.5 h-1.5 rounded-full bg-orange-500"></span>
            </div>
          </div>

          {/* Camera Notch Punch Hole (Android aesthetic) */}
          <div className="w-4 h-4 rounded-full bg-black border border-zinc-800 flex items-center justify-center">
            <div className="w-1.5 h-1.5 rounded-full bg-zinc-900 ring-1 ring-orange-500/20"></div>
          </div>

          {/* Android Network / Battery icons */}
          <div className="flex items-center gap-2">
            <span className={`text-[10px] font-mono tracking-tighter uppercase px-1 py-0.5 rounded ${
              isLight ? 'bg-slate-100 text-slate-600' : 'bg-white/5 text-zinc-400'
            }`}>
              5G
            </span>
            <Wifi size={13} />
            <div className="flex items-center gap-0.5">
              <span className="text-[10px] font-mono">94%</span>
              <BatteryCharging size={14} className="text-orange-500" />
            </div>
          </div>
        </header>

        {/* Dynamic App Content Body */}
        <main className="flex-1 flex flex-col overflow-hidden relative">
          {children}
        </main>

        {/* Android Gesture Bar */}
        <div className={`h-4 pb-1 shrink-0 flex items-center justify-center z-30 transition-colors ${
          isLight ? 'bg-white' : 'bg-[#0B0B0C]'
        }`}>
          <div className={`w-28 h-1 rounded-full ${isLight ? 'bg-slate-300' : 'bg-white/20'}`}></div>
        </div>
      </div>
    </div>
  );
};
