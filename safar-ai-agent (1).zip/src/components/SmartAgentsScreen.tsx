import React, { useState } from 'react';
import { 
  Bot, 
  Compass, 
  ListChecks, 
  Code2, 
  Sparkles, 
  Briefcase, 
  Palette, 
  ChevronRight, 
  ArrowRight,
  PenTool,
  Languages,
  AlignLeft,
  Calculator as CalcIcon,
  BookOpen,
  FileText,
  Eye,
  QrCode,
  Wrench,
  Cpu
} from 'lucide-react';
import { SmartAgent } from '../types';
import { SMART_AGENTS } from '../data/agents';

// Sub-tools for the 8 requested tools
import { AIWriterTool } from './tools/AIWriterTool';
import { TranslatorTool } from './tools/TranslatorTool';
import { SummarizerTool } from './tools/SummarizerTool';
import { CalculatorTool } from './tools/CalculatorTool';
import { ResearchTool } from './tools/ResearchTool';
import { DocumentTool } from './tools/DocumentTool';
import { VisionTool } from './tools/VisionTool';
import { ScannerTool } from './tools/ScannerTool';
import { AgentTeamScreen } from './AgentTeamScreen';
import { SafarFlowScreen } from './SafarFlowScreen';
import { Users, GitBranch } from 'lucide-react';

export type SmartHubToolId = 
  | 'writer'
  | 'translator'
  | 'summarizer'
  | 'calculator'
  | 'research'
  | 'document'
  | 'vision'
  | 'scanner';

interface SmartAgentsScreenProps {
  onSelectAgent: (agentId: string, initialPrompt?: string) => void;
  onOpenStudio: (prompt?: string) => void;
  onSendToChat?: (text: string) => void;
  initialToolId?: SmartHubToolId | null;
}

export const SmartAgentsScreen: React.FC<SmartAgentsScreenProps> = ({
  onSelectAgent,
  onOpenStudio,
  onSendToChat,
  initialToolId = null,
}) => {
  const [hubView, setHubView] = useState<'team' | 'flows' | 'tools' | 'personas'>('team');
  const [activeTool, setActiveTool] = useState<SmartHubToolId | null>(initialToolId);

  // Quick Expedition builder state
  const [quickTripDestination, setQuickTripDestination] = useState<string>('');
  const [quickTripDays, setQuickTripDays] = useState<string>('5');
  const [quickTripStyle, setQuickTripStyle] = useState<string>('culture');

  const toolsList = [
    {
      id: 'writer' as SmartHubToolId,
      name: 'AI Writer',
      description: 'Generate essays, correspondence, articles, and stories in EN, বাংলা, or العربية with custom tone.',
      icon: PenTool,
      badge: 'Creation',
      color: '#F97316',
    },
    {
      id: 'translator' as SmartHubToolId,
      name: 'Translator',
      description: 'Context-aware neural translation between Bengali, Arabic, English, and global languages with pronunciation.',
      icon: Languages,
      badge: 'Language',
      color: '#FB923C',
    },
    {
      id: 'summarizer' as SmartHubToolId,
      name: 'Summarizer',
      description: 'Condense long articles, transcripts, or notes into executive briefs and bulleted key takeaways.',
      icon: AlignLeft,
      badge: 'Productivity',
      color: '#EA580C',
    },
    {
      id: 'calculator' as SmartHubToolId,
      name: 'Calculator',
      description: 'Interactive scientific keypad and step-by-step algebra, physics, and financial problem solver.',
      icon: CalcIcon,
      badge: 'Math',
      color: '#F59E0B',
    },
    {
      id: 'research' as SmartHubToolId,
      name: 'Research Assistant',
      description: 'Deep analytical topic briefs, empirical evidence synthesis, historical context, and future horizons.',
      icon: BookOpen,
      badge: 'Analysis',
      color: '#F97316',
    },
    {
      id: 'document' as SmartHubToolId,
      name: 'PDF & File Assistant',
      description: 'Upload real PDF, CSV, TXT, and Markdown documents for grounded extraction and multi-turn QA.',
      icon: FileText,
      badge: 'Files',
      color: '#FB923C',
    },
    {
      id: 'vision' as SmartHubToolId,
      name: 'Image Understanding',
      description: 'Multimodal image analysis with Gemini 3.8 Flash: OCR transcription, object detection, and visual QA.',
      icon: Eye,
      badge: 'Vision',
      color: '#EA580C',
    },
    {
      id: 'scanner' as SmartHubToolId,
      name: 'QR & Barcode Scanner',
      description: 'Live optical camera scanner with canvas decode, image file upload, and AI security payload analysis.',
      icon: QrCode,
      badge: 'Optical',
      color: '#F59E0B',
    },
  ];

  const handleLaunchQuickItinerary = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickTripDestination.trim()) return;
    const prompt = `Create a curated ${quickTripDays}-day itinerary for ${quickTripDestination.trim()} focusing on ${quickTripStyle}. Include morning, afternoon, and evening recommendations, transit logistics, and local culinary gems.`;
    onSelectAgent('safar-travel', prompt);
  };

  const getAgentIcon = (iconName: string) => {
    switch (iconName) {
      case 'Compass': return Compass;
      case 'ListChecks': return ListChecks;
      case 'Code2': return Code2;
      case 'Briefcase': return Briefcase;
      case 'Palette': return Palette;
      default: return Sparkles;
    }
  };

  // If a specific tool is open, render that tool screen
  if (activeTool === 'writer') {
    return <AIWriterTool onBack={() => setActiveTool(null)} onSendToChat={onSendToChat} />;
  }
  if (activeTool === 'translator') {
    return <TranslatorTool onBack={() => setActiveTool(null)} onSendToChat={onSendToChat} />;
  }
  if (activeTool === 'summarizer') {
    return <SummarizerTool onBack={() => setActiveTool(null)} onSendToChat={onSendToChat} />;
  }
  if (activeTool === 'calculator') {
    return <CalculatorTool onBack={() => setActiveTool(null)} onSendToChat={onSendToChat} />;
  }
  if (activeTool === 'research') {
    return <ResearchTool onBack={() => setActiveTool(null)} onSendToChat={onSendToChat} />;
  }
  if (activeTool === 'document') {
    return <DocumentTool onBack={() => setActiveTool(null)} onSendToChat={onSendToChat} />;
  }
  if (activeTool === 'vision') {
    return <VisionTool onBack={() => setActiveTool(null)} onSendToChat={onSendToChat} />;
  }
  if (activeTool === 'scanner') {
    return <ScannerTool onBack={() => setActiveTool(null)} onSendToChat={onSendToChat} />;
  }

  return (
    <div className="flex-1 flex flex-col overflow-y-auto bg-[#0B0B0C] px-4 py-4 space-y-4">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-orange-500/15 border border-orange-500/30 text-orange-400 flex items-center justify-center font-bold">
            <Bot size={18} />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white tracking-tight">Smart Agent Hub</h2>
            <p className="text-xs text-zinc-400">8 specialized AI tools & autonomous personas</p>
          </div>
        </div>
      </div>

      {/* Segmented Switcher: Agent Team vs Flows vs AI Tools vs Autonomous Personas */}
      <div className="flex items-center p-1 rounded-2xl bg-[#141418] border border-white/10 text-xs gap-1">
        <button
          onClick={() => setHubView('team')}
          className={`flex-1 py-1.5 rounded-xl font-medium flex items-center justify-center gap-1 transition-all ${
            hubView === 'team'
              ? 'bg-orange-500 text-white shadow-sm'
              : 'text-zinc-400 hover:text-white'
          }`}
        >
          <Users size={12} />
          <span>Team (5)</span>
        </button>

        <button
          onClick={() => setHubView('flows')}
          className={`flex-1 py-1.5 rounded-xl font-medium flex items-center justify-center gap-1 transition-all ${
            hubView === 'flows'
              ? 'bg-orange-500 text-white shadow-sm'
              : 'text-zinc-400 hover:text-white'
          }`}
        >
          <GitBranch size={12} />
          <span>Flows (4)</span>
        </button>

        <button
          onClick={() => setHubView('tools')}
          className={`flex-1 py-1.5 rounded-xl font-medium flex items-center justify-center gap-1 transition-all ${
            hubView === 'tools'
              ? 'bg-orange-500 text-white shadow-sm'
              : 'text-zinc-400 hover:text-white'
          }`}
        >
          <Wrench size={12} />
          <span>Tools ({toolsList.length})</span>
        </button>

        <button
          onClick={() => setHubView('personas')}
          className={`flex-1 py-1.5 rounded-xl font-medium flex items-center justify-center gap-1 transition-all ${
            hubView === 'personas'
              ? 'bg-orange-500 text-white shadow-sm'
              : 'text-zinc-400 hover:text-white'
          }`}
        >
          <Cpu size={12} />
          <span>Personas ({SMART_AGENTS.length})</span>
        </button>
      </div>

      {/* VIEW 0: 5-AGENT TEAM COLLABORATIVE PIPELINE */}
      {hubView === 'team' && (
        <AgentTeamScreen onSendToChat={onSendToChat} />
      )}

      {/* VIEW 0.5: SAFAR FLOW AUTOMATION */}
      {hubView === 'flows' && (
        <SafarFlowScreen onSendToChat={onSendToChat} />
      )}

      {/* VIEW 1: THE 8 AI TOOLS */}
      {hubView === 'tools' && (
        <div className="space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {toolsList.map((tool) => {
              const Icon = tool.icon;
              return (
                <button
                  key={tool.id}
                  onClick={() => setActiveTool(tool.id)}
                  className="p-3.5 rounded-2xl bg-[#141418] border border-white/[0.08] hover:border-orange-500/50 text-left transition-all hover:bg-[#18181D] group flex flex-col justify-between"
                >
                  <div className="flex items-center justify-between w-full mb-2">
                    <div className="w-9 h-9 rounded-xl bg-orange-500/10 border border-orange-500/20 text-orange-400 flex items-center justify-center group-hover:scale-105 transition-transform">
                      <Icon size={18} />
                    </div>
                    <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-white/5 text-zinc-400 border border-white/5">
                      {tool.badge}
                    </span>
                  </div>

                  <div>
                    <h3 className="text-xs font-bold text-white group-hover:text-orange-300 transition-colors flex items-center justify-between">
                      <span>{tool.name}</span>
                      <ChevronRight size={13} className="text-zinc-500 group-hover:text-orange-400 group-hover:translate-x-0.5 transition-all" />
                    </h3>
                    <p className="text-[11px] text-zinc-400 mt-1 leading-relaxed line-clamp-2">
                      {tool.description}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* VIEW 2: AUTONOMOUS PERSONAS & TRAVEL CONCIERGE */}
      {hubView === 'personas' && (
        <div className="space-y-4">
          {/* Signature Tool: Safar Expedition Quick Builder */}
          <div className="p-3.5 rounded-2xl bg-gradient-to-br from-[#1A1512] to-[#121215] border border-orange-500/30 relative overflow-hidden">
            <div className="flex items-center gap-2 mb-2">
              <Compass size={16} className="text-orange-400" />
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                Safar Voyage Engine · Instant Expedition Planner
              </h3>
            </div>
            <p className="text-xs text-zinc-300 mb-3">
              Launch a bespoke multi-day voyage itinerary with logistics, hidden culinary stops, and transit passes.
            </p>

            <form onSubmit={handleLaunchQuickItinerary} className="space-y-2.5">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <div className="sm:col-span-2 relative">
                  <input
                    type="text"
                    value={quickTripDestination}
                    onChange={(e) => setQuickTripDestination(e.target.value)}
                    placeholder="Where to? (e.g. Kyoto, Lisbon, Swiss Alps...)"
                    className="w-full bg-[#141418] border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-orange-500"
                  />
                </div>
                <div className="flex gap-2">
                  <select
                    value={quickTripDays}
                    onChange={(e) => setQuickTripDays(e.target.value)}
                    className="w-1/2 bg-[#141418] border border-white/10 rounded-xl px-2 py-2 text-xs text-white focus:outline-none focus:border-orange-500"
                  >
                    <option value="3">3 Days</option>
                    <option value="5">5 Days</option>
                    <option value="7">7 Days</option>
                    <option value="10">10 Days</option>
                    <option value="14">14 Days</option>
                  </select>
                  <select
                    value={quickTripStyle}
                    onChange={(e) => setQuickTripStyle(e.target.value)}
                    className="w-1/2 bg-[#141418] border border-white/10 rounded-xl px-2 py-2 text-xs text-white focus:outline-none focus:border-orange-500"
                  >
                    <option value="culinary & culture">Culture</option>
                    <option value="adventure & nature">Nature</option>
                    <option value="luxury relaxation">Luxury</option>
                    <option value="budget backpacking">Backpacking</option>
                  </select>
                </div>
              </div>

              <button
                type="submit"
                disabled={!quickTripDestination.trim()}
                className={`w-full py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                  quickTripDestination.trim()
                    ? 'bg-orange-500 hover:bg-orange-600 text-white shadow-md shadow-orange-500/20 active:scale-98'
                    : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                }`}
              >
                <span>Generate Expedition Itinerary</span>
                <ArrowRight size={13} />
              </button>
            </form>
          </div>

          {/* Agents List */}
          <div className="space-y-3">
            {SMART_AGENTS.map((agent: SmartAgent) => {
              const Icon = getAgentIcon(agent.icon);
              return (
                <div
                  key={agent.id}
                  className="p-3.5 rounded-2xl bg-[#141418] border border-white/[0.08] hover:border-orange-500/40 transition-all space-y-2.5"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-orange-500/10 border border-orange-500/20 text-orange-400 flex items-center justify-center shrink-0">
                        <Icon size={20} />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-sm font-bold text-white">{agent.name}</h3>
                          <span className="text-[10px] font-mono uppercase px-1.5 py-0.5 rounded bg-white/5 text-zinc-400 border border-white/10">
                            {agent.badge}
                          </span>
                        </div>
                        <p className="text-xs text-orange-400 font-medium">{agent.title}</p>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        if (agent.id === 'safar-visual') {
                          onOpenStudio();
                        } else {
                          onSelectAgent(agent.id);
                        }
                      }}
                      className="px-3 py-1.5 rounded-xl bg-orange-500/10 hover:bg-orange-500 text-orange-400 hover:text-white border border-orange-500/30 text-xs font-semibold flex items-center gap-1 transition-colors"
                    >
                      <span>Launch</span>
                      <ChevronRight size={13} />
                    </button>
                  </div>

                  <p className="text-xs text-zinc-400 leading-relaxed">
                    {agent.description}
                  </p>

                  {/* Starter Prompt Chips */}
                  <div className="pt-1 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
                    {agent.starterPrompts.slice(0, 2).map((sp, idx) => (
                      <button
                        key={idx}
                        onClick={() => {
                          if (agent.id === 'safar-visual') {
                            onOpenStudio(sp);
                          } else {
                            onSelectAgent(agent.id, sp);
                          }
                        }}
                        className="text-[11px] whitespace-nowrap shrink-0 px-2.5 py-1 rounded-lg bg-black/40 border border-white/5 text-zinc-300 hover:text-orange-300 hover:border-orange-500/30 transition-colors"
                      >
                        "{sp}"
                      </button>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
