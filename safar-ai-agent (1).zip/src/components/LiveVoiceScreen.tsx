import React, { useState, useEffect, useRef } from 'react';
import { 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  Square, 
  Play, 
  Hand, 
  Radio, 
  Sparkles, 
  MessageSquare, 
  AlertCircle, 
  Languages, 
  Check, 
  RotateCcw,
  Sliders,
  ChevronDown,
  ArrowRight,
} from 'lucide-react';
import { getApiUrl } from '../services/apiConfig';

interface LiveVoiceScreenProps {
  onSwitchToChat: (initialPrompt?: string) => void;
}

type VoiceState = 'idle' | 'listening' | 'processing' | 'speaking';

interface VoiceTranscriptItem {
  id: string;
  sender: 'user' | 'safar';
  text: string;
  timestamp: string;
  language?: string;
}

export const LiveVoiceScreen: React.FC<LiveVoiceScreenProps> = ({ onSwitchToChat }) => {
  // Voice session states
  const [voiceState, setVoiceState] = useState<VoiceState>('idle');
  const [selectedLanguage, setSelectedLanguage] = useState<'en-US' | 'bn-BD' | 'ar-SA'>('en-US');
  const [interimTranscript, setInterimTranscript] = useState<string>('');
  const [statusMessage, setStatusMessage] = useState<string>('Ready to begin. Tap Start Voice Session.');
  const [micPermission, setMicPermission] = useState<'granted' | 'denied' | 'prompt'>('prompt');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Audio & Voice options
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedVoiceURI, setSelectedVoiceURI] = useState<string>('');
  const [showVoiceSettings, setShowVoiceSettings] = useState<boolean>(false);
  const [speechRate, setSpeechRate] = useState<number>(1.0);
  const [textFallbackQuery, setTextFallbackQuery] = useState<string>('');

  // Conversation history in voice session
  const [transcripts, setTranscripts] = useState<VoiceTranscriptItem[]>([
    {
      id: 'welcome-voice',
      sender: 'safar',
      text: 'Safar Live Voice active. I am tuned to English, Bengali, and Arabic with natural speech. Tap Start to speak.',
      timestamp: 'Ready',
      language: 'en',
    },
  ]);

  const recognitionRef = useRef<any>(null);
  const synthesisRef = useRef<SpeechSynthesisUtterance | null>(null);

  // Helper to detect language
  const detectLanguageCode = (text: string): 'ar' | 'bn' | 'en' => {
    if (/[\u0600-\u06FF]/.test(text)) return 'ar';
    if (/[\u0980-\u09FF]/.test(text)) return 'bn';
    return 'en';
  };

  // Populate browser voices and auto-select natural female voice
  useEffect(() => {
    const updateVoices = () => {
      if (!('speechSynthesis' in window)) return;
      const voices = window.speechSynthesis.getVoices();
      setAvailableVoices(voices);

      // Prioritize natural female voices based on keywords and current language
      const langPrefix = selectedLanguage.split('-')[0];
      const langMatchingVoices = voices.filter(v => v.lang.toLowerCase().startsWith(langPrefix));

      const femaleKeywords = ['female', 'samantha', 'victoria', 'karen', 'zira', 'google us english', 'natural', 'laila', 'salma', 'tania'];
      
      const naturalFemaleVoice = langMatchingVoices.find(v => 
        femaleKeywords.some(kw => v.name.toLowerCase().includes(kw))
      ) || langMatchingVoices[0] || voices.find(v => femaleKeywords.some(kw => v.name.toLowerCase().includes(kw))) || voices[0];

      if (naturalFemaleVoice && !selectedVoiceURI) {
        setSelectedVoiceURI(naturalFemaleVoice.voiceURI);
      }
    };

    updateVoices();
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.onvoiceschanged = updateVoices;
    }
  }, [selectedLanguage]);

  // Initialize SpeechRecognition
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setErrorMessage('Speech recognition is not natively available in this browser. You can use text query fallback below.');
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = selectedLanguage;

    recognition.onstart = () => {
      setVoiceState('listening');
      setMicPermission('granted');
      setErrorMessage(null);
      setStatusMessage('Listening to your voice... Speak naturally.');
    };

    recognition.onresult = (event: any) => {
      let interim = '';
      let finalSpeech = '';

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        const transcriptChunk = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          finalSpeech += transcriptChunk;
        } else {
          interim += transcriptChunk;
        }
      }

      setInterimTranscript(interim);

      if (finalSpeech.trim()) {
        processUserVoice(finalSpeech.trim());
      }
    };

    recognition.onerror = (event: any) => {
      console.warn('Speech recognition event error:', event.error);
      if (event.error === 'not-allowed') {
        setMicPermission('denied');
        setVoiceState('idle');
        setErrorMessage('Microphone access was denied. Please allow microphone permissions in browser settings or use text chat.');
        setStatusMessage('Microphone access blocked.');
      } else if (event.error === 'no-speech') {
        setStatusMessage('No speech detected. Listening...');
      } else {
        setStatusMessage(`Voice notice: ${event.error}`);
      }
    };

    recognition.onend = () => {
      // If we were listening and recognition stopped unexpectedly, handle state
      if (voiceState === 'listening') {
        setVoiceState('idle');
        setStatusMessage('Listening paused. Tap Start to resume.');
      }
    };

    recognitionRef.current = recognition;

    return () => {
      try {
        recognition.stop();
      } catch (e) {
        // ignore
      }
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
    };
  }, [selectedLanguage]);

  // Request real microphone permission explicitly
  const requestMicPermission = async (): Promise<boolean> => {
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        // Release stream immediately once permission verified
        stream.getTracks().forEach(track => track.stop());
        setMicPermission('granted');
        setErrorMessage(null);
        return true;
      }
      return true;
    } catch (err: any) {
      console.warn('Mic permission error:', err);
      setMicPermission('denied');
      setErrorMessage('Microphone permission denied. Enable microphone access in browser settings or use Text Chat below.');
      setStatusMessage('Microphone permission required.');
      return false;
    }
  };

  // START Listening Control
  const handleStartVoice = async () => {
    // If speaking, interrupt speech first
    if (voiceState === 'speaking') {
      handleInterruptSpeech();
    }

    const hasPermission = await requestMicPermission();
    if (!hasPermission) return;

    if (recognitionRef.current) {
      try {
        recognitionRef.current.lang = selectedLanguage;
        recognitionRef.current.start();
      } catch (err: any) {
        console.warn('Start error:', err);
        // May already be active
        setVoiceState('listening');
        setStatusMessage('Listening to your voice...');
      }
    }
  };

  // STOP Listening Control
  const handleStopVoice = () => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {
        // ignore
      }
    }
    setVoiceState('idle');
    setInterimTranscript('');
    setStatusMessage('Voice session stopped. Tap Start to speak.');
  };

  // INTERRUPT SPEECH Control
  const handleInterruptSpeech = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    synthesisRef.current = null;
    setVoiceState('idle');
    setStatusMessage('Speech interrupted by user. Ready.');
  };

  // TOGGLE MUTE Control
  const handleToggleMute = () => {
    if (!isMuted && voiceState === 'speaking') {
      handleInterruptSpeech();
    }
    setIsMuted(!isMuted);
  };

  // Process speech transcript with Gemini
  const processUserVoice = async (transcriptText: string) => {
    // Temporarily pause recognition while processing
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {
        // ignore
      }
    }

    setVoiceState('processing');
    setInterimTranscript('');
    setStatusMessage('Safar is synthesizing response...');

    const detectedLang = detectLanguageCode(transcriptText);

    const userTranscriptItem: VoiceTranscriptItem = {
      id: `u-${Date.now()}`,
      sender: 'user',
      text: transcriptText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      language: detectedLang,
    };

    setTranscripts(prev => [...prev, userTranscriptItem]);

    try {
      const res = await fetch(getApiUrl('/api/voice/interact'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          transcript: transcriptText,
          agentId: 'voice',
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to process voice query');
      }

      const spokenResponse = data.spokenText || 'I am with you. What would you like to explore next?';
      const responseLang = detectLanguageCode(spokenResponse);

      const safarTranscriptItem: VoiceTranscriptItem = {
        id: `s-${Date.now()}`,
        sender: 'safar',
        text: spokenResponse,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        language: responseLang,
      };

      setTranscripts(prev => [...prev, safarTranscriptItem]);

      // Speak response aloud with female voice preference
      speakSpokenText(spokenResponse, responseLang);
    } catch (err: any) {
      console.error('Voice interact error:', err);
      setVoiceState('idle');
      setStatusMessage('Error getting response. Tap Start to try again.');
      setErrorMessage(err?.message || 'Voice generation error. You can switch to text chat.');
    }
  };

  // Text-to-Speech synthesis with natural female voice prioritization
  const speakSpokenText = (text: string, langCode: 'ar' | 'bn' | 'en') => {
    if (isMuted || !('speechSynthesis' in window)) {
      setVoiceState('idle');
      setStatusMessage('Audio muted. Ready for your next query.');
      return;
    }

    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = speechRate;
    utterance.pitch = 1.05; // Slightly elevated pitch for friendly, natural feminine clarity

    const voices = window.speechSynthesis.getVoices();
    let chosenVoice: SpeechSynthesisVoice | undefined;

    // 1. If user manually selected a voice from settings, use it
    if (selectedVoiceURI) {
      chosenVoice = voices.find(v => v.voiceURI === selectedVoiceURI);
    }

    // 2. Otherwise auto-match natural female voice for the language
    if (!chosenVoice) {
      const langPrefix = langCode === 'ar' ? 'ar' : langCode === 'bn' ? 'bn' : 'en';
      const matchingVoices = voices.filter(v => v.lang.toLowerCase().startsWith(langPrefix));

      const femaleKeywords = ['female', 'natural', 'google', 'samantha', 'victoria', 'karen', 'zira', 'salma', 'laila', 'tania'];
      chosenVoice = matchingVoices.find(v => 
        femaleKeywords.some(kw => v.name.toLowerCase().includes(kw))
      ) || matchingVoices[0] || voices[0];
    }

    if (chosenVoice) {
      utterance.voice = chosenVoice;
    }

    // Explicit language tag for audio engine
    if (langCode === 'ar') {
      utterance.lang = 'ar-SA';
    } else if (langCode === 'bn') {
      utterance.lang = 'bn-BD';
    } else {
      utterance.lang = 'en-US';
    }

    utterance.onstart = () => {
      setVoiceState('speaking');
      setStatusMessage(`Safar is speaking (${chosenVoice?.name ? chosenVoice.name.slice(0, 20) : 'Natural Voice'})...`);
    };

    utterance.onend = () => {
      setVoiceState('idle');
      setStatusMessage('Finished speaking. Tap Start to talk.');
      synthesisRef.current = null;
    };

    utterance.onerror = (e) => {
      console.warn('Synthesis error:', e);
      setVoiceState('idle');
      setStatusMessage('Voice output complete.');
      synthesisRef.current = null;
    };

    synthesisRef.current = utterance;
    window.speechSynthesis.speak(utterance);
  };

  // Text-chat fallback submission
  const handleTextFallbackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!textFallbackQuery.trim()) return;
    processUserVoice(textFallbackQuery.trim());
    setTextFallbackQuery('');
  };

  return (
    <div className="flex-1 flex flex-col justify-between overflow-hidden bg-[#0B0B0C] px-4 py-3.5 select-none">
      {/* Top Bar: Controls & Language Switcher */}
      <div className="space-y-2 pb-2 border-b border-white/[0.08]">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-orange-500/15 border border-orange-500/30 text-orange-400 flex items-center justify-center">
              <Radio size={16} className={voiceState === 'listening' ? 'animate-pulse' : ''} />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-sm font-bold text-white tracking-tight">Safar Live Voice</h2>
                <span className={`w-2 h-2 rounded-full ${
                  voiceState === 'listening' 
                    ? 'bg-red-500 animate-ping' 
                    : voiceState === 'speaking' 
                    ? 'bg-emerald-400 animate-pulse' 
                    : voiceState === 'processing'
                    ? 'bg-orange-500 animate-spin'
                    : 'bg-zinc-600'
                }`}></span>
              </div>
              <p className="text-[10px] font-mono text-zinc-400 capitalize">
                State: <span className="text-orange-400 font-semibold">{voiceState}</span>
              </p>
            </div>
          </div>

          {/* Quick Toolbar: Mute, Voice Settings, Switch to Text */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={handleToggleMute}
              className={`p-1.5 rounded-xl border text-xs transition-colors ${
                isMuted
                  ? 'bg-red-500/10 text-red-400 border-red-500/30'
                  : 'bg-[#141418] text-zinc-300 border-white/10 hover:text-white'
              }`}
              title={isMuted ? 'Audio Muted' : 'Mute Audio'}
            >
              {isMuted ? <VolumeX size={15} /> : <Volume2 size={15} />}
            </button>

            <button
              onClick={() => setShowVoiceSettings(!showVoiceSettings)}
              className="p-1.5 rounded-xl bg-[#141418] border border-white/10 text-zinc-300 hover:text-white"
              title="Voice & Language Settings"
            >
              <Sliders size={15} />
            </button>

            <button
              onClick={() => onSwitchToChat()}
              className="px-2.5 py-1 rounded-xl bg-white/5 border border-white/10 text-[11px] text-zinc-300 hover:text-orange-400 flex items-center gap-1 transition-colors"
              title="Switch to Text Chat"
            >
              <MessageSquare size={13} />
              <span>Chat</span>
            </button>
          </div>
        </div>

        {/* Language Selection Strip */}
        <div className="flex items-center justify-between text-[11px] pt-1">
          <div className="flex items-center gap-1 text-zinc-400">
            <Languages size={12} className="text-orange-400" />
            <span>Target Locale:</span>
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setSelectedLanguage('en-US')}
              className={`px-2 py-0.5 rounded-md text-[10px] font-medium transition-colors ${
                selectedLanguage === 'en-US'
                  ? 'bg-orange-500 text-white'
                  : 'bg-[#141418] text-zinc-400 hover:text-white'
              }`}
            >
              English
            </button>
            <button
              onClick={() => setSelectedLanguage('bn-BD')}
              className={`px-2 py-0.5 rounded-md text-[10px] font-medium transition-colors ${
                selectedLanguage === 'bn-BD'
                  ? 'bg-orange-500 text-white'
                  : 'bg-[#141418] text-zinc-400 hover:text-white'
              }`}
            >
              বাংলা (Bengali)
            </button>
            <button
              onClick={() => setSelectedLanguage('ar-SA')}
              className={`px-2 py-0.5 rounded-md text-[10px] font-medium transition-colors ${
                selectedLanguage === 'ar-SA'
                  ? 'bg-orange-500 text-white'
                  : 'bg-[#141418] text-zinc-400 hover:text-white'
              }`}
            >
              العربية (Arabic)
            </button>
          </div>
        </div>

        {/* Expandable Voice Settings Tray */}
        {showVoiceSettings && (
          <div className="p-3 bg-[#141418] rounded-2xl border border-white/10 space-y-2 text-xs animate-in fade-in duration-200">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-white">Voice Customization</span>
              <span className="text-[10px] text-orange-400 font-mono">Preferred: Natural Female</span>
            </div>

            <div>
              <label className="block text-[11px] text-zinc-400 mb-1">
                Select TTS Output Voice ({availableVoices.length} detected)
              </label>
              <select
                value={selectedVoiceURI}
                onChange={(e) => setSelectedVoiceURI(e.target.value)}
                className="w-full bg-[#18181D] border border-white/10 rounded-xl p-2 text-xs text-white focus:outline-none focus:border-orange-500"
              >
                {availableVoices.map((v) => (
                  <option key={v.voiceURI} value={v.voiceURI}>
                    {v.name} ({v.lang})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <div className="flex items-center justify-between text-[11px] text-zinc-400 mb-1">
                <span>Speaking Rate</span>
                <span className="font-mono text-orange-400">{speechRate}x</span>
              </div>
              <input
                type="range"
                min="0.75"
                max="1.3"
                step="0.05"
                value={speechRate}
                onChange={(e) => setSpeechRate(parseFloat(e.target.value))}
                className="w-full accent-orange-500"
              />
            </div>
          </div>
        )}
      </div>

      {/* Permission or Error Banner with Text Fallback Option */}
      {errorMessage && (
        <div className="my-2 p-2.5 rounded-xl bg-red-950/40 border border-red-500/30 text-xs text-red-200 flex items-start justify-between">
          <div className="flex items-start gap-2">
            <AlertCircle size={15} className="text-red-400 shrink-0 mt-0.5" />
            <div>
              <p>{errorMessage}</p>
              <button
                onClick={() => onSwitchToChat()}
                className="mt-1 text-orange-400 hover:underline font-semibold flex items-center gap-1"
              >
                <span>Switch to Text Chat instead</span>
                <ArrowRight size={12} />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CENTERPIECE: Glowing Live Voice Visualizer & Interactive Core */}
      <div className="my-auto py-4 flex flex-col items-center justify-center relative">
        <div className="relative flex items-center justify-center">
          {/* Active Audio Wave Rings */}
          {(voiceState === 'listening' || voiceState === 'speaking') && (
            <>
              <div className="absolute w-56 h-56 rounded-full border border-orange-500/30 radar-ring pointer-events-none"></div>
              <div 
                className="absolute w-68 h-68 rounded-full border border-orange-500/15 radar-ring pointer-events-none" 
                style={{ animationDelay: '0.7s' }}
              ></div>
            </>
          )}

          {/* Central Hero Button (Tap to toggle Start / Stop) */}
          <button
            onClick={voiceState === 'listening' ? handleStopVoice : handleStartVoice}
            className={`w-36 h-36 rounded-full border-2 transition-all duration-300 relative flex flex-col items-center justify-center cursor-pointer shadow-2xl active:scale-95 ${
              voiceState === 'listening'
                ? 'border-red-500 bg-gradient-to-b from-[#251010] to-[#120808] shadow-[0_0_60px_rgba(239,68,68,0.5)]'
                : voiceState === 'speaking'
                ? 'border-emerald-400 bg-gradient-to-b from-[#102518] to-[#08120D] shadow-[0_0_60px_rgba(52,211,153,0.5)]'
                : voiceState === 'processing'
                ? 'border-orange-500 bg-gradient-to-b from-[#2A180E] to-[#140C07] shadow-[0_0_60px_rgba(249,115,22,0.5)] animate-pulse'
                : 'border-white/15 bg-gradient-to-b from-[#18181D] to-[#0E0E11] hover:border-orange-500/50'
            }`}
            aria-label="Toggle Safar Voice Session"
          >
            <div className="w-28 h-28 rounded-full bg-[#0F0F13] border border-white/10 flex flex-col items-center justify-center relative overflow-hidden">
              <div className="absolute inset-0 bg-radial from-orange-500/20 via-transparent to-transparent"></div>

              {/* Dynamic State Icon */}
              {voiceState === 'listening' ? (
                <Mic size={34} className="text-red-400 animate-bounce relative z-10" />
              ) : voiceState === 'speaking' ? (
                <Volume2 size={34} className="text-emerald-400 animate-pulse relative z-10" />
              ) : voiceState === 'processing' ? (
                <Radio size={32} className="text-orange-400 animate-spin relative z-10" />
              ) : (
                <Mic size={32} className="text-zinc-400 relative z-10" />
              )}

              <span className="text-[10px] font-mono uppercase tracking-wider text-zinc-300 font-semibold mt-1 relative z-10">
                {voiceState === 'listening' 
                  ? 'Listening' 
                  : voiceState === 'speaking' 
                  ? 'Speaking' 
                  : voiceState === 'processing' 
                  ? 'Reasoning' 
                  : 'Start Voice'}
              </span>
            </div>
          </button>
        </div>

        {/* Audio Frequency Spectrum Visualizer */}
        <div className="flex items-center gap-1.5 h-8 mt-6">
          {[6, 14, 26, 34, 18, 30, 16, 24, 32, 14, 10, 28, 12].map((height, idx) => (
            <div
              key={idx}
              className={`w-1 rounded-full transition-all duration-150 ${
                voiceState === 'listening'
                  ? 'bg-gradient-to-t from-red-600 to-orange-400 animate-pulse'
                  : voiceState === 'speaking'
                  ? 'bg-gradient-to-t from-emerald-500 to-amber-300 animate-pulse'
                  : voiceState === 'processing'
                  ? 'bg-orange-500 animate-ping'
                  : 'bg-zinc-800'
              }`}
              style={{
                height: (voiceState === 'listening' || voiceState === 'speaking') ? `${height}px` : '4px',
                animationDelay: `${idx * 0.07}s`,
              }}
            ></div>
          ))}
        </div>

        {/* Live Status Description */}
        <p className="text-xs text-zinc-400 mt-2.5 text-center max-w-xs font-medium min-h-[18px]">
          {interimTranscript ? `"${interimTranscript}"` : statusMessage}
        </p>

        {/* FOUR EXPLICIT SESSION CONTROLS: Start, Stop, Mute, Interrupt */}
        <div className="flex items-center gap-2 mt-4 p-1.5 rounded-2xl bg-[#141418] border border-white/10 shadow-lg">
          {/* 1. START CONTROL */}
          <button
            onClick={handleStartVoice}
            disabled={voiceState === 'listening'}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
              voiceState === 'listening'
                ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                : 'bg-orange-500 hover:bg-orange-600 text-white shadow-sm active:scale-95'
            }`}
            title="Start Microphone Recording"
          >
            <Play size={12} fill="currentColor" />
            <span>Start</span>
          </button>

          {/* 2. STOP CONTROL */}
          <button
            onClick={handleStopVoice}
            disabled={voiceState === 'idle'}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
              voiceState === 'idle'
                ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                : 'bg-zinc-700 hover:bg-zinc-600 text-white active:scale-95'
            }`}
            title="Stop Microphone Recording"
          >
            <Square size={12} fill="currentColor" />
            <span>Stop</span>
          </button>

          {/* 3. INTERRUPT SPEECH CONTROL */}
          <button
            onClick={handleInterruptSpeech}
            disabled={voiceState !== 'speaking'}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
              voiceState === 'speaking'
                ? 'bg-amber-500 hover:bg-amber-600 text-black animate-pulse shadow-md active:scale-95'
                : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
            }`}
            title="Interrupt Safar while speaking"
          >
            <Hand size={12} />
            <span>Interrupt</span>
          </button>

          {/* 4. MUTE CONTROL */}
          <button
            onClick={handleToggleMute}
            className={`px-2.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1 transition-all ${
              isMuted
                ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                : 'bg-white/5 text-zinc-300 hover:text-white'
            }`}
            title={isMuted ? 'Unmute TTS' : 'Mute TTS'}
          >
            {isMuted ? <VolumeX size={13} /> : <Volume2 size={13} />}
            <span>{isMuted ? 'Muted' : 'Mute'}</span>
          </button>
        </div>
      </div>

      {/* Transcript Log & Quick Text-Chat Fallback Area */}
      <div className="space-y-2 bg-[#121215] rounded-2xl p-3 border border-white/[0.08] max-h-48 flex flex-col justify-between">
        <div className="flex items-center justify-between text-xs text-zinc-400 pb-1 border-b border-white/5">
          <span className="font-semibold text-zinc-300">Live Dialogue</span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setTranscripts([])}
              className="text-zinc-500 hover:text-zinc-300 text-[11px]"
              title="Clear transcript"
            >
              Clear
            </button>
            <button
              onClick={() => {
                const lastItem = transcripts[transcripts.length - 1];
                onSwitchToChat(lastItem?.text);
              }}
              className="text-orange-400 hover:text-orange-300 flex items-center gap-1 text-[11px] font-medium"
            >
              <MessageSquare size={12} />
              Continue in Chat
            </button>
          </div>
        </div>

        {/* Scrollable Transcripts */}
        <div className="space-y-1.5 overflow-y-auto max-h-24 py-1 pr-1">
          {transcripts.map((item) => {
            const isUser = item.sender === 'user';
            const isAr = item.language === 'ar';
            return (
              <div
                key={item.id}
                dir={isAr ? 'rtl' : 'ltr'}
                className={`text-xs p-2 rounded-xl transition-all ${
                  isUser
                    ? 'bg-orange-500/10 border border-orange-500/20 text-orange-200 ml-4 text-right'
                    : 'bg-white/5 border border-white/5 text-zinc-300 mr-4'
                }`}
              >
                <div className="flex items-center justify-between text-[10px] text-zinc-500 mb-0.5">
                  <span className="font-semibold uppercase tracking-wider">
                    {isUser ? 'You' : 'Safar (Voice)'}
                  </span>
                  <span>{item.timestamp}</span>
                </div>
                <p className="leading-relaxed">{item.text}</p>
              </div>
            );
          })}
        </div>

        {/* Text Fallback Input inside Voice Screen */}
        <form onSubmit={handleTextFallbackSubmit} className="pt-1.5 border-t border-white/5 flex items-center gap-1.5">
          <input
            type="text"
            value={textFallbackQuery}
            onChange={(e) => setTextFallbackQuery(e.target.value)}
            placeholder="Or type here to speak in English, বাংলা, العربية..."
            className="flex-1 bg-[#18181D] border border-white/10 rounded-xl px-2.5 py-1.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-orange-500"
          />
          <button
            type="submit"
            disabled={!textFallbackQuery.trim() || voiceState === 'processing'}
            className="px-3 py-1.5 rounded-xl bg-orange-500 text-white font-semibold text-xs hover:bg-orange-600 disabled:bg-zinc-800 disabled:text-zinc-500 transition-colors shrink-0"
          >
            Send
          </button>
        </form>
      </div>
    </div>
  );
};
