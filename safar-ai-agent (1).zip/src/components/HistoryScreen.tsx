import React, { useState, useEffect } from 'react';
import { 
  History as HistoryIcon, 
  Search, 
  Trash2, 
  Pin, 
  MessageSquare, 
  Image as ImageIcon, 
  Compass, 
  Clock, 
  Download,
  ExternalLink,
  Plus,
  Edit3,
  Check,
  X,
  AlertTriangle,
  Bot,
  Filter
} from 'lucide-react';
import { NavigationTab, ChatSession, AppTheme } from '../types';
import { 
  loadChatSessions, 
  saveAllChatSessions,
  deleteChatSession, 
  renameChatSession, 
  togglePinChatSession,
  clearAllChatHistory,
  clearAllVaultHistory,
  loadSavedVaultItems,
  SavedVaultItem,
  loadSettings
} from '../services/storageService';
import { SMART_AGENTS } from '../data/agents';

interface HistoryScreenProps {
  onOpenSession: (sessionId: string, tab: NavigationTab, prompt?: string) => void;
  onStartNewChat: () => void;
}

export const HistoryScreen: React.FC<HistoryScreenProps> = ({ 
  onOpenSession,
  onStartNewChat
}) => {
  const [sessions, setSessions] = useState<ChatSession[]>(() => loadChatSessions());
  const [vaultItems, setVaultItems] = useState<SavedVaultItem[]>(() => loadSavedVaultItems());
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeTabFilter, setActiveTabFilter] = useState<'all' | 'chats' | 'voyage' | 'image' | 'code' | 'task'>('all');
  const [appTheme, setAppTheme] = useState<AppTheme>(() => loadSettings().theme);

  // Rename modal or inline state
  const [renamingSessionId, setRenamingSessionId] = useState<string | null>(null);
  const [renameInput, setRenameInput] = useState<string>('');

  // Delete single confirmation
  const [sessionToDelete, setSessionToDelete] = useState<ChatSession | null>(null);
  const [vaultItemToDelete, setVaultItemToDelete] = useState<SavedVaultItem | null>(null);

  // Clear all confirmation
  const [showClearAllModal, setShowClearAllModal] = useState<boolean>(false);
  const [noticeMessage, setNoticeMessage] = useState<string | null>(null);

  // Refresh data on mount
  useEffect(() => {
    setSessions(loadChatSessions());
    setVaultItems(loadSavedVaultItems());
    setAppTheme(loadSettings().theme);
  }, []);

  const isLight = appTheme === 'light';

  // Toggle Pin for Chat Session
  const handleTogglePinSession = (sessionId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = togglePinChatSession(sessionId);
    setSessions(updated);
  };

  // Start Rename
  const handleStartRename = (session: ChatSession, e: React.MouseEvent) => {
    e.stopPropagation();
    setRenamingSessionId(session.id);
    setRenameInput(session.title);
  };

  // Submit Rename
  const handleSaveRename = (sessionId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!renameInput.trim()) return;
    const res = renameChatSession(sessionId, renameInput.trim());
    if (res.success) {
      setSessions(res.sessions);
      setRenamingSessionId(null);
      setNoticeMessage('Conversation renamed successfully.');
      setTimeout(() => setNoticeMessage(null), 2000);
    }
  };

  const handleCancelRename = (e: React.MouseEvent) => {
    e.stopPropagation();
    setRenamingSessionId(null);
    setRenameInput('');
  };

  // Delete Session Confirmation
  const handleConfirmDeleteSession = () => {
    if (!sessionToDelete) return;
    const res = deleteChatSession(sessionToDelete.id);
    if (res.success) {
      setSessions(res.sessions);
      setSessionToDelete(null);
      setNoticeMessage('Conversation deleted.');
      setTimeout(() => setNoticeMessage(null), 2000);
    }
  };

  // Delete Vault Item
  const handleConfirmDeleteVaultItem = () => {
    if (!vaultItemToDelete) return;
    const updated = vaultItems.filter(v => v.id !== vaultItemToDelete.id);
    setVaultItems(updated);
    setVaultItemToDelete(null);
    setNoticeMessage('Vault log removed.');
    setTimeout(() => setNoticeMessage(null), 2000);
  };

  // Clear All
  const handleConfirmClearAll = () => {
    const sCount = sessions.length;
    const vCount = vaultItems.length;
    clearAllChatHistory();
    clearAllVaultHistory();
    setSessions([]);
    setVaultItems([]);
    setShowClearAllModal(false);
    setNoticeMessage(`Successfully cleared all ${sCount} chat sessions and ${vCount} vault logs.`);
    setTimeout(() => setNoticeMessage(null), 3000);
  };

  // Script detection for Arabic/Bengali layout
  const isArabic = (text: string) => /[\u0600-\u06FF]/.test(text);
  const isBengali = (text: string) => /[\u0980-\u09FF]/.test(text);

  // Filtered Sessions
  const filteredSessions = sessions.filter(s => {
    if (activeTabFilter !== 'all' && activeTabFilter !== 'chats') return false;
    const query = searchQuery.toLowerCase();
    const matchTitle = s.title.toLowerCase().includes(query);
    const matchAgent = s.agentId.toLowerCase().includes(query);
    const matchMsg = s.messages.some(m => m.content.toLowerCase().includes(query));
    return matchTitle || matchAgent || matchMsg;
  });

  // Filtered Vault Items
  const filteredVaultItems = vaultItems.filter(it => {
    if (activeTabFilter === 'chats') return false;
    if (activeTabFilter !== 'all' && it.type !== activeTabFilter) return false;
    const query = searchQuery.toLowerCase();
    return it.title.toLowerCase().includes(query) || it.summary.toLowerCase().includes(query);
  });

  const totalItemCount = filteredSessions.length + filteredVaultItems.length;

  return (
    <div className={`flex-1 flex flex-col overflow-y-auto px-4 py-4 space-y-4 pb-12 transition-colors ${
      isLight ? 'bg-slate-50 text-slate-900' : 'bg-[#0B0B0C] text-white'
    }`}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-orange-500/15 border border-orange-500/30 text-orange-400 flex items-center justify-center font-bold">
            <HistoryIcon size={18} />
          </div>
          <div>
            <h2 className="text-lg font-bold tracking-tight">Expedition & Chat History</h2>
            <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-zinc-400'}`}>
              Search, resume, rename, and manage your agent logs
            </p>
          </div>
        </div>

        {/* Action Buttons: New Chat & Clear All */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={onStartNewChat}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white text-xs font-semibold shadow-md shadow-orange-500/20 transition-all"
            title="Start fresh conversation"
          >
            <Plus size={14} />
            <span className="text-[11px]">New Chat</span>
          </button>
          
          {(sessions.length > 0 || vaultItems.length > 0) && (
            <button
              onClick={() => setShowClearAllModal(true)}
              className={`p-1.5 rounded-xl border transition-all text-xs ${
                isLight 
                  ? 'bg-white border-slate-200 text-red-500 hover:bg-red-50' 
                  : 'bg-[#141418] border-white/10 text-zinc-400 hover:text-red-400 hover:border-red-500/30'
              }`}
              title="Clear all history (requires confirmation)"
            >
              <Trash2 size={15} />
            </button>
          )}
        </div>
      </div>

      {/* Notice Banner */}
      {noticeMessage && (
        <div className="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-xs text-emerald-300 flex items-center gap-2 animate-fadeIn">
          <Check size={14} className="text-emerald-400 shrink-0" />
          <span className="text-[11px] font-medium">{noticeMessage}</span>
        </div>
      )}

      {/* Search Input */}
      <div className="relative">
        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search conversations, prompts, itinerary logs..."
          className={`w-full rounded-xl pl-9 pr-8 py-2.5 text-xs focus:outline-none focus:border-orange-500 border transition-all ${
            isLight 
              ? 'bg-white border-slate-300 text-slate-800 placeholder-slate-400' 
              : 'bg-[#141418] border-white/10 text-white placeholder-zinc-500'
          }`}
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery('')}
            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-white"
          >
            <X size={14} />
          </button>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar text-xs">
        {[
          { id: 'all', label: 'All History' },
          { id: 'chats', label: `Chats (${sessions.length})` },
          { id: 'voyage', label: 'Voyages' },
          { id: 'image', label: 'Artworks' },
          { id: 'code', label: 'Code' },
          { id: 'task', label: 'Tasks' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTabFilter(tab.id as any)}
            className={`px-3 py-1.5 rounded-xl capitalize whitespace-nowrap text-xs font-medium transition-all ${
              activeTabFilter === tab.id
                ? 'bg-orange-500 text-white shadow-sm'
                : isLight
                  ? 'bg-white text-slate-600 border border-slate-200 hover:border-slate-300'
                  : 'bg-[#141418] text-zinc-400 border border-white/5 hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Content List */}
      <div className="space-y-3">
        {totalItemCount === 0 ? (
          <div className={`p-8 text-center rounded-2xl border text-xs space-y-2 ${
            isLight ? 'bg-white border-slate-200 text-slate-500' : 'bg-[#141418] border-white/5 text-zinc-500'
          }`}>
            <HistoryIcon size={24} className="mx-auto text-zinc-600 mb-1" />
            <p className="font-semibold text-zinc-400">No logs found</p>
            <p className="text-[11px]">
              {searchQuery ? 'Try adjusting your search keywords.' : 'Start a new conversation to build your expedition logs.'}
            </p>
            <button
              onClick={onStartNewChat}
              className="mt-2 inline-flex items-center gap-1 px-3 py-1.5 rounded-xl bg-orange-500 text-white text-xs font-semibold"
            >
              <Plus size={13} />
              <span>Start New Chat</span>
            </button>
          </div>
        ) : (
          <>
            {/* Active & Past Chat Conversations */}
            {filteredSessions.map((session) => {
              const agent = SMART_AGENTS.find(a => a.id === session.agentId) || SMART_AGENTS[0];
              const lastMsg = session.messages[session.messages.length - 1];
              const isRenaming = renamingSessionId === session.id;
              const titleIsArabic = isArabic(session.title);
              const titleIsBengali = isBengali(session.title);

              return (
                <div
                  key={session.id}
                  onClick={() => {
                    if (!isRenaming) {
                      onOpenSession(session.id, 'chat');
                    }
                  }}
                  className={`p-3.5 rounded-2xl border transition-all cursor-pointer group relative ${
                    isLight 
                      ? 'bg-white border-slate-200 hover:border-orange-400 shadow-sm' 
                      : 'bg-[#141418] border-white/[0.08] hover:border-orange-500/40'
                  }`}
                >
                  {/* Top row: Agent info + Actions */}
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-lg bg-orange-500/10 text-orange-400 flex items-center justify-center text-xs font-bold">
                        <MessageSquare size={13} />
                      </div>
                      <span className="text-[10px] font-mono uppercase text-orange-400 font-semibold">
                        {agent.name}
                      </span>
                      <span className={`text-[10px] font-mono ${isLight ? 'text-slate-400' : 'text-zinc-500'}`}>
                        {session.messages.length} msg{session.messages.length === 1 ? '' : 's'}
                      </span>
                      <span className={`text-[10px] ${isLight ? 'text-slate-400' : 'text-zinc-500'}`}>
                        • {new Date(session.updatedAt).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                      </span>
                    </div>

                    <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                      {/* Pin button */}
                      <button
                        type="button"
                        onClick={(e) => handleTogglePinSession(session.id, e)}
                        className={`p-1.5 rounded-lg transition-colors ${
                          session.pinned
                            ? 'text-orange-400 bg-orange-500/10'
                            : isLight ? 'text-slate-400 hover:text-slate-700' : 'text-zinc-500 hover:text-zinc-300'
                        }`}
                        title={session.pinned ? 'Unpin' : 'Pin conversation'}
                      >
                        <Pin size={13} />
                      </button>

                      {/* Rename button */}
                      <button
                        type="button"
                        onClick={(e) => handleStartRename(session, e)}
                        className={`p-1.5 rounded-lg transition-colors ${
                          isLight ? 'text-slate-400 hover:text-orange-500' : 'text-zinc-500 hover:text-orange-300'
                        }`}
                        title="Rename conversation"
                      >
                        <Edit3 size={13} />
                      </button>

                      {/* Delete button (opens confirmation) */}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSessionToDelete(session);
                        }}
                        className="p-1.5 rounded-lg text-zinc-500 hover:text-red-400 transition-colors"
                        title="Delete conversation (confirm required)"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </div>

                  {/* Title or Inline Rename input */}
                  {isRenaming ? (
                    <div className="flex items-center gap-2 my-1" onClick={(e) => e.stopPropagation()}>
                      <input
                        type="text"
                        value={renameInput}
                        onChange={(e) => setRenameInput(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') handleSaveRename(session.id, e as any);
                          if (e.key === 'Escape') handleCancelRename(e as any);
                        }}
                        autoFocus
                        className={`flex-1 rounded-lg px-2.5 py-1 text-xs font-semibold focus:outline-none focus:border-orange-500 border ${
                          isLight 
                            ? 'bg-slate-100 border-slate-300 text-slate-900' 
                            : 'bg-[#1E1E24] border-white/20 text-white'
                        }`}
                      />
                      <button
                        type="button"
                        onClick={(e) => handleSaveRename(session.id, e)}
                        className="p-1.5 rounded-lg bg-orange-500 hover:bg-orange-600 text-white"
                        title="Save rename"
                      >
                        <Check size={13} />
                      </button>
                      <button
                        type="button"
                        onClick={handleCancelRename}
                        className="p-1.5 rounded-lg bg-zinc-700 hover:bg-zinc-600 text-zinc-300"
                        title="Cancel"
                      >
                        <X size={13} />
                      </button>
                    </div>
                  ) : (
                    <h4 
                      dir={titleIsArabic ? 'rtl' : 'ltr'} 
                      className={`text-xs font-semibold group-hover:text-orange-400 transition-colors ${
                        titleIsBengali ? 'leading-relaxed' : ''
                      } ${titleIsArabic ? 'font-arabic text-right' : ''}`}
                    >
                      {session.title}
                    </h4>
                  )}

                  {/* Last message preview */}
                  {lastMsg && (
                    <p 
                      dir={isArabic(lastMsg.content) ? 'rtl' : 'ltr'}
                      className={`text-[11px] line-clamp-2 leading-relaxed mt-1 ${
                        isLight ? 'text-slate-500' : 'text-zinc-400'
                      } ${isArabic(lastMsg.content) ? 'font-arabic text-right' : ''} ${
                        isBengali(lastMsg.content) ? 'leading-loose' : ''
                      }`}
                    >
                      {lastMsg.content.replace(/[*#`]/g, '')}
                    </p>
                  )}
                </div>
              );
            })}

            {/* Saved Vault Items (Voyages, Images, Tasks, Code) */}
            {filteredVaultItems.map((item) => (
              <div
                key={item.id}
                onClick={() => {
                  if (item.type === 'image') {
                    onOpenSession(item.id, 'images', item.title);
                  } else {
                    onOpenSession(item.id, 'chat', item.title);
                  }
                }}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer group ${
                  isLight 
                    ? 'bg-white border-slate-200 hover:border-orange-400 shadow-sm' 
                    : 'bg-[#141418] border-white/[0.08] hover:border-orange-500/40'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-lg bg-orange-500/10 text-orange-400 flex items-center justify-center">
                      {item.type === 'image' ? (
                        <ImageIcon size={13} />
                      ) : item.type === 'voyage' ? (
                        <Compass size={13} />
                      ) : (
                        <HistoryIcon size={13} />
                      )}
                    </div>
                    <span className="text-[10px] font-mono uppercase text-orange-400 font-semibold">
                      {item.type}
                    </span>
                    <span className={`text-[10px] ${isLight ? 'text-slate-400' : 'text-zinc-500'} font-mono`}>
                      {item.timestamp}
                    </span>
                  </div>

                  <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setVaultItemToDelete(item);
                      }}
                      className="p-1.5 rounded-lg text-zinc-500 hover:text-red-400 transition-colors"
                      title="Delete log"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>

                <h4 className="text-xs font-semibold group-hover:text-orange-400 transition-colors">
                  {item.title}
                </h4>

                <p className={`text-[11px] line-clamp-2 leading-relaxed mt-1 ${
                  isLight ? 'text-slate-500' : 'text-zinc-400'
                }`}>
                  {item.summary}
                </p>
              </div>
            ))}
          </>
        )}
      </div>

      {/* ----------------- Delete Single Session Confirmation Modal ----------------- */}
      {sessionToDelete && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className={`w-full max-w-sm rounded-2xl border p-4.5 space-y-3.5 shadow-2xl ${
            isLight ? 'bg-white border-slate-300 text-slate-900' : 'bg-[#16161C] border-white/15 text-white'
          }`}>
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-xl bg-red-500/20 text-red-400 flex items-center justify-center shrink-0">
                <Trash2 size={18} />
              </div>
              <div>
                <h3 className="text-sm font-bold">Delete Conversation?</h3>
                <p className={`text-xs mt-1 leading-relaxed ${isLight ? 'text-slate-600' : 'text-zinc-400'}`}>
                  Are you sure you want to delete <strong className="text-orange-400">"{sessionToDelete.title}"</strong>? All messages in this thread will be permanently removed.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setSessionToDelete(null)}
                className={`flex-1 py-2 rounded-xl text-xs font-semibold border transition-all ${
                  isLight ? 'bg-slate-100 border-slate-300 text-slate-700 hover:bg-slate-200' : 'bg-white/5 border-white/10 text-zinc-300 hover:bg-white/10'
                }`}
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteSession}
                className="flex-1 py-2 rounded-xl text-xs font-bold bg-red-500 hover:bg-red-600 text-white shadow-md shadow-red-500/25 transition-all flex items-center justify-center gap-1"
              >
                <Trash2 size={13} />
                <span>Delete</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ----------------- Delete Single Vault Item Confirmation Modal ----------------- */}
      {vaultItemToDelete && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className={`w-full max-w-sm rounded-2xl border p-4.5 space-y-3.5 shadow-2xl ${
            isLight ? 'bg-white border-slate-300 text-slate-900' : 'bg-[#16161C] border-white/15 text-white'
          }`}>
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-xl bg-red-500/20 text-red-400 flex items-center justify-center shrink-0">
                <Trash2 size={18} />
              </div>
              <div>
                <h3 className="text-sm font-bold">Remove Vault Item?</h3>
                <p className={`text-xs mt-1 leading-relaxed ${isLight ? 'text-slate-600' : 'text-zinc-400'}`}>
                  Remove <strong className="text-orange-400">"{vaultItemToDelete.title}"</strong> from your saved expedition logs?
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setVaultItemToDelete(null)}
                className={`flex-1 py-2 rounded-xl text-xs font-semibold border transition-all ${
                  isLight ? 'bg-slate-100 border-slate-300 text-slate-700 hover:bg-slate-200' : 'bg-white/5 border-white/10 text-zinc-300 hover:bg-white/10'
                }`}
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteVaultItem}
                className="flex-1 py-2 rounded-xl text-xs font-bold bg-red-500 hover:bg-red-600 text-white shadow-md shadow-red-500/25 transition-all"
              >
                Remove
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ----------------- Clear All History Confirmation Modal ----------------- */}
      {showClearAllModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className={`w-full max-w-sm rounded-2xl border p-4.5 space-y-3.5 shadow-2xl ${
            isLight ? 'bg-white border-slate-300 text-slate-900' : 'bg-[#16161C] border-white/15 text-white'
          }`}>
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-xl bg-red-500/20 text-red-400 flex items-center justify-center shrink-0">
                <AlertTriangle size={18} />
              </div>
              <div>
                <h3 className="text-sm font-bold">Clear All History?</h3>
                <p className={`text-xs mt-1 leading-relaxed ${isLight ? 'text-slate-600' : 'text-zinc-400'}`}>
                  Are you sure you want to delete all <strong>{sessions.length}</strong> chat conversations and <strong>{vaultItems.length}</strong> vault logs? This action will permanently erase your local logs and cannot be undone.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowClearAllModal(false)}
                className={`flex-1 py-2 rounded-xl text-xs font-semibold border transition-all ${
                  isLight ? 'bg-slate-100 border-slate-300 text-slate-700 hover:bg-slate-200' : 'bg-white/5 border-white/10 text-zinc-300 hover:bg-white/10'
                }`}
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmClearAll}
                className="flex-1 py-2 rounded-xl text-xs font-bold bg-red-500 hover:bg-red-600 text-white shadow-md shadow-red-500/25 transition-all flex items-center justify-center gap-1.5"
              >
                <Trash2 size={13} />
                <span>Yes, Clear All</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
