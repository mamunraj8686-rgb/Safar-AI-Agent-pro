import React, { useState, useRef } from 'react';
import { 
  Users, 
  Search, 
  ListChecks, 
  PenTool, 
  ShieldCheck, 
  Crown, 
  Play, 
  RotateCcw, 
  Copy, 
  Check, 
  Volume2, 
  MessageSquare, 
  Sparkles, 
  ChevronDown, 
  ChevronUp, 
  AlertCircle,
  RefreshCw,
  ArrowRight,
  Square,
} from 'lucide-react';
import { getApiUrl } from '../services/apiConfig';

interface AgentTeamScreenProps {
  onSendToChat?: (text: string) => void;
}

type TeamRole = 
  | 'coordinator_plan'
  | 'research'
  | 'planning'
  | 'writing'
  | 'review'
  | 'coordinator_finalize';

interface AgentRoleCard {
  role: TeamRole;
  name: string;
  title: string;
  description: string;
  icon: any;
  color: string;
  status: 'idle' | 'working' | 'completed' | 'error';
  output?: string;
}

export const AgentTeamScreen: React.FC<AgentTeamScreenProps> = ({ onSendToChat }) => {
  const [objective, setObjective] = useState<string>('');
  const [language, setLanguage] = useState<'en' | 'bn' | 'ar'>('en');
  const [isExecuting, setIsExecuting] = useState<boolean>(false);
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(-1);
  const [expandedStep, setExpandedStep] = useState<TeamRole | null>('coordinator_finalize');
  const [copied, setCopied] = useState<boolean>(false);
  const [generalError, setGeneralError] = useState<string | null>(null);

  const abortControllerRef = useRef<AbortController | null>(null);
  const cancelRequestedRef = useRef<boolean>(false);

  const initialRoles: AgentRoleCard[] = [
    {
      role: 'coordinator_plan',
      name: 'Coordinator Agent',
      title: 'Task Strategy & Role Distribution',
      description: 'Deconstructs the objective and assigns specific mandates to team members.',
      icon: Crown,
      color: '#F97316',
      status: 'idle',
    },
    {
      role: 'research',
      name: 'Research Agent',
      title: 'Evidence & Domain Investigation',
      description: 'Gathers empirical facts, constraints, and relevant context.',
      icon: Search,
      color: '#FB923C',
      status: 'idle',
    },
    {
      role: 'planning',
      name: 'Planning Agent',
      title: 'Architecture & Milestone Roadmap',
      description: 'Synthesizes research into a structured blueprint and section flow.',
      icon: ListChecks,
      color: '#EA580C',
      status: 'idle',
    },
    {
      role: 'writing',
      name: 'Writing Agent',
      title: 'Comprehensive Content Drafting',
      description: 'Drafts the full, deep deliverable following the architecture.',
      icon: PenTool,
      color: '#F59E0B',
      status: 'idle',
    },
    {
      role: 'review',
      name: 'Review Agent',
      title: 'Critical Audit & Editorial Polish',
      description: 'Evaluates veracity, refines weaknesses, and polishes tone.',
      icon: ShieldCheck,
      color: '#34D399',
      status: 'idle',
    },
    {
      role: 'coordinator_finalize',
      name: 'Coordinator Executive Delivery',
      title: 'Final Unified Deliverable',
      description: 'Performs executive sign-off and presents one authoritative final answer.',
      icon: Crown,
      color: '#F97316',
      status: 'idle',
    },
  ];

  const [roles, setRoles] = useState<AgentRoleCard[]>(initialRoles);

  const sampleObjectives = [
    {
      label: 'Eco-Tourism Launch',
      text: 'Design a strategic launch blueprint for an eco-friendly expedition collective in the Nordic Fjords',
      lang: 'en' as const,
    },
    {
      label: 'বাংলা: পর্যটন উদ্যোগ',
      text: 'সুন্দরবনে পরিবেশবান্ধব কমিউনিটি পর্যটনের একটি পূর্ণাঙ্গ গবেষণাভিত্তিক বাস্তবায়ন পরিকল্পনা তৈরি করুন',
      lang: 'bn' as const,
    },
    {
      label: 'العربية: تقنية السفر الذكي',
      text: 'إعداد خطة متكاملة لتطبيق سياحي ذكي يعتمد على الذكاء الاصطناعي للمسافرين في الخليج العربي',
      lang: 'ar' as const,
    },
  ];

  // Execute an individual step in the pipeline
  const executeStep = async (
    role: TeamRole,
    prevOutputs: Record<string, string>,
    signal?: AbortSignal
  ): Promise<string> => {
    const res = await fetch(getApiUrl('/api/agent-team/execute-step'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        role,
        objective,
        language,
        previousOutputs: prevOutputs,
      }),
      signal,
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || `Step ${role} execution failed`);
    }
    return data.output || 'Step completed.';
  };

  const handleCancel = () => {
    cancelRequestedRef.current = true;
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    setIsExecuting(false);
    setGeneralError('Team execution halted by user.');
  };

  // Run the full 5-agent team collaborative pipeline
  const handleRunFullTeam = async () => {
    if (!objective.trim()) {
      setGeneralError('Please enter an objective for the agent team');
      return;
    }

    cancelRequestedRef.current = false;
    abortControllerRef.current = new AbortController();
    const currentSignal = abortControllerRef.current.signal;

    setIsExecuting(true);
    setGeneralError(null);

    // Reset status to idle
    setRoles(prev => prev.map(r => ({ ...r, status: 'idle', output: undefined })));

    const stepsSequence: TeamRole[] = [
      'coordinator_plan',
      'research',
      'planning',
      'writing',
      'review',
      'coordinator_finalize',
    ];

    const accumulatedOutputs: Record<string, string> = {};

    for (let i = 0; i < stepsSequence.length; i++) {
      if (cancelRequestedRef.current) break;
      const currentRole = stepsSequence[i];
      setCurrentStepIndex(i);

      // Set current role to working
      setRoles(prev => prev.map(r => r.role === currentRole ? { ...r, status: 'working' } : r));
      setExpandedStep(currentRole);

      try {
        const stepOutput = await executeStep(currentRole, accumulatedOutputs, currentSignal);
        if (cancelRequestedRef.current) break;
        accumulatedOutputs[currentRole] = stepOutput;

        // Set current role to completed
        setRoles(prev => prev.map(r => r.role === currentRole ? { ...r, status: 'completed', output: stepOutput } : r));
      } catch (err: any) {
        if (err?.name === 'AbortError' || cancelRequestedRef.current) {
          setRoles(prev => prev.map(r => r.role === currentRole ? { ...r, status: 'idle' } : r));
          setIsExecuting(false);
          return;
        }
        console.error(`Error in role ${currentRole}:`, err);
        setRoles(prev => prev.map(r => r.role === currentRole ? { ...r, status: 'error', output: `Error: ${err?.message || 'Execution failed'}` } : r));
        setGeneralError(`Team execution stopped at ${currentRole}: ${err?.message || 'Failed'}. You can retry this step.`);
        setIsExecuting(false);
        return;
      }
    }

    if (!cancelRequestedRef.current) {
      setIsExecuting(false);
      setCurrentStepIndex(stepsSequence.length);
      setExpandedStep('coordinator_finalize');
    }
  };

  // Retry a specific step that failed without re-running prior completed steps
  const handleRetryStep = async (targetRole: TeamRole) => {
    const roleIndex = roles.findIndex(r => r.role === targetRole);
    if (roleIndex === -1) return;

    setIsExecuting(true);
    setGeneralError(null);

    // Gather outputs of all previous completed steps
    const accumulatedOutputs: Record<string, string> = {};
    for (let i = 0; i < roleIndex; i++) {
      if (roles[i].output) {
        accumulatedOutputs[roles[i].role] = roles[i].output!;
      }
    }

    setRoles(prev => prev.map(r => r.role === targetRole ? { ...r, status: 'working' } : r));
    setExpandedStep(targetRole);

    try {
      const stepOutput = await executeStep(targetRole, accumulatedOutputs);
      setRoles(prev => prev.map(r => r.role === targetRole ? { ...r, status: 'completed', output: stepOutput } : r));
      
      // If there are subsequent steps, ask or continue
      setIsExecuting(false);
    } catch (err: any) {
      setRoles(prev => prev.map(r => r.role === targetRole ? { ...r, status: 'error', output: `Error: ${err?.message || 'Retry failed'}` } : r));
      setGeneralError(`Step retry failed: ${err?.message}`);
      setIsExecuting(false);
    }
  };

  const completedCount = roles.filter(r => r.status === 'completed').length;
  const progressPercent = Math.round((completedCount / roles.length) * 100);

  const finalDeliverable = roles.find(r => r.role === 'coordinator_finalize')?.output;

  const copyFinalResult = () => {
    if (!finalDeliverable) return;
    navigator.clipboard.writeText(finalDeliverable);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const playSpeech = (text: string) => {
    if (!('speechSynthesis' in window) || !text) return;
    window.speechSynthesis.cancel();
    const cleanText = text.replace(/[*#`_\[\]]/g, '');
    const utter = new SpeechSynthesisUtterance(cleanText);
    if (language === 'bn') utter.lang = 'bn-BD';
    else if (language === 'ar') utter.lang = 'ar-SA';
    else utter.lang = 'en-US';
    window.speechSynthesis.speak(utter);
  };

  return (
    <div className="space-y-4">
      {/* Team Header Card */}
      <div className="p-4 rounded-2xl bg-gradient-to-br from-[#1A1612] via-[#141418] to-[#0E0E12] border border-orange-500/30 space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-orange-500/20 text-orange-400 flex items-center justify-center font-bold">
              <Users size={18} />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white tracking-tight flex items-center gap-1.5">
                <span>Safar 5-Agent Swarm</span>
                <span className="text-[10px] font-mono uppercase bg-orange-500/10 text-orange-400 border border-orange-500/30 px-1.5 py-0.5 rounded">
                  Coordinated Swarm
                </span>
              </h3>
              <p className="text-[11px] text-zinc-400">
                Coordinator · Research · Planning · Writing · Review
              </p>
            </div>
          </div>

          <div className="text-right">
            <span className="text-xs font-mono font-bold text-orange-400">{progressPercent}%</span>
            <span className="text-[10px] text-zinc-500 block">Progress</span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full h-1.5 bg-zinc-800 rounded-full overflow-hidden">
          <div 
            className="h-full bg-gradient-to-r from-orange-600 via-orange-500 to-amber-300 transition-all duration-500 rounded-full"
            style={{ width: `${progressPercent}%` }}
          ></div>
        </div>
      </div>

      {generalError && (
        <div className="p-3 rounded-xl bg-red-950/40 border border-red-500/30 text-xs text-red-200 flex items-start gap-2">
          <AlertCircle size={15} className="text-red-400 shrink-0 mt-0.5" />
          <p>{generalError}</p>
        </div>
      )}

      {/* Task Input Box */}
      <div className="space-y-3 bg-[#141418] p-3.5 rounded-2xl border border-white/[0.08]">
        <div>
          <div className="flex items-center justify-between text-xs text-zinc-300 mb-1">
            <label className="font-semibold text-white">Team Objective / Complex Task</label>
            <div className="flex items-center gap-1">
              <span className="text-zinc-500 text-[11px]">Language:</span>
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value as any)}
                className="bg-[#18181D] text-xs text-orange-400 font-semibold border border-white/10 rounded-lg px-2 py-0.5"
              >
                <option value="en">English</option>
                <option value="bn">বাংলা (Bengali)</option>
                <option value="ar">العربية (Arabic)</option>
              </select>
            </div>
          </div>
          <textarea
            value={objective}
            onChange={(e) => setObjective(e.target.value)}
            placeholder="Assign a complex objective to the 5-Agent team (e.g. Plan a full market entry strategy, write a comprehensive whitepaper, or formulate a multi-week expedition)..."
            rows={3}
            className="w-full bg-[#18181D] border border-white/10 rounded-xl p-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-orange-500"
          />
        </div>

        {/* Quick Sample Objective Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          {sampleObjectives.map((so, idx) => (
            <button
              key={idx}
              onClick={() => {
                setObjective(so.text);
                setLanguage(so.lang);
              }}
              className="text-[11px] whitespace-nowrap shrink-0 px-2.5 py-1 rounded-lg bg-white/5 text-zinc-300 hover:text-orange-400 transition-colors"
            >
              {so.label}
            </button>
          ))}
        </div>

        {/* Start / Stop Team Execution Button */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleRunFullTeam}
            disabled={isExecuting || !objective.trim()}
            className="flex-1 py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 disabled:bg-zinc-800 disabled:text-zinc-500 text-white font-semibold text-xs flex items-center justify-center gap-2 transition-all shadow-md shadow-orange-500/25 active:scale-98"
          >
            {isExecuting ? (
              <>
                <RefreshCw size={14} className="animate-spin" />
                <span>Agents Coordinating (Step {currentStepIndex + 1}/6)...</span>
              </>
            ) : (
              <>
                <Play size={14} fill="currentColor" />
                <span>Deploy Safar 5-Agent Team</span>
              </>
            )}
          </button>

          {isExecuting && (
            <button
              onClick={handleCancel}
              className="py-2.5 px-3.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold flex items-center gap-1.5 transition-colors border border-white/10 active:scale-95"
              title="Stop execution to save API calls"
            >
              <Square size={12} className="text-red-400 fill-current" />
              <span>Stop</span>
            </button>
          )}
        </div>
      </div>

      {/* The 5 Agent Roles Pipeline Cards */}
      <div className="space-y-2">
        <h4 className="text-xs font-semibold text-zinc-300 flex items-center justify-between">
          <span>Agent Pipeline & Intermediate Deliverables</span>
          <span className="text-[10px] text-zinc-500 font-mono">
            {completedCount} of {roles.length} Done
          </span>
        </h4>

        {roles.map((roleCard) => {
          const Icon = roleCard.icon;
          const isExpanded = expandedStep === roleCard.role;
          const isWorking = roleCard.status === 'working';
          const isDone = roleCard.status === 'completed';
          const isError = roleCard.status === 'error';

          return (
            <div
              key={roleCard.role}
              className={`rounded-2xl border transition-all ${
                isWorking
                  ? 'bg-[#18181F] border-orange-500/60 shadow-lg shadow-orange-500/10'
                  : isDone
                  ? 'bg-[#141418] border-white/10'
                  : isError
                  ? 'bg-red-950/20 border-red-500/40'
                  : 'bg-[#121215] border-white/5 opacity-80'
              }`}
            >
              {/* Card Header Accordion Trigger */}
              <div
                onClick={() => setExpandedStep(isExpanded ? null : roleCard.role)}
                className="p-3 flex items-center justify-between cursor-pointer"
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div
                    className={`w-7 h-7 rounded-xl flex items-center justify-center shrink-0 ${
                      isWorking
                        ? 'bg-orange-500 text-white animate-pulse'
                        : isDone
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : isError
                        ? 'bg-red-500/20 text-red-400'
                        : 'bg-white/5 text-zinc-400'
                    }`}
                  >
                    {isWorking ? (
                      <RefreshCw size={13} className="animate-spin" />
                    ) : isDone ? (
                      <Check size={14} />
                    ) : isError ? (
                      <AlertCircle size={14} />
                    ) : (
                      <Icon size={14} />
                    )}
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <h5 className="text-xs font-bold text-white truncate">{roleCard.name}</h5>
                      <span className={`text-[9px] font-mono uppercase px-1.5 py-0.2 rounded ${
                        isWorking
                          ? 'bg-orange-500/20 text-orange-400 font-bold'
                          : isDone
                          ? 'bg-emerald-500/10 text-emerald-400'
                          : isError
                          ? 'bg-red-500/20 text-red-300'
                          : 'bg-white/5 text-zinc-500'
                      }`}>
                        {roleCard.status}
                      </span>
                    </div>
                    <p className="text-[10px] text-zinc-400 truncate">{roleCard.title}</p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  {isError && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleRetryStep(roleCard.role);
                      }}
                      className="px-2 py-0.5 rounded-lg bg-red-600 text-white text-[10px] font-semibold flex items-center gap-1 hover:bg-red-500"
                    >
                      <RotateCcw size={10} />
                      Retry
                    </button>
                  )}
                  {isExpanded ? <ChevronUp size={15} className="text-zinc-400" /> : <ChevronDown size={15} className="text-zinc-500" />}
                </div>
              </div>

              {/* Accordion Content with real output */}
              {isExpanded && (
                <div className="px-3 pb-3 pt-1 border-t border-white/5 space-y-2">
                  <p className="text-[11px] text-zinc-400 italic">
                    {roleCard.description}
                  </p>

                  {roleCard.output ? (
                    <div className="p-2.5 rounded-xl bg-black/60 border border-white/10 text-xs text-zinc-200 whitespace-pre-line leading-relaxed max-h-60 overflow-y-auto">
                      {roleCard.output}
                    </div>
                  ) : isWorking ? (
                    <div className="p-3 text-center text-xs text-orange-400 flex items-center justify-center gap-2">
                      <RefreshCw size={13} className="animate-spin" />
                      <span>{roleCard.name} is reasoning and processing with Gemini...</span>
                    </div>
                  ) : (
                    <div className="p-2 text-center text-[11px] text-zinc-500">
                      Waiting for pipeline sequence...
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Final Executive Deliverable Banner */}
      {finalDeliverable && (
        <div className="p-4 rounded-2xl bg-[#141418] border-2 border-orange-500/50 space-y-2.5 shadow-xl animate-in fade-in">
          <div className="flex items-center justify-between pb-1 border-b border-white/10">
            <div className="flex items-center gap-1.5 text-xs font-bold text-orange-400">
              <Crown size={15} />
              <span>Coordinator Executive Answer</span>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                onClick={() => playSpeech(finalDeliverable)}
                className="p-1.5 rounded-lg bg-white/5 text-zinc-300 hover:text-white"
                title="Read Aloud"
              >
                <Volume2 size={13} />
              </button>
              <button
                onClick={copyFinalResult}
                className="p-1.5 rounded-lg bg-white/5 text-zinc-300 hover:text-white"
                title="Copy Final Answer"
              >
                {copied ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
              </button>
              {onSendToChat && (
                <button
                  onClick={() => onSendToChat(`Safar 5-Agent Team Output:\n\n${finalDeliverable}`)}
                  className="px-2.5 py-1 rounded-lg bg-orange-500 text-white font-medium text-xs hover:bg-orange-600 flex items-center gap-1"
                  title="Send to Chat"
                >
                  <MessageSquare size={13} />
                  <span>Chat</span>
                </button>
              )}
            </div>
          </div>

          <div
            dir={language === 'ar' ? 'rtl' : 'ltr'}
            className={`text-xs text-zinc-100 whitespace-pre-line leading-relaxed font-sans ${language === 'ar' ? 'text-right' : 'text-left'}`}
          >
            {finalDeliverable}
          </div>
        </div>
      )}
    </div>
  );
};
