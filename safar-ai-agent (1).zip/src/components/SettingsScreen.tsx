import React, { useState, useEffect } from 'react';
import { 
  Settings as SettingsIcon, 
  Volume2, 
  Sparkles, 
  Sliders, 
  ShieldCheck, 
  Trash2, 
  Smartphone, 
  Check, 
  Info,
  ChevronRight,
  Cpu,
  Moon,
  Sun,
  Languages,
  Play,
  Square,
  FileText,
  Lock,
  Download,
  AlertTriangle,
  Database,
  ExternalLink,
  X
} from 'lucide-react';
import { SMART_AGENTS } from '../data/agents';
import { AppSettings, AppTheme, AppLanguage, StorageStatus } from '../types';
import { 
  loadSettings, 
  saveSettings, 
  getStorageDiagnostics, 
  clearAllChatHistory, 
  clearAllVaultHistory, 
  exportAllDataAsJSON,
  DEFAULT_SETTINGS
} from '../services/storageService';

interface SettingsScreenProps {
  onBackToHome: () => void;
  onThemeChange?: (theme: AppTheme) => void;
  onLanguageChange?: (lang: AppLanguage) => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({ 
  onBackToHome,
  onThemeChange,
  onLanguageChange
}) => {
  const [settings, setSettings] = useState<AppSettings>(() => loadSettings());
  const [diagnostics, setDiagnostics] = useState<StorageStatus>(() => getStorageDiagnostics());
  const [savedNotice, setSavedNotice] = useState<string | null>(null);
  const [saveError, setSaveError] = useState<string | null>(null);

  // Audio testing state
  const [isPlayingTestVoice, setIsPlayingTestVoice] = useState<boolean>(false);

  // Modal states
  const [showAboutModal, setShowAboutModal] = useState<boolean>(false);
  const [showPrivacyModal, setShowPrivacyModal] = useState<boolean>(false);
  const [showClearConfirmModal, setShowClearConfirmModal] = useState<boolean>(false);
  const [clearingInProgress, setClearingInProgress] = useState<boolean>(false);

  // Reload diagnostics on mount
  useEffect(() => {
    setDiagnostics(getStorageDiagnostics());
  }, []);

  const handleUpdate = <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => {
    const updated: AppSettings = {
      ...settings,
      [key]: value,
    };
    setSettings(updated);

    if (key === 'theme' && onThemeChange) {
      onThemeChange(value as AppTheme);
    }
    if (key === 'language' && onLanguageChange) {
      onLanguageChange(value as AppLanguage);
    }

    // Persist immediately to storage
    const result = saveSettings(updated);
    if (result.success) {
      setSavedNotice('Setting updated and saved');
      setSaveError(null);
      setTimeout(() => setSavedNotice(null), 1800);
      setDiagnostics(getStorageDiagnostics());
    } else {
      setSaveError(result.error || 'Could not write to local storage');
      setTimeout(() => setSaveError(null), 3500);
    }
  };

  const handleExplicitSave = () => {
    const result = saveSettings(settings);
    if (result.success) {
      setSavedNotice(
        result.storageType === 'localStorage'
          ? 'Preferences securely saved to browser storage.'
          : 'Preferences saved in-memory (persistent storage restricted).'
      );
      setSaveError(null);
      setTimeout(() => setSavedNotice(null), 2500);
      setDiagnostics(getStorageDiagnostics());
    } else {
      setSaveError(result.error || 'Failed to save preferences.');
    }
  };

  const handleTestVoice = () => {
    if (!('speechSynthesis' in window)) {
      setSaveError('Speech Synthesis is not supported in this browser.');
      setTimeout(() => setSaveError(null), 3000);
      return;
    }

    if (isPlayingTestVoice) {
      window.speechSynthesis.cancel();
      setIsPlayingTestVoice(false);
      return;
    }

    window.speechSynthesis.cancel();
    
    let samplePhrase = 'Greetings! This is your Safar AI Agent speech synthesis test.';
    let langCode = 'en-US';

    if (settings.language === 'bn') {
      samplePhrase = 'নমস্কার! এটি আপনার সফর এআই ভয়েস সিন্থেসিস পরীক্ষা।';
      langCode = 'bn-BD';
    } else if (settings.language === 'ar') {
      samplePhrase = 'مرحباً بك! هذا اختبار النطق الصوتي لمساعد سفر الذكي.';
      langCode = 'ar-SA';
    }

    const utterance = new SpeechSynthesisUtterance(samplePhrase);
    utterance.rate = settings.speechRate;
    utterance.pitch = settings.speechPitch;
    utterance.lang = langCode;

    utterance.onend = () => setIsPlayingTestVoice(false);
    utterance.onerror = () => setIsPlayingTestVoice(false);

    setIsPlayingTestVoice(true);
    window.speechSynthesis.speak(utterance);
  };

  const handleExportData = () => {
    try {
      const json = exportAllDataAsJSON();
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `safar-ai-backup-${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      setSavedNotice('Complete backup exported successfully.');
      setTimeout(() => setSavedNotice(null), 2500);
    } catch (err: any) {
      setSaveError('Export failed: ' + err?.message);
    }
  };

  const handleConfirmClearAll = () => {
    setClearingInProgress(true);
    setTimeout(() => {
      const res1 = clearAllChatHistory();
      const res2 = clearAllVaultHistory();
      setClearingInProgress(false);
      setShowClearConfirmModal(false);
      setDiagnostics(getStorageDiagnostics());
      setSavedNotice(`Cleared ${res1.clearedSessions} chat sessions and ${res2.clearedCount} vault logs.`);
      setTimeout(() => setSavedNotice(null), 3000);
    }, 400);
  };

  const isLight = settings.theme === 'light';

  return (
    <div className={`flex-1 flex flex-col overflow-y-auto px-4 py-4 space-y-4 pb-12 transition-colors ${
      isLight ? 'bg-slate-50 text-slate-900' : 'bg-[#0B0B0C] text-white'
    }`}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-orange-500/15 border border-orange-500/30 text-orange-400 flex items-center justify-center font-bold">
            <SettingsIcon size={18} />
          </div>
          <div>
            <h2 className="text-lg font-bold tracking-tight">Safar Settings</h2>
            <p className={`text-xs ${isLight ? 'text-slate-500' : 'text-zinc-400'}`}>
              Language, themes, speech synthesis & data storage
            </p>
          </div>
        </div>

        {/* Quick About Button */}
        <button
          onClick={() => setShowAboutModal(true)}
          className={`p-1.5 rounded-xl border text-xs font-medium flex items-center gap-1 transition-all ${
            isLight 
              ? 'bg-white border-slate-200 text-slate-700 hover:border-orange-400' 
              : 'bg-[#141418] border-white/10 text-zinc-300 hover:border-white/25'
          }`}
          title="About Safar AI"
        >
          <Info size={14} className="text-orange-400" />
          <span className="text-[11px]">About</span>
        </button>
      </div>

      {/* Persistence / Diagnostics Notice */}
      {diagnostics.limitationMessage ? (
        <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs text-amber-300 flex items-start gap-2.5">
          <AlertTriangle size={16} className="text-amber-400 shrink-0 mt-0.5" />
          <div className="space-y-0.5">
            <span className="font-semibold block">Storage Notice & Limitations:</span>
            <p className="text-[11px] leading-relaxed text-amber-200/90">
              {diagnostics.limitationMessage}
            </p>
          </div>
        </div>
      ) : (
        <div className={`p-2.5 rounded-xl border flex items-center justify-between text-xs ${
          isLight ? 'bg-white border-slate-200 text-slate-600' : 'bg-[#141418] border-white/5 text-zinc-400'
        }`}>
          <div className="flex items-center gap-2">
            <Database size={13} className="text-emerald-400" />
            <span className="text-[11px]">Storage Engine: <strong className={isLight ? 'text-slate-800' : 'text-zinc-200'}>Active LocalStorage</strong></span>
          </div>
          <span className="text-[10px] font-mono text-emerald-400 font-semibold px-2 py-0.5 rounded bg-emerald-500/10">
            {diagnostics.sessionCount} chats ({Math.round(diagnostics.estimatedBytes / 1024)} KB)
          </span>
        </div>
      )}

      {/* Success Alert */}
      {savedNotice && (
        <div className="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-xs text-emerald-300 flex items-center gap-2 animate-fadeIn">
          <Check size={14} className="text-emerald-400 shrink-0" />
          <span className="text-[11px] font-medium">{savedNotice}</span>
        </div>
      )}

      {/* Error Alert */}
      {saveError && (
        <div className="p-2.5 rounded-xl bg-red-950/40 border border-red-500/30 text-xs text-red-300 flex items-center gap-2">
          <AlertTriangle size={14} className="text-red-400 shrink-0" />
          <span className="text-[11px]">{saveError}</span>
        </div>
      )}

      {/* Section 1: Appearance & Theme */}
      <div className={`p-3.5 rounded-2xl border space-y-3 transition-colors ${
        isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-[#141418] border-white/[0.08]'
      }`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-semibold">
            {isLight ? <Sun size={15} className="text-orange-500" /> : <Moon size={15} className="text-orange-400" />}
            <span>App Theme & Visual Mode</span>
          </div>
          <span className={`text-[10px] font-mono px-2 py-0.5 rounded uppercase font-semibold ${
            isLight ? 'bg-slate-100 text-slate-700' : 'bg-white/10 text-zinc-300'
          }`}>
            {settings.theme}
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2 text-xs">
          <button
            type="button"
            onClick={() => handleUpdate('theme', 'dark')}
            className={`p-3 rounded-xl border flex items-center gap-2.5 transition-all text-left ${
              settings.theme === 'dark'
                ? 'bg-[#1C1C24] border-orange-500 text-white shadow-md'
                : isLight
                  ? 'bg-slate-50 border-slate-200 text-slate-600 hover:border-slate-300'
                  : 'bg-[#101014] border-white/5 text-zinc-400 hover:border-white/15'
            }`}
          >
            <div className="w-7 h-7 rounded-lg bg-black text-orange-400 flex items-center justify-center border border-white/10">
              <Moon size={14} />
            </div>
            <div>
              <div className="font-semibold text-xs text-white">Dark Obsidian</div>
              <div className="text-[10px] text-zinc-400">Deep black & orange</div>
            </div>
          </button>

          <button
            type="button"
            onClick={() => handleUpdate('theme', 'light')}
            className={`p-3 rounded-xl border flex items-center gap-2.5 transition-all text-left ${
              settings.theme === 'light'
                ? 'bg-orange-50 border-orange-500 text-slate-900 shadow-md ring-1 ring-orange-500'
                : isLight
                  ? 'bg-slate-50 border-slate-200 text-slate-600 hover:border-slate-300'
                  : 'bg-[#101014] border-white/5 text-zinc-400 hover:border-white/15'
            }`}
          >
            <div className="w-7 h-7 rounded-lg bg-white text-orange-500 flex items-center justify-center border border-slate-300 shadow-sm">
              <Sun size={14} />
            </div>
            <div>
              <div className={`font-semibold text-xs ${isLight ? 'text-slate-900' : 'text-zinc-200'}`}>Modern Light</div>
              <div className={`text-[10px] ${isLight ? 'text-slate-500' : 'text-zinc-400'}`}>High contrast slate</div>
            </div>
          </button>
        </div>
      </div>

      {/* Section 2: Language Selection */}
      <div className={`p-3.5 rounded-2xl border space-y-3 transition-colors ${
        isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-[#141418] border-white/[0.08]'
      }`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-semibold">
            <Languages size={15} className="text-orange-400" />
            <span>Language Preference (ভাষা / اللغة)</span>
          </div>
          <span className="text-[10px] font-mono text-orange-400 uppercase font-semibold">
            {settings.language}
          </span>
        </div>

        <p className={`text-[11px] leading-relaxed ${isLight ? 'text-slate-500' : 'text-zinc-400'}`}>
          Select your primary language. Arabic automatically enables full RTL (right-to-left) bidirectional layout and Cairo typography. Bengali enables rich conjunct rendering.
        </p>

        <div className="grid grid-cols-2 gap-2">
          {[
            { id: 'auto', label: 'Auto Detect', sub: 'Adaptive matching', flag: '🌐' },
            { id: 'en', label: 'English', sub: 'Standard global', flag: '🇬🇧' },
            { id: 'bn', label: 'বাংলা (Bengali)', sub: 'সহজ ও প্রাঞ্জল বাংলা', flag: '🇧🇩' },
            { id: 'ar', label: 'العربية (Arabic)', sub: 'تخطيط من اليمين لليسار', flag: '🇸🇦' },
          ].map((lang) => (
            <button
              key={lang.id}
              type="button"
              onClick={() => handleUpdate('language', lang.id as AppLanguage)}
              className={`p-2.5 rounded-xl border text-left transition-all relative ${
                settings.language === lang.id
                  ? isLight
                    ? 'bg-orange-50 border-orange-500 text-slate-900 ring-1 ring-orange-500'
                    : 'bg-[#1B1720] border-orange-500 text-white shadow-sm'
                  : isLight
                    ? 'bg-slate-50 border-slate-200 text-slate-600 hover:border-slate-300'
                    : 'bg-[#101014] border-white/5 text-zinc-400 hover:border-white/15'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-base">{lang.flag}</span>
                {settings.language === lang.id && (
                  <Check size={12} className="text-orange-500" />
                )}
              </div>
              <div className={`text-xs font-semibold ${settings.language === lang.id ? 'text-orange-500' : ''}`}>
                {lang.label}
              </div>
              <div className={`text-[10px] truncate ${isLight ? 'text-slate-500' : 'text-zinc-500'}`}>
                {lang.sub}
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Section 3: Voice & Speech Engine */}
      <div className={`p-3.5 rounded-2xl border space-y-3.5 transition-colors ${
        isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-[#141418] border-white/[0.08]'
      }`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-semibold">
            <Volume2 size={15} className="text-orange-400" />
            <span>Voice & Speech Synthesis</span>
          </div>
          <button
            type="button"
            onClick={handleTestVoice}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-orange-500/15 border border-orange-500/30 text-orange-400 hover:bg-orange-500/25 text-xs font-medium transition-all"
          >
            {isPlayingTestVoice ? <Square size={11} className="fill-orange-400" /> : <Play size={11} />}
            <span className="text-[11px]">{isPlayingTestVoice ? 'Stop' : 'Test Voice'}</span>
          </button>
        </div>

        {/* Auto-speak toggle */}
        <div className="flex items-center justify-between pt-1">
          <div>
            <div className="text-xs font-medium">Auto-speak responses</div>
            <div className={`text-[11px] ${isLight ? 'text-slate-500' : 'text-zinc-400'}`}>
              Automatically read assistant messages aloud in AI Chat
            </div>
          </div>
          <button
            onClick={() => handleUpdate('autoSpeak', !settings.autoSpeak)}
            className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
              settings.autoSpeak ? 'bg-orange-500' : isLight ? 'bg-slate-300' : 'bg-zinc-800'
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white transition-transform ${
                settings.autoSpeak ? 'translate-x-5' : 'translate-x-0'
              }`}
            ></div>
          </button>
        </div>

        {/* Speech Rate Slider */}
        <div>
          <div className="flex items-center justify-between text-xs mb-1">
            <span className={isLight ? 'text-slate-600' : 'text-zinc-400'}>Speech Velocity (Speed)</span>
            <span className="font-mono text-orange-400 font-semibold">{settings.speechRate.toFixed(2)}x</span>
          </div>
          <input
            type="range"
            min="0.75"
            max="1.50"
            step="0.05"
            value={settings.speechRate}
            onChange={(e) => handleUpdate('speechRate', parseFloat(e.target.value))}
            className="w-full accent-orange-500 cursor-pointer"
          />
          <div className="flex justify-between text-[10px] text-zinc-500 font-mono mt-0.5">
            <span>0.75x (Gentle)</span>
            <span>1.0x (Normal)</span>
            <span>1.5x (Swift)</span>
          </div>
        </div>

        {/* Speech Pitch Slider */}
        <div>
          <div className="flex items-center justify-between text-xs mb-1">
            <span className={isLight ? 'text-slate-600' : 'text-zinc-400'}>Vocal Tone Pitch</span>
            <span className="font-mono text-orange-400 font-semibold">{settings.speechPitch.toFixed(2)}x</span>
          </div>
          <input
            type="range"
            min="0.80"
            max="1.25"
            step="0.05"
            value={settings.speechPitch}
            onChange={(e) => handleUpdate('speechPitch', parseFloat(e.target.value))}
            className="w-full accent-orange-500 cursor-pointer"
          />
        </div>
      </div>

      {/* Section 4: Primary Summoned Agent */}
      <div className={`p-3.5 rounded-2xl border space-y-2.5 transition-colors ${
        isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-[#141418] border-white/[0.08]'
      }`}>
        <div className="flex items-center gap-2 text-xs font-semibold">
          <Cpu size={15} className="text-orange-400" />
          <span>Primary Intelligence Agent</span>
        </div>

        <div>
          <label className={`block text-xs mb-1.5 ${isLight ? 'text-slate-500' : 'text-zinc-400'}`}>
            Default Agent for New Conversations
          </label>
          <select
            value={settings.defaultAgentId}
            onChange={(e) => handleUpdate('defaultAgentId', e.target.value)}
            className={`w-full rounded-xl p-2.5 text-xs focus:outline-none focus:border-orange-500 border ${
              isLight 
                ? 'bg-slate-50 border-slate-300 text-slate-800' 
                : 'bg-[#18181D] border-white/10 text-white'
            }`}
          >
            {SMART_AGENTS.map((agent) => (
              <option key={agent.id} value={agent.id}>
                {agent.name} — {agent.title}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Section 5: Image Studio Specifications */}
      <div className={`p-3.5 rounded-2xl border space-y-2.5 transition-colors ${
        isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-[#141418] border-white/[0.08]'
      }`}>
        <div className="flex items-center gap-2 text-xs font-semibold">
          <Sparkles size={15} className="text-orange-400" />
          <span>Image Studio Default Resolution</span>
        </div>

        <div className="grid grid-cols-3 gap-2">
          {(['1K', '2K', '4K'] as const).map((res) => (
            <button
              key={res}
              type="button"
              onClick={() => handleUpdate('defaultResolution', res)}
              className={`py-2 rounded-xl text-center border font-mono text-xs font-semibold transition-all ${
                settings.defaultResolution === res
                  ? 'bg-orange-500 text-white border-orange-500 shadow-sm'
                  : isLight
                    ? 'bg-slate-50 text-slate-600 border-slate-200 hover:border-slate-300'
                    : 'bg-[#18181D] text-zinc-400 border-white/10 hover:border-white/20'
              }`}
            >
              {res}
            </button>
          ))}
        </div>
      </div>

      {/* Section 6: Data, Export & Privacy */}
      <div className={`p-3.5 rounded-2xl border space-y-3 transition-colors ${
        isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-[#141418] border-white/[0.08]'
      }`}>
        <div className="flex items-center gap-2 text-xs font-semibold">
          <ShieldCheck size={15} className="text-emerald-400" />
          <span>Data Storage & Privacy</span>
        </div>

        <div className="flex flex-col gap-2 pt-1">
          <button
            type="button"
            onClick={handleExportData}
            className={`w-full py-2.5 px-3 rounded-xl border text-xs font-medium flex items-center justify-between transition-all ${
              isLight 
                ? 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100' 
                : 'bg-[#101014] border-white/10 text-zinc-300 hover:bg-white/5'
            }`}
          >
            <div className="flex items-center gap-2">
              <Download size={14} className="text-orange-400" />
              <span>Export All Conversations & Settings (JSON)</span>
            </div>
            <ChevronRight size={14} className="text-zinc-500" />
          </button>

          <button
            type="button"
            onClick={() => setShowPrivacyModal(true)}
            className={`w-full py-2.5 px-3 rounded-xl border text-xs font-medium flex items-center justify-between transition-all ${
              isLight 
                ? 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100' 
                : 'bg-[#101014] border-white/10 text-zinc-300 hover:bg-white/5'
            }`}
          >
            <div className="flex items-center gap-2">
              <Lock size={14} className="text-emerald-400" />
              <span>Privacy Policy & Local Data Practices</span>
            </div>
            <ChevronRight size={14} className="text-zinc-500" />
          </button>

          <button
            type="button"
            onClick={() => setShowClearConfirmModal(true)}
            className="w-full py-2.5 px-3 rounded-xl border border-red-500/30 bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs font-medium flex items-center justify-between transition-all"
          >
            <div className="flex items-center gap-2">
              <Trash2 size={14} />
              <span>Clear All Chat History & Logs...</span>
            </div>
            <span className="text-[10px] uppercase font-mono text-red-400 font-semibold">Requires Confirmation</span>
          </button>
        </div>
      </div>

      {/* Save Button */}
      <button
        onClick={handleExplicitSave}
        className="w-full py-3 rounded-xl bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700 text-white text-xs font-bold shadow-lg shadow-orange-500/20 transition-all flex items-center justify-center gap-2"
      >
        <Check size={15} />
        <span>Save All Preferences</span>
      </button>

      {/* ----------------- Clear All Confirmation Modal ----------------- */}
      {showClearConfirmModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className={`w-full max-w-sm rounded-2xl border p-4.5 space-y-3.5 shadow-2xl ${
            isLight ? 'bg-white border-slate-300 text-slate-900' : 'bg-[#16161C] border-white/15 text-white'
          }`}>
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-xl bg-red-500/20 text-red-400 flex items-center justify-center shrink-0">
                <AlertTriangle size={18} />
              </div>
              <div>
                <h3 className="text-sm font-bold">Clear All History?</h3>
                <p className={`text-xs mt-1 leading-relaxed ${isLight ? 'text-slate-600' : 'text-zinc-400'}`}>
                  This will permanently erase all saved chat conversations, flow outputs, and expedition logs from your device storage. This action cannot be reversed.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowClearConfirmModal(false)}
                className={`flex-1 py-2 rounded-xl text-xs font-semibold border transition-all ${
                  isLight ? 'bg-slate-100 border-slate-300 text-slate-700 hover:bg-slate-200' : 'bg-white/5 border-white/10 text-zinc-300 hover:bg-white/10'
                }`}
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={clearingInProgress}
                onClick={handleConfirmClearAll}
                className="flex-1 py-2 rounded-xl text-xs font-bold bg-red-500 hover:bg-red-600 text-white shadow-md shadow-red-500/25 transition-all flex items-center justify-center gap-1.5"
              >
                {clearingInProgress ? (
                  <span>Erasing...</span>
                ) : (
                  <>
                    <Trash2 size={13} />
                    <span>Yes, Clear All</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ----------------- About Modal ----------------- */}
      {showAboutModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className={`w-full max-w-md max-h-[85vh] overflow-y-auto rounded-2xl border p-5 space-y-4 shadow-2xl ${
            isLight ? 'bg-white border-slate-300 text-slate-900' : 'bg-[#15151A] border-white/15 text-white'
          }`}>
            <div className="flex items-center justify-between pb-2 border-b border-white/10">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-orange-500/20 text-orange-400 flex items-center justify-center font-bold">
                  <Info size={16} />
                </div>
                <div>
                  <h3 className="text-base font-bold">About Safar AI Agent</h3>
                  <span className="text-[10px] font-mono text-orange-400 uppercase font-semibold">Version 2.4.0 (Enterprise)</span>
                </div>
              </div>
              <button
                onClick={() => setShowAboutModal(false)}
                className="p-1 rounded-lg text-zinc-400 hover:text-white"
              >
                <X size={18} />
              </button>
            </div>

            <div className={`text-xs space-y-3 leading-relaxed ${isLight ? 'text-slate-600' : 'text-zinc-300'}`}>
              <p>
                <strong>Safar AI Agent</strong> is an intelligent, Android-styled autonomous intelligence application engineered for high-performance multi-agent reasoning, multilingual content transformation, and live speech synthesis.
              </p>

              <div className={`p-3 rounded-xl border space-y-2 text-[11px] ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#0E0E12] border-white/5'
              }`}>
                <div className="font-semibold text-orange-400 flex items-center gap-1.5">
                  <Sparkles size={12} />
                  <span>Core Architecture & Capabilities:</span>
                </div>
                <ul className="space-y-1 list-disc pl-4 text-zinc-400">
                  <li><strong>Agent Team Swarm:</strong> 5 synchronized agents (Research, Planning, Writing, Review, Coordinator) delivering structured final synthesis.</li>
                  <li><strong>Safar Flow Automation:</strong> 5-step pipeline for Content Writing, Translation, Summarization, Review, and Export.</li>
                  <li><strong>Smart Agent Hub:</strong> 8 specialized persona assistants spanning Voyage planning, Engineering, Creative Copy, and Financial analysis.</li>
                  <li><strong>Multilingual Engine:</strong> Native Bengali (বাংলা), Arabic (العربية with full RTL layout), and English.</li>
                  <li><strong>Live Speech Synthesis:</strong> Adjustable velocity, pitch, and native phonetic voice targeting.</li>
                </ul>
              </div>

              <div className={`p-2.5 rounded-xl border text-[11px] flex justify-between items-center ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#0E0E12] border-white/5'
              }`}>
                <span>Backend Model Pipeline</span>
                <span className="font-mono text-orange-400 font-semibold">Gemini 3.8 Flash / 3 Pro</span>
              </div>
            </div>

            <button
              onClick={() => setShowAboutModal(false)}
              className="w-full py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-semibold text-xs shadow-md"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* ----------------- Privacy Modal ----------------- */}
      {showPrivacyModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className={`w-full max-w-md max-h-[85vh] overflow-y-auto rounded-2xl border p-5 space-y-4 shadow-2xl ${
            isLight ? 'bg-white border-slate-300 text-slate-900' : 'bg-[#15151A] border-white/15 text-white'
          }`}>
            <div className="flex items-center justify-between pb-2 border-b border-white/10">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
                  <Lock size={16} />
                </div>
                <div>
                  <h3 className="text-base font-bold">Privacy & Data Handling</h3>
                  <span className="text-[10px] font-mono text-emerald-400 uppercase font-semibold">Client-First Privacy</span>
                </div>
              </div>
              <button
                onClick={() => setShowPrivacyModal(false)}
                className="p-1 rounded-lg text-zinc-400 hover:text-white"
              >
                <X size={18} />
              </button>
            </div>

            <div className={`text-xs space-y-3 leading-relaxed ${isLight ? 'text-slate-600' : 'text-zinc-300'}`}>
              <div className={`p-3 rounded-xl border space-y-2 text-[11px] ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#0E0E12] border-white/5'
              }`}>
                <h4 className="font-semibold text-white">1. Where Your Data Lives</h4>
                <p>
                  All chat conversations, flow outputs, custom prompts, and settings are stored locally on your device inside browser <code className="font-mono text-orange-400">localStorage</code>. No personal conversation databases are stored on central ad-tracking servers.
                </p>
              </div>

              <div className={`p-3 rounded-xl border space-y-2 text-[11px] ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#0E0E12] border-white/5'
              }`}>
                <h4 className="font-semibold text-white">2. AI Model Proxy Security</h4>
                <p>
                  Requests sent to Gemini models are proxied securely through the Node.js server to shield API keys. Your messages are processed solely to produce your direct response, without persistent retention for user tracking or profiling.
                </p>
              </div>

              <div className={`p-3 rounded-xl border space-y-2 text-[11px] ${
                isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#0E0E12] border-white/5'
              }`}>
                <h4 className="font-semibold text-white">3. Complete User Control</h4>
                <p>
                  You retain complete ownership over your data. You can download an offline JSON backup at any time or use "Clear All Chat History" to instantly wipe all records from your browser cache.
                </p>
              </div>
            </div>

            <button
              onClick={() => setShowPrivacyModal(false)}
              className="w-full py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-semibold text-xs shadow-md"
            >
              I Understand
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
