import React, { useState, useRef } from 'react';
import { 
  GitBranch, 
  PenTool, 
  Languages, 
  AlignLeft, 
  ShieldCheck, 
  Download, 
  Copy, 
  Check, 
  RotateCcw, 
  Play, 
  Square, 
  Edit3, 
  Save, 
  X, 
  ChevronDown, 
  ChevronUp, 
  AlertCircle, 
  MessageSquare, 
  Volume2, 
  VolumeX, 
  ArrowRight, 
  Briefcase, 
  Share2, 
  GraduationCap, 
  FileText, 
  Sparkles,
  Sliders
} from 'lucide-react';
import { FlowStepType, FlowStepStatus, WorkflowPresetId, WorkflowPreset } from '../types';
import { getApiUrl } from '../services/apiConfig';

interface SafarFlowScreenProps {
  onSendToChat?: (text: string) => void;
  onBackToHome?: () => void;
  initialPresetId?: WorkflowPresetId;
}

interface StepItem {
  id: FlowStepType;
  title: string;
  subtitle: string;
  description: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  status: FlowStepStatus;
  output: string;
  editedOutput?: string;
  isEditing?: boolean;
  error?: string | null;
  elapsedMs?: number;
}

export const SafarFlowScreen: React.FC<SafarFlowScreenProps> = ({
  onSendToChat,
  onBackToHome,
  initialPresetId = 'business_writing',
}) => {
  // Available workflow presets
  const presets: WorkflowPreset[] = [
    {
      id: 'business_writing',
      name: 'Business Writing',
      category: 'Corporate & Strategy',
      tagline: 'Proposal · Translate · Executive Summary · Audit',
      description: 'Draft an executive business proposal, translate for global stakeholders, distill core takeaways, and review for boardroom polish.',
      defaultTopic: 'Strategic partnership proposal for adopting sustainable green logistics across regional distribution hubs.',
      defaultTargetLanguage: 'ar',
      recommendedTone: 'Authoritative & Persuasive Corporate',
      examples: [
        'Strategic partnership proposal for adopting sustainable green logistics across regional distribution hubs.',
        'Q3 Board Briefing on AI infrastructure expansion and risk mitigation.',
        'Enterprise SaaS agreement memo for cross-border software licensing.'
      ]
    },
    {
      id: 'social_media',
      name: 'Social Media Posts',
      category: 'Growth & Marketing',
      tagline: 'Viral Hook · Multilingual · Micro-Thread · Virality Audit',
      description: 'Craft viral conversion copy with strong hooks, translate for global audiences, extract snappy tweet summaries, and review for engagement.',
      defaultTopic: 'Launch announcement for Safar AI Agent: an all-in-one multilingual companion with Live Voice, 5-Agent Swarm, and Automated Flows.',
      defaultTargetLanguage: 'bn',
      recommendedTone: 'High-Energy & Viral Storytelling',
      examples: [
        'Launch announcement for Safar AI Agent: an all-in-one multilingual companion with Live Voice, 5-Agent Swarm, and Automated Flows.',
        '10 breakthrough productivity hacks for remote software engineering teams.',
        'The future of multimodal AI in travel exploration: why native voice matters.'
      ]
    },
    {
      id: 'document_translation',
      name: 'Document Translation',
      category: 'Legal & Localization',
      tagline: 'Structured Doc · Neural Translation · Clause Digest · Accuracy Audit',
      description: 'Author structured official documentation, perform nuance-preserving neural translation, create clause digests, and audit linguistic fidelity.',
      defaultTopic: 'International Master Service Agreement (MSA) clause on intellectual property rights and cross-border data privacy standards.',
      defaultTargetLanguage: 'bn',
      recommendedTone: 'Formal & Legally Precise',
      examples: [
        'International Master Service Agreement (MSA) clause on intellectual property rights and cross-border data privacy standards.',
        'Non-Disclosure and Confidentiality Policy for global contractors and research partners.',
        'Standard Operating Procedure (SOP) for customer data security and breach escalation.'
      ]
    },
    {
      id: 'study_notes',
      name: 'Study Notes',
      category: 'Education & Research',
      tagline: 'Master Digest · Concept Clarifier · Flashcards · Fact-Check Audit',
      description: 'Generate comprehensive academic study notes, translate key terms to your native language, compile high-yield flashcard summaries, and verify clarity.',
      defaultTopic: 'Deep learning foundations: Attention mechanisms in Transformers and Reinforcement Learning from Human Feedback (RLHF).',
      defaultTargetLanguage: 'ar',
      recommendedTone: 'Pedagogical & Intuitive Educational',
      examples: [
        'Deep learning foundations: Attention mechanisms in Transformers and Reinforcement Learning from Human Feedback (RLHF).',
        'Principles of Macroeconomics: Fiscal vs. Monetary Policy during inflation shocks.',
        'Cellular respiration and oxidative phosphorylation: Biochemical pathways and ATP synthesis.'
      ]
    },
    {
      id: 'custom',
      name: 'Custom Flow',
      category: 'Flexible Pipeline',
      tagline: 'Write · Translate · Summarize · Review · Export',
      description: 'Configure your own custom topic, custom guidelines, target translation language, and review criteria.',
      defaultTopic: 'Comprehensive guide to building resilient distributed systems in cloud environments.',
      defaultTargetLanguage: 'bn',
      recommendedTone: 'Balanced & Clear',
      examples: [
        'Comprehensive guide to building resilient distributed systems in cloud environments.',
        'Creative short story about an ancient astronomer who discovers a whispering star.',
        'Personal fitness and nutrition master plan for marathon preparation.'
      ]
    }
  ];

  // Active workflow preset selection
  const [activePresetId, setActivePresetId] = useState<WorkflowPresetId>(initialPresetId);
  const currentPreset = presets.find((p) => p.id === activePresetId) || presets[0];

  // Pipeline configuration state
  const [topic, setTopic] = useState<string>(currentPreset.defaultTopic);
  const [targetLang, setTargetLang] = useState<string>(currentPreset.defaultTargetLanguage);
  const [tone, setTone] = useState<string>(currentPreset.recommendedTone);
  const [customInstructions, setCustomInstructions] = useState<string>('');
  const [showConfig, setShowConfig] = useState<boolean>(false);

  // Steps state
  const [steps, setSteps] = useState<StepItem[]>([
    {
      id: 'write',
      title: 'Step 1: Write Content',
      subtitle: 'Content Generation Engine',
      description: 'Generates structured, authoritative content tailored specifically to the workflow type.',
      icon: PenTool,
      status: 'idle',
      output: '',
    },
    {
      id: 'translate',
      title: 'Step 2: Translate Content',
      subtitle: 'Neural Translation Engine',
      description: 'Translates the written draft into the target language while preserving formatting and nuance.',
      icon: Languages,
      status: 'idle',
      output: '',
    },
    {
      id: 'summarize',
      title: 'Step 3: Summarize Content',
      subtitle: 'Executive Distillation Engine',
      description: 'Condenses the content into key executive takeaways, high-yield points, and action items.',
      icon: AlignLeft,
      status: 'idle',
      output: '',
    },
    {
      id: 'review',
      title: 'Step 4: Review Result',
      subtitle: 'Editorial Quality & Polish Audit',
      description: 'Performs a rigorous editorial critique across tone, accuracy, and delivers the final master version.',
      icon: ShieldCheck,
      status: 'idle',
      output: '',
    },
    {
      id: 'export',
      title: 'Step 5: Copy & Export Final Output',
      subtitle: 'Distribution & Export Center',
      description: 'Ready-to-use polished deliverable. Copy, download as Markdown/Text, or export to AI Chat.',
      icon: Download,
      status: 'idle',
      output: '',
    }
  ]);

  // Overall workflow state
  const [isExecutingAll, setIsExecutingAll] = useState<boolean>(false);
  const [currentRunningStep, setCurrentRunningStep] = useState<FlowStepType | null>(null);
  const [expandedSteps, setExpandedSteps] = useState<Record<string, boolean>>({
    write: true,
    translate: true,
    summarize: true,
    review: true,
    export: true,
  });
  const [copiedStep, setCopiedStep] = useState<string | null>(null);
  const [speakingStep, setSpeakingStep] = useState<string | null>(null);
  const [generalError, setGeneralError] = useState<string | null>(null);

  // Cancellation ref
  const abortControllerRef = useRef<AbortController | null>(null);
  const cancelRequestedRef = useRef<boolean>(false);

  // When changing presets, update topic and defaults
  const handleSelectPreset = (presetId: WorkflowPresetId) => {
    if (isExecutingAll) return;
    const found = presets.find((p) => p.id === presetId);
    if (!found) return;
    setActivePresetId(presetId);
    setTopic(found.defaultTopic);
    setTargetLang(found.defaultTargetLanguage);
    setTone(found.recommendedTone);
    // Reset steps to idle
    resetSteps();
  };

  // Reset all steps to clean state
  const resetSteps = () => {
    if (window.speechSynthesis) window.speechSynthesis.cancel();
    setSpeakingStep(null);
    setSteps((prev) =>
      prev.map((s) => ({
        ...s,
        status: 'idle',
        output: '',
        editedOutput: undefined,
        isEditing: false,
        error: null,
        elapsedMs: undefined,
      }))
    );
    setGeneralError(null);
  };

  // Helper to determine if text is Arabic / Urdu (RTL)
  const isRTL = (text: string) => /[\u0600-\u06FF\u0750-\u077F]/.test(text);

  // Execute a single step on the backend
  const executeStepApi = async (
    stepType: FlowStepType,
    currentStepsSnapshot: StepItem[],
    signal?: AbortSignal
  ): Promise<string> => {
    const startTime = Date.now();

    // Collect effective outputs (using editedOutput if user edited)
    const getEffectiveOutput = (id: FlowStepType) => {
      const s = currentStepsSnapshot.find((item) => item.id === id);
      return s?.editedOutput !== undefined ? s.editedOutput : (s?.output || '');
    };

    const previousOutputs = {
      write: getEffectiveOutput('write'),
      translate: getEffectiveOutput('translate'),
      summarize: getEffectiveOutput('summarize'),
      review: getEffectiveOutput('review'),
    };

    const stepInputs: any = {
      tone,
      customInstructions,
      writeLanguage: 'en',
      targetLanguage: targetLang,
      summaryLanguage: 'en',
      reviewLanguage: 'en',
    };

    if (stepType === 'write') {
      stepInputs.topic = topic;
    } else if (stepType === 'translate') {
      // Content to translate is the written step (or user-edited written step)
      stepInputs.content = previousOutputs.write || topic;
      stepInputs.targetLanguage = targetLang;
    } else if (stepType === 'summarize') {
      // Content to summarize is the translated step, or written step
      stepInputs.content = previousOutputs.translate || previousOutputs.write || topic;
    } else if (stepType === 'review') {
      // Content to review is the summary or the full set
      stepInputs.content = previousOutputs.summarize || previousOutputs.translate || previousOutputs.write || topic;
    }

    const payload = {
      step: stepType,
      workflowType: activePresetId,
      inputTopic: topic,
      stepInputs,
      previousOutputs,
      language: targetLang,
    };

    const res = await fetch(getApiUrl('/api/flow/execute-step'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      signal,
    });

    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || `HTTP error ${res.status}`);
    }

    const data = await res.json();
    return data.output || 'Step completed.';
  };

  // Run a single specific step
  const handleRunSingleStep = async (stepId: FlowStepType) => {
    if (isExecutingAll) return;
    if (!topic.trim()) {
      setGeneralError('Please enter a topic or prompt for this workflow.');
      return;
    }

    setGeneralError(null);
    setCurrentRunningStep(stepId);

    // Update status to running
    setSteps((prev) =>
      prev.map((s) => (s.id === stepId ? { ...s, status: 'running', error: null } : s))
    );

    const startTime = Date.now();
    try {
      const output = await executeStepApi(stepId, steps);
      const elapsedMs = Date.now() - startTime;

      setSteps((prev) => {
        const next = prev.map((s) => {
          if (s.id === stepId) {
            return {
              ...s,
              status: 'completed' as FlowStepStatus,
              output,
              editedOutput: undefined,
              isEditing: false,
              elapsedMs,
            };
          }
          return s;
        });

        // If step 4 (review) was run, also update step 5 (export)
        if (stepId === 'review') {
          return next.map((s) =>
            s.id === 'export'
              ? { ...s, status: 'completed' as FlowStepStatus, output }
              : s
          );
        }
        return next;
      });
    } catch (err: any) {
      if (err.name === 'AbortError') return;
      setSteps((prev) =>
        prev.map((s) =>
          s.id === stepId
            ? { ...s, status: 'error' as FlowStepStatus, error: err.message || 'Execution failed' }
            : s
        )
      );
    } finally {
      setCurrentRunningStep(null);
    }
  };

  // Run the whole flow sequentially: Step 1 -> Step 2 -> Step 3 -> Step 4 -> Step 5
  const handleRunFullWorkflow = async () => {
    if (!topic.trim()) {
      setGeneralError('Please enter a topic or prompt for this workflow.');
      return;
    }

    setGeneralError(null);
    setIsExecutingAll(true);
    cancelRequestedRef.current = false;

    const controller = new AbortController();
    abortControllerRef.current = controller;

    // Sequence of steps to run
    const stepsSequence: FlowStepType[] = ['write', 'translate', 'summarize', 'review'];
    let currentStepsState = [...steps];

    try {
      for (const stepType of stepsSequence) {
        if (cancelRequestedRef.current) break;

        setCurrentRunningStep(stepType);

        // Mark as running
        currentStepsState = currentStepsState.map((s) =>
          s.id === stepType ? { ...s, status: 'running', error: null } : s
        );
        setSteps(currentStepsState);

        const startTime = Date.now();
        const output = await executeStepApi(stepType, currentStepsState, controller.signal);
        const elapsedMs = Date.now() - startTime;

        if (cancelRequestedRef.current) break;

        // Update completed step
        currentStepsState = currentStepsState.map((s) => {
          if (s.id === stepType) {
            return {
              ...s,
              status: 'completed' as FlowStepStatus,
              output,
              editedOutput: undefined,
              isEditing: false,
              elapsedMs,
            };
          }
          return s;
        });
        setSteps(currentStepsState);
      }

      // If finished review without cancel, populate export step
      if (!cancelRequestedRef.current) {
        const reviewOutput = currentStepsState.find((s) => s.id === 'review')?.output || '';
        currentStepsState = currentStepsState.map((s) =>
          s.id === 'export'
            ? { ...s, status: 'completed' as FlowStepStatus, output: reviewOutput }
            : s
        );
        setSteps(currentStepsState);
      }
    } catch (err: any) {
      if (err.name === 'AbortError' || cancelRequestedRef.current) {
        setGeneralError('Workflow paused by user.');
      } else {
        setGeneralError(`Workflow error: ${err.message || 'Execution failed'}`);
      }
    } finally {
      setIsExecutingAll(false);
      setCurrentRunningStep(null);
      abortControllerRef.current = null;
    }
  };

  // Stop / Abort current execution
  const handleStopWorkflow = () => {
    cancelRequestedRef.current = true;
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    setIsExecutingAll(false);
    setCurrentRunningStep(null);
    setGeneralError('Workflow execution stopped.');
  };

  // Toggle step expansion
  const toggleExpandStep = (id: string) => {
    setExpandedSteps((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  // Enable intermediate output editing
  const handleStartEdit = (stepId: FlowStepType) => {
    setSteps((prev) =>
      prev.map((s) => {
        if (s.id === stepId) {
          const currentText = s.editedOutput !== undefined ? s.editedOutput : s.output;
          return { ...s, isEditing: true, editedOutput: currentText };
        }
        return s;
      })
    );
  };

  // Save intermediate output edits
  const handleSaveEdit = (stepId: FlowStepType) => {
    setSteps((prev) =>
      prev.map((s) => {
        if (s.id === stepId) {
          const nextOutput = s.editedOutput || s.output;
          return {
            ...s,
            output: nextOutput,
            isEditing: false,
            status: 'edited' as FlowStepStatus,
          };
        }
        return s;
      })
    );
  };

  // Cancel editing
  const handleCancelEdit = (stepId: FlowStepType) => {
    setSteps((prev) =>
      prev.map((s) => {
        if (s.id === stepId) {
          return { ...s, isEditing: false, editedOutput: undefined };
        }
        return s;
      })
    );
  };

  // Update text while editing
  const handleEditTextChange = (stepId: FlowStepType, text: string) => {
    setSteps((prev) =>
      prev.map((s) => (s.id === stepId ? { ...s, editedOutput: text } : s))
    );
  };

  // Copy text to clipboard
  const handleCopy = (text: string, id: string) => {
    if (!text) return;
    navigator.clipboard.writeText(text);
    setCopiedStep(id);
    setTimeout(() => setCopiedStep(null), 2500);
  };

  // Export as Markdown or Text file
  const handleDownloadFile = (content: string, filename: string, mimeType: string) => {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Export entire workflow audit log
  const handleExportFullAudit = () => {
    const lines = [
      `# Safar Flow Automation Report: ${currentPreset.name}`,
      `Generated: ${new Date().toLocaleString()}`,
      `Objective: ${topic}`,
      `Target Language: ${targetLang}`,
      `Tone / Style: ${tone}`,
      '',
      '---',
      '## Step 1: Write Content',
      steps.find((s) => s.id === 'write')?.output || '(Not run)',
      '',
      '---',
      '## Step 2: Translation',
      steps.find((s) => s.id === 'translate')?.output || '(Not run)',
      '',
      '---',
      '## Step 3: Executive Summary',
      steps.find((s) => s.id === 'summarize')?.output || '(Not run)',
      '',
      '---',
      '## Step 4: Editorial Review & Polish',
      steps.find((s) => s.id === 'review')?.output || '(Not run)',
      '',
      '---',
      '## Final Master Output',
      finalOutputToExport || '(Not available)',
      '',
      '_Created with Safar AI Agent Flow Automation Engine._'
    ];
    handleDownloadFile(lines.join('\n'), `safar-flow-${activePresetId}-${Date.now()}.md`, 'text/markdown');
  };

  // TTS read aloud
  const handleSpeak = (text: string, id: string) => {
    if (!('speechSynthesis' in window)) return;
    if (speakingStep === id) {
      window.speechSynthesis.cancel();
      setSpeakingStep(null);
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text.slice(0, 800));
    utterance.rate = 1.0;
    utterance.onend = () => setSpeakingStep(null);
    utterance.onerror = () => setSpeakingStep(null);
    setSpeakingStep(id);
    window.speechSynthesis.speak(utterance);
  };

  // Get final output for Step 5
  const reviewStep = steps.find((s) => s.id === 'review');
  const finalOutputToExport = reviewStep?.output || steps.find((s) => s.id === 'summarize')?.output || '';

  // Calculate completed progress percentage
  const completedCount = steps.filter((s) => s.status === 'completed' || s.status === 'edited').length;
  const progressPercent = Math.round((completedCount / steps.length) * 100);

  return (
    <div className="flex flex-col h-full bg-[#0B0B0E] text-zinc-100 overflow-y-auto">
      {/* Top Header */}
      <header className="sticky top-0 z-20 bg-[#0E0E12]/95 backdrop-blur-md border-b border-white/[0.08] px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-orange-500/15 border border-orange-500/30 text-orange-400 flex items-center justify-center">
            <GitBranch size={17} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-sm font-semibold text-white tracking-tight">Safar Flow Automation</h1>
              <span className="text-[10px] text-zinc-400 font-mono">Gemini 3.8</span>
            </div>
            <p className="text-[11px] text-zinc-400">
              5-Step Sequential Content & Translation Pipeline
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setShowConfig(!showConfig)}
            className={`p-1.5 rounded-lg border text-xs flex items-center gap-1 transition-colors ${
              showConfig 
                ? 'bg-orange-500/15 border-orange-500/40 text-orange-400' 
                : 'bg-white/5 border-white/10 text-zinc-400 hover:text-zinc-200'
            }`}
            title="Configure Pipeline Parameters"
          >
            <Sliders size={14} />
            <span className="hidden sm:inline">Settings</span>
          </button>

          <button
            onClick={resetSteps}
            disabled={isExecutingAll}
            className="p-1.5 rounded-lg bg-white/5 border border-white/10 text-zinc-400 hover:text-zinc-200 disabled:opacity-40 transition-colors"
            title="Reset All Steps"
          >
            <RotateCcw size={14} />
          </button>
        </div>
      </header>

      {/* Main Container */}
      <div className="flex-1 p-4 max-w-3xl w-full mx-auto space-y-4">
        {/* Preset Selector Tabs */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-zinc-300 uppercase tracking-wider">
              Ready-Made Workflows
            </span>
            <span className="text-[11px] text-zinc-400">
              {currentPreset.category}
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {presets.filter(p => p.id !== 'custom').map((p) => {
              const isSelected = activePresetId === p.id;
              const Icon = p.id === 'business_writing' ? Briefcase 
                : p.id === 'social_media' ? Share2 
                : p.id === 'document_translation' ? FileText 
                : GraduationCap;

              return (
                <button
                  key={p.id}
                  onClick={() => handleSelectPreset(p.id)}
                  disabled={isExecutingAll}
                  className={`p-2.5 rounded-xl text-left border transition-all flex flex-col justify-between ${
                    isSelected
                      ? 'bg-gradient-to-br from-orange-500/15 via-[#1A1412] to-[#121216] border-orange-500/50 text-white shadow-sm'
                      : 'bg-[#121216] border-white/[0.06] text-zinc-400 hover:border-white/20 hover:text-zinc-200'
                  }`}
                >
                  <div className="flex items-center justify-between w-full mb-1">
                    <Icon size={16} className={isSelected ? 'text-orange-400' : 'text-zinc-400'} />
                    {isSelected && (
                      <span className="w-1.5 h-1.5 rounded-full bg-orange-400 shadow-[0_0_6px_#FB923C]" />
                    )}
                  </div>
                  <div>
                    <div className="text-xs font-medium text-white truncate">{p.name}</div>
                    <div className="text-[10px] text-zinc-400 truncate mt-0.5">{p.category}</div>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Custom Flow Button */}
          <div className="mt-2 flex justify-end">
            <button
              onClick={() => handleSelectPreset('custom')}
              className={`text-xs px-2.5 py-1 rounded-lg border transition-colors flex items-center gap-1.5 ${
                activePresetId === 'custom'
                  ? 'bg-orange-500/20 border-orange-500/50 text-orange-300'
                  : 'bg-transparent border-white/10 text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <Sparkles size={12} />
              <span>Or build Custom Flow</span>
            </button>
          </div>
        </div>

        {/* Workflow Brief Card */}
        <div className="p-3.5 rounded-2xl bg-[#131317] border border-white/[0.08] space-y-3">
          <div className="flex items-start justify-between gap-2">
            <div>
              <h2 className="text-sm font-semibold text-white">{currentPreset.name}</h2>
              <p className="text-xs text-zinc-400 mt-0.5">{currentPreset.description}</p>
            </div>
            <span className="text-[10px] text-zinc-400 border border-white/10 px-2 py-0.5 rounded-md font-mono">
              Target: {targetLang.toUpperCase()}
            </span>
          </div>

          {/* Topic Input */}
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-zinc-300 flex items-center justify-between">
              <span>Workflow Prompt / Subject</span>
              <span className="text-[10px] text-zinc-400">Step 1 will craft content based on this</span>
            </label>
            <textarea
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              disabled={isExecutingAll}
              rows={2}
              placeholder="Enter your topic, business memo subject, or study outline..."
              className="w-full text-xs p-2.5 rounded-xl bg-[#0E0E12] border border-white/10 text-zinc-100 placeholder:text-zinc-600 focus:outline-none focus:border-orange-500 transition-colors resize-none"
            />
          </div>

          {/* Example Prompt Chips */}
          {currentPreset.examples.length > 0 && (
            <div className="space-y-1">
              <span className="text-[10px] text-zinc-400">Suggested topics:</span>
              <div className="flex flex-wrap gap-1.5">
                {currentPreset.examples.map((ex, idx) => (
                  <button
                    key={idx}
                    onClick={() => setTopic(ex)}
                    disabled={isExecutingAll}
                    className="text-[11px] px-2 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-zinc-300 border border-white/[0.06] text-left transition-colors truncate max-w-full"
                  >
                    {ex.length > 60 ? `${ex.slice(0, 60)}...` : ex}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Collapsible Advanced Config */}
          {showConfig && (
            <div className="pt-2 border-t border-white/[0.08] grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="text-zinc-400 block mb-1">Target Language for Translation</label>
                <select
                  value={targetLang}
                  onChange={(e) => setTargetLang(e.target.value)}
                  disabled={isExecutingAll}
                  className="w-full p-2 rounded-lg bg-[#0E0E12] border border-white/10 text-zinc-200 focus:outline-none focus:border-orange-500"
                >
                  <option value="bn">Bengali (বাংলা)</option>
                  <option value="ar">Arabic (العربية)</option>
                  <option value="en">English</option>
                  <option value="es">Spanish (Español)</option>
                  <option value="fr">French (Français)</option>
                  <option value="de">German (Deutsch)</option>
                  <option value="ur">Urdu (اردو)</option>
                </select>
              </div>

              <div>
                <label className="text-zinc-400 block mb-1">Tone & Pacing</label>
                <input
                  type="text"
                  value={tone}
                  onChange={(e) => setTone(e.target.value)}
                  disabled={isExecutingAll}
                  placeholder="e.g. Authoritative, Energetic, Formal"
                  className="w-full p-2 rounded-lg bg-[#0E0E12] border border-white/10 text-zinc-200 focus:outline-none focus:border-orange-500"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="text-zinc-400 block mb-1">Custom Guidelines / Instructions (Optional)</label>
                <input
                  type="text"
                  value={customInstructions}
                  onChange={(e) => setCustomInstructions(e.target.value)}
                  disabled={isExecutingAll}
                  placeholder="e.g. Focus heavily on ROI, include 3 specific bullet points, keep under 400 words"
                  className="w-full p-2 rounded-lg bg-[#0E0E12] border border-white/10 text-zinc-200 focus:outline-none focus:border-orange-500"
                />
              </div>
            </div>
          )}

          {/* Execution Controls Row */}
          <div className="flex items-center gap-2 pt-1">
            <button
              onClick={handleRunFullWorkflow}
              disabled={isExecutingAll || !topic.trim()}
              className="flex-1 py-2.5 px-4 rounded-xl bg-orange-500 hover:bg-orange-600 disabled:bg-zinc-800 disabled:text-zinc-500 text-white font-medium text-xs flex items-center justify-center gap-2 transition-all shadow-[0_0_15px_rgba(249,115,22,0.25)]"
            >
              <Play size={14} className={isExecutingAll ? 'animate-pulse' : ''} fill="currentColor" />
              <span>
                {isExecutingAll
                  ? `Executing Step: ${currentRunningStep?.toUpperCase()}...`
                  : 'Run Full Workflow (Steps 1-4)'}
              </span>
            </button>

            {isExecutingAll && (
              <button
                onClick={handleStopWorkflow}
                className="py-2.5 px-4 rounded-xl bg-red-500/20 hover:bg-red-500/30 border border-red-500/40 text-red-300 font-medium text-xs flex items-center gap-1.5 transition-colors"
                title="Stop execution"
              >
                <Square size={13} fill="currentColor" />
                <span>Stop</span>
              </button>
            )}
          </div>
        </div>

        {/* Global Error Banner */}
        {generalError && (
          <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertCircle size={15} className="shrink-0" />
              <span>{generalError}</span>
            </div>
            <button
              onClick={() => setGeneralError(null)}
              className="text-red-400 hover:text-white"
            >
              <X size={14} />
            </button>
          </div>
        )}

        {/* Pipeline Stepper Bar */}
        <div className="bg-[#121216] border border-white/[0.08] p-3 rounded-2xl space-y-2">
          <div className="flex items-center justify-between text-xs">
            <div className="font-semibold text-zinc-300">Pipeline Execution Progress</div>
            <div className="text-zinc-400 font-mono text-[11px]">{progressPercent}% Completed</div>
          </div>

          <div className="w-full bg-zinc-800/80 rounded-full h-1.5 overflow-hidden">
            <div 
              className="bg-gradient-to-r from-orange-500 to-amber-400 h-full transition-all duration-300"
              style={{ width: `${progressPercent}%` }}
            />
          </div>

          <div className="grid grid-cols-5 gap-1 pt-1">
            {steps.map((st, i) => {
              const isRunning = currentRunningStep === st.id;
              const isDone = st.status === 'completed' || st.status === 'edited';
              const isErr = st.status === 'error';

              return (
                <div key={st.id} className="flex flex-col items-center text-center">
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold border transition-colors ${
                      isRunning
                        ? 'border-orange-500 bg-orange-500/20 text-orange-400 animate-pulse'
                        : isDone
                        ? 'border-emerald-500/50 bg-emerald-500/20 text-emerald-400'
                        : isErr
                        ? 'border-red-500 bg-red-500/20 text-red-400'
                        : 'border-white/10 bg-white/5 text-zinc-400'
                    }`}
                  >
                    {isDone ? <Check size={11} strokeWidth={2.5} /> : isErr ? '!' : i + 1}
                  </div>
                  <span className="text-[10px] text-zinc-400 mt-1 truncate w-full">
                    {st.id.charAt(0).toUpperCase() + st.id.slice(1)}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Steps List */}
        <div className="space-y-3">
          {steps.map((step, index) => {
            const Icon = step.icon;
            const isRunning = currentRunningStep === step.id;
            const isDone = step.status === 'completed' || step.status === 'edited';
            const isError = step.status === 'error';
            const isExpanded = expandedSteps[step.id] ?? true;
            const displayOutput = step.editedOutput !== undefined ? step.editedOutput : step.output;
            const textIsRTL = isRTL(displayOutput);

            // Special layout for Step 5 (Export Center)
            if (step.id === 'export') {
              return (
                <div
                  key={step.id}
                  className="rounded-2xl border border-white/[0.08] bg-[#141419] overflow-hidden transition-all"
                >
                  <div className="p-3.5 bg-gradient-to-r from-orange-500/10 via-transparent to-transparent flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-lg bg-orange-500/20 border border-orange-500/30 text-orange-400 flex items-center justify-center">
                        <Download size={16} />
                      </div>
                      <div>
                        <div className="text-xs font-semibold text-white">Step 5: Copy & Export Final Output</div>
                        <div className="text-[11px] text-zinc-400">Export review deliverable, summary, or full audit log</div>
                      </div>
                    </div>

                    <button
                      onClick={() => toggleExpandStep(step.id)}
                      className="p-1 text-zinc-400 hover:text-white"
                    >
                      {isExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                    </button>
                  </div>

                  {isExpanded && (
                    <div className="p-3.5 space-y-3 border-t border-white/[0.06]">
                      {finalOutputToExport ? (
                        <>
                          <div className="space-y-1.5">
                            <div className="flex items-center justify-between text-xs text-zinc-400">
                              <span>Final Polished Output Preview:</span>
                              <span className="font-mono text-[10px]">
                                {finalOutputToExport.split(/\s+/).filter(Boolean).length} words · {finalOutputToExport.length} chars
                              </span>
                            </div>
                            <div
                              dir={isRTL(finalOutputToExport) ? 'rtl' : 'ltr'}
                              className="max-h-48 overflow-y-auto p-3 rounded-xl bg-[#0D0D11] border border-white/[0.08] text-xs text-zinc-200 whitespace-pre-wrap font-sans leading-relaxed"
                            >
                              {finalOutputToExport}
                            </div>
                          </div>

                          {/* Export Action Buttons */}
                          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                            <button
                              onClick={() => handleCopy(finalOutputToExport, 'final-output')}
                              className="p-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-medium flex items-center justify-center gap-1.5 transition-colors"
                            >
                              {copiedStep === 'final-output' ? <Check size={14} /> : <Copy size={14} />}
                              <span>{copiedStep === 'final-output' ? 'Copied!' : 'Copy Final Output'}</span>
                            </button>

                            <button
                              onClick={() => handleDownloadFile(finalOutputToExport, `safar-${activePresetId}-final.md`, 'text/markdown')}
                              className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-zinc-200 font-medium flex items-center justify-center gap-1.5 transition-colors"
                            >
                              <Download size={14} />
                              <span>Export Markdown (.md)</span>
                            </button>

                            <button
                              onClick={() => handleDownloadFile(finalOutputToExport, `safar-${activePresetId}-final.txt`, 'text/plain')}
                              className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-zinc-200 font-medium flex items-center justify-center gap-1.5 transition-colors"
                            >
                              <FileText size={14} />
                              <span>Export Text (.txt)</span>
                            </button>

                            <button
                              onClick={handleExportFullAudit}
                              className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-zinc-200 font-medium flex items-center justify-center gap-1.5 transition-colors sm:col-span-2"
                            >
                              <GitBranch size={14} />
                              <span>Export Complete Flow Audit (.md)</span>
                            </button>

                            {onSendToChat && (
                              <button
                                onClick={() => onSendToChat(finalOutputToExport)}
                                className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-orange-400 hover:text-orange-300 font-medium flex items-center justify-center gap-1.5 transition-colors"
                              >
                                <MessageSquare size={14} />
                                <span>Send to AI Chat</span>
                              </button>
                            )}
                          </div>
                        </>
                      ) : (
                        <div className="p-4 rounded-xl bg-[#0D0D11] border border-white/[0.05] text-center text-xs text-zinc-400">
                          Run the workflow steps above to generate and export your final reviewed output.
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            }

            return (
              <div
                key={step.id}
                className={`rounded-2xl border transition-all overflow-hidden ${
                  isRunning
                    ? 'border-orange-500/60 bg-[#141217]'
                    : isDone
                    ? 'border-white/[0.08] bg-[#121216]'
                    : isError
                    ? 'border-red-500/40 bg-[#161214]'
                    : 'border-white/[0.05] bg-[#101013]'
                }`}
              >
                {/* Step Card Header */}
                <div className="p-3.5 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-8 h-8 rounded-xl flex items-center justify-center transition-colors ${
                        isRunning
                          ? 'bg-orange-500/20 text-orange-400 border border-orange-500/40'
                          : isDone
                          ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                          : isError
                          ? 'bg-red-500/15 text-red-400 border border-red-500/30'
                          : 'bg-white/5 text-zinc-400 border border-white/10'
                      }`}
                    >
                      <Icon size={16} />
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold text-white">{step.title}</span>
                        {step.status === 'edited' && (
                          <span className="text-[10px] text-amber-400 bg-amber-500/10 border border-amber-500/20 px-1.5 py-0.2 rounded">
                            User Edited
                          </span>
                        )}
                        {step.elapsedMs && (
                          <span className="text-[10px] text-zinc-400 font-mono">
                            {(step.elapsedMs / 1000).toFixed(1)}s
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-zinc-400">{step.subtitle}</p>
                    </div>
                  </div>

                  {/* Step Action Controls */}
                  <div className="flex items-center gap-1.5">
                    {/* Run / Retry Step Button */}
                    <button
                      onClick={() => handleRunSingleStep(step.id)}
                      disabled={isExecutingAll || isRunning}
                      className={`px-2.5 py-1 rounded-lg text-xs font-medium border flex items-center gap-1 transition-all ${
                        isRunning
                          ? 'bg-orange-500/20 border-orange-500/40 text-orange-400 animate-pulse'
                          : isDone
                          ? 'bg-white/5 border-white/10 text-zinc-300 hover:text-white hover:bg-white/10'
                          : 'bg-orange-500/15 border-orange-500/30 text-orange-300 hover:bg-orange-500/25'
                      }`}
                      title={isDone ? 'Regenerate this step' : 'Run this step'}
                    >
                      {isDone ? <RotateCcw size={12} /> : <Play size={12} fill="currentColor" />}
                      <span className="hidden sm:inline">{isDone ? 'Retry Step' : 'Run Step'}</span>
                    </button>

                    {/* Edit intermediate output button */}
                    {isDone && !step.isEditing && (
                      <button
                        onClick={() => handleStartEdit(step.id)}
                        disabled={isExecutingAll}
                        className="p-1.5 rounded-lg bg-white/5 border border-white/10 text-zinc-400 hover:text-zinc-200 transition-colors"
                        title="Edit output before next step"
                      >
                        <Edit3 size={13} />
                      </button>
                    )}

                    {/* Copy step output button */}
                    {displayOutput && (
                      <button
                        onClick={() => handleCopy(displayOutput, step.id)}
                        className="p-1.5 rounded-lg bg-white/5 border border-white/10 text-zinc-400 hover:text-zinc-200 transition-colors"
                        title="Copy step output"
                      >
                        {copiedStep === step.id ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
                      </button>
                    )}

                    {/* Expand/Collapse */}
                    <button
                      onClick={() => toggleExpandStep(step.id)}
                      className="p-1 text-zinc-400 hover:text-zinc-200"
                    >
                      {isExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                    </button>
                  </div>
                </div>

                {/* Card Content (Expandable) */}
                {isExpanded && (
                  <div className="p-3.5 pt-0 border-t border-white/[0.04] space-y-2">
                    {/* Description if Idle */}
                    {step.status === 'idle' && (
                      <p className="text-xs text-zinc-400 italic pt-2">
                        {step.description}
                      </p>
                    )}

                    {/* Running State */}
                    {isRunning && (
                      <div className="py-4 flex flex-col items-center justify-center text-center space-y-2">
                        <div className="w-6 h-6 border-2 border-orange-500 border-t-transparent rounded-full animate-spin" />
                        <span className="text-xs text-zinc-400 font-mono">
                          Generating step with Gemini 3.8 Flash...
                        </span>
                      </div>
                    )}

                    {/* Error State */}
                    {isError && (
                      <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-xs flex items-center justify-between mt-2">
                        <span>{step.error || 'Step failed'}</span>
                        <button
                          onClick={() => handleRunSingleStep(step.id)}
                          className="px-2 py-0.5 rounded bg-red-500/20 hover:bg-red-500/30 text-white font-medium text-[11px]"
                        >
                          Retry
                        </button>
                      </div>
                    )}

                    {/* Editable Text Mode */}
                    {step.isEditing ? (
                      <div className="space-y-2 pt-2">
                        <div className="flex items-center justify-between text-xs text-zinc-400">
                          <span>Edit Intermediate Output (Next steps will use your edited text):</span>
                        </div>
                        <textarea
                          value={step.editedOutput ?? step.output}
                          onChange={(e) => handleEditTextChange(step.id, e.target.value)}
                          rows={6}
                          dir={textIsRTL ? 'rtl' : 'ltr'}
                          className="w-full text-xs p-3 rounded-xl bg-[#0B0B0E] border border-orange-500/40 text-zinc-100 font-sans focus:outline-none focus:ring-1 focus:ring-orange-500 leading-relaxed"
                        />
                        <div className="flex justify-end gap-2 text-xs">
                          <button
                            onClick={() => handleCancelEdit(step.id)}
                            className="px-3 py-1.5 rounded-lg border border-white/10 text-zinc-400 hover:text-white"
                          >
                            Cancel
                          </button>
                          <button
                            onClick={() => handleSaveEdit(step.id)}
                            className="px-3 py-1.5 rounded-lg bg-orange-500 hover:bg-orange-600 text-white font-medium flex items-center gap-1"
                          >
                            <Save size={12} />
                            <span>Save & Apply</span>
                          </button>
                        </div>
                      </div>
                    ) : (
                      /* Display Output Mode */
                      isDone && displayOutput && (
                        <div className="pt-2 space-y-2">
                          <div
                            dir={textIsRTL ? 'rtl' : 'ltr'}
                            className="max-h-60 overflow-y-auto p-3 rounded-xl bg-[#0D0D11] border border-white/[0.06] text-xs text-zinc-200 whitespace-pre-wrap font-sans leading-relaxed selection:bg-orange-500/30"
                          >
                            {displayOutput}
                          </div>

                          <div className="flex items-center justify-between text-[11px] text-zinc-400 pt-1">
                            <span>
                              {displayOutput.split(/\s+/).filter(Boolean).length} words · {displayOutput.length} characters
                            </span>
                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => handleSpeak(displayOutput, step.id)}
                                className="flex items-center gap-1 text-zinc-400 hover:text-zinc-200 transition-colors"
                              >
                                {speakingStep === step.id ? <VolumeX size={12} className="text-orange-400" /> : <Volume2 size={12} />}
                                <span>{speakingStep === step.id ? 'Stop' : 'Listen'}</span>
                              </button>
                              <span>·</span>
                              <button
                                onClick={() => handleStartEdit(step.id)}
                                className="text-orange-400 hover:text-orange-300 font-medium"
                              >
                                Edit Text
                              </button>
                            </div>
                          </div>
                        </div>
                      )
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
