import React, { useState, useRef, useEffect } from 'react';
import { 
  ArrowUp, 
  Sparkles, 
  Bot, 
  User, 
  Copy, 
  Check, 
  Volume2, 
  VolumeX, 
  RotateCcw, 
  Plus,
  Trash2, 
  Image as ImageIcon,
  Compass, 
  AlertCircle,
  Globe,
  ChevronDown,
  Languages,
  Edit3,
  Clock,
  Search,
  X,
  MessageSquare,
  AlertTriangle
} from 'lucide-react';
import { ChatMessage, SmartAgent, ChatSession, AppLanguage, AppTheme } from '../types';
import { SMART_AGENTS } from '../data/agents';
import { 
  loadChatSessions, 
  updateChatSession, 
  createNewChatSession, 
  renameChatSession, 
  deleteChatSession,
  loadSettings 
} from '../services/storageService';
import { getApiUrl } from '../services/apiConfig';

interface ChatScreenProps {
  initialPrompt?: string;
  initialAgentId?: string;
  initialSessionId?: string;
  onOpenImageStudio: (prompt?: string) => void;
}

// Multilingual starter prompts including Bengali, Arabic, English
const MULTILINGUAL_STARTERS = [
  {
    lang: 'English',
    code: 'en',
    flag: '🇬🇧',
    prompt: 'Plan a 4-day Tokyo expedition focused on hidden shrines and ramen masters',
  },
  {
    lang: 'বাংলা',
    code: 'bn',
    flag: '🇧🇩',
    prompt: 'আমাকে একটি ৩ দিনের সিলেট ও জাফলং ভ্রমণের সুন্দর ও বিস্তারিত পরিকল্পনা দিন',
  },
  {
    lang: 'العربية',
    code: 'ar',
    flag: '🇸🇦',
    prompt: 'خطط لي رحلة استكشافية تاريخية إلى الأندلس وقرطبة لمدة 5 أيام مع تفاصيل المواصلات',
  },
  {
    lang: 'English (Tech)',
    code: 'en',
    flag: '⚡',
    prompt: 'Explain the difference between optimistic locking and pessimistic locking with clean code',
  },
  {
    lang: 'বাংলা (বিজ্ঞান)',
    code: 'bn',
    flag: '🇧🇩',
    prompt: 'কৃত্রিম বুদ্ধিমত্তা কীভাবে ভ্রমণ শিল্পে বিপ্লব ঘটাচ্ছে তা সহজ ভাষায় ব্যাখ্যা করুন',
  },
  {
    lang: 'العربية (تقنية)',
    code: 'ar',
    flag: '🇸🇦',
    prompt: 'ما هي أهم استراتيجيات تحسين أداء تطبيقات الجوال بنظام أندرويد؟',
  },
];

export const ChatScreen: React.FC<ChatScreenProps> = ({
  initialPrompt,
  initialAgentId = 'safar-travel',
  initialSessionId,
  onOpenImageStudio,
}) => {
  // Load settings
  const userSettings = loadSettings();
  const [appTheme] = useState<AppTheme>(userSettings.theme);
  const [activeLang, setActiveLang] = useState<AppLanguage>(userSettings.language);

  // Sessions management
  const [sessions, setSessions] = useState<ChatSession[]>(() => loadChatSessions());
  const [activeSessionId, setActiveSessionId] = useState<string>(() => {
    if (initialSessionId) return initialSessionId;
    const existing = loadChatSessions();
    return existing.length > 0 ? existing[0].id : 'session-default';
  });

  const activeSession = sessions.find(s => s.id === activeSessionId) || sessions[0] || {
    id: 'session-default',
    title: 'New Expedition',
    agentId: initialAgentId,
    messages: [],
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };

  const [selectedAgentId, setSelectedAgentId] = useState<string>(activeSession.agentId || initialAgentId);
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    if (activeSession.messages && activeSession.messages.length > 0) {
      return activeSession.messages;
    }
    const defaultAgent = SMART_AGENTS.find(a => a.id === initialAgentId) || SMART_AGENTS[0];
    return [
      {
        id: 'msg-welcome',
        role: 'assistant',
        content: `Greetings! I am **${defaultAgent.name}**, your ${defaultAgent.title}.
${defaultAgent.description}

I can converse with you fluently in **English**, **বাংলা (Bengali)**, and **العربية (Arabic)**.

How may I assist your voyage today?`,
        timestamp: Date.now(),
        agentId: defaultAgent.id,
      },
    ];
  });

  const [inputPrompt, setInputPrompt] = useState<string>(initialPrompt || '');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [lastFailedPrompt, setLastFailedPrompt] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [playingVoiceId, setPlayingVoiceId] = useState<string | null>(null);
  const [showAgentPicker, setShowAgentPicker] = useState<boolean>(false);
  const [showSessionsDrawer, setShowSessionsDrawer] = useState<boolean>(false);
  const [drawerSearch, setDrawerSearch] = useState<string>('');

  // Rename session state
  const [isRenamingCurrent, setIsRenamingCurrent] = useState<boolean>(false);
  const [currentRenameTitle, setCurrentRenameTitle] = useState<string>('');

  // Delete session confirmation modal
  const [sessionToDelete, setSessionToDelete] = useState<ChatSession | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const currentAgent = SMART_AGENTS.find(a => a.id === selectedAgentId) || SMART_AGENTS[0];
  const isLight = appTheme === 'light';

  // Keep active session messages synced with state and storage
  useEffect(() => {
    if (activeSession) {
      const updated: ChatSession = {
        ...activeSession,
        agentId: selectedAgentId,
        messages,
        updatedAt: Date.now(),
      };
      updateChatSession(updated);
      setSessions(loadChatSessions());
    }
  }, [messages, selectedAgentId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  useEffect(() => {
    if (initialPrompt && initialPrompt.trim()) {
      handleSendMessage(initialPrompt.trim());
    }
  }, []);

  // Script detection for Arabic / Bengali
  const isArabic = (text: string) => /[\u0600-\u06FF]/.test(text) || activeLang === 'ar';
  const isBengali = (text: string) => /[\u0980-\u09FF]/.test(text) || activeLang === 'bn';

  const handleSendMessage = async (textToSend?: string) => {
    const promptText = (textToSend || inputPrompt).trim();
    if (!promptText || isLoading) return;

    setErrorMessage(null);
    setLastFailedPrompt(null);

    const userMessage: ChatMessage = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: promptText,
      timestamp: Date.now(),
      agentId: selectedAgentId,
    };

    const cleanHistory = messages.filter(m => !m.isError);
    const newHistory = [...cleanHistory, userMessage];
    setMessages(newHistory);
    setInputPrompt('');
    setIsLoading(true);

    // If session is newly created or generic title, derive title from user prompt
    if (activeSession.title === 'New Expedition' || activeSession.title === 'Welcome to Safar AI') {
      const derived = promptText.length > 38 ? promptText.substring(0, 38) + '...' : promptText;
      renameChatSession(activeSession.id, derived);
      setSessions(loadChatSessions());
    }

    try {
      // Pass language context if user has explicit language preference
      let customSystem = currentAgent.systemPrompt;
      if (activeLang === 'bn') {
        customSystem += '\nPlease respond natively in fluent, natural Bengali (বাংলা) with proper grammar and vocabulary.';
      } else if (activeLang === 'ar') {
        customSystem += '\nPlease respond natively in fluent, natural Arabic (العربية) with elegant phrasing and formatting.';
      }

      const res = await fetch(getApiUrl('/api/chat'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newHistory.map(m => ({ role: m.role, content: m.content })),
          agentId: selectedAgentId,
          systemPrompt: customSystem,
          modelOverride: 'gemini-3.8-flash',
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to generate response from Gemini API');
      }

      const assistantMessage: ChatMessage = {
        id: `assistant-${Date.now()}`,
        role: 'assistant',
        content: data.text,
        timestamp: Date.now(),
        agentId: selectedAgentId,
      };

      setMessages(prev => [...prev, assistantMessage]);

      // Check auto-speak setting
      const currentSettings = loadSettings();
      if (currentSettings.autoSpeak) {
        setTimeout(() => {
          playSpeech(assistantMessage.id, assistantMessage.content);
        }, 300);
      }
    } catch (err: any) {
      console.error('Chat error:', err);
      const friendlyError = err?.message || 'Connection or API error encountered. Please check network or API keys.';
      setErrorMessage(friendlyError);
      setLastFailedPrompt(promptText);

      const errMessageObj: ChatMessage = {
        id: `err-${Date.now()}`,
        role: 'assistant',
        content: friendlyError,
        timestamp: Date.now(),
        agentId: selectedAgentId,
        isError: true,
      };
      setMessages(prev => [...prev, errMessageObj]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRetryLast = () => {
    if (lastFailedPrompt) {
      handleSendMessage(lastFailedPrompt);
    } else {
      const lastUserMsg = [...messages].reverse().find(m => m.role === 'user');
      if (lastUserMsg) {
        handleSendMessage(lastUserMsg.content);
      }
    }
  };

  const handleRegenerateFromMessage = (targetMsgId: string) => {
    const msgIndex = messages.findIndex(m => m.id === targetMsgId);
    if (msgIndex <= 0) return;
    
    const prevUserMsg = messages[msgIndex - 1];
    if (prevUserMsg && prevUserMsg.role === 'user') {
      const pruned = messages.slice(0, msgIndex);
      setMessages(pruned);
      handleSendMessage(prevUserMsg.content);
    }
  };

  // Start a brand new chat session
  const handleStartNewChat = () => {
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
      setPlayingVoiceId(null);
    }
    setErrorMessage(null);
    setLastFailedPrompt(null);
    setInputPrompt('');

    const defaultAgent = SMART_AGENTS.find(a => a.id === selectedAgentId) || SMART_AGENTS[0];
    const newSession = createNewChatSession(defaultAgent.id, 'New Expedition');
    
    const initialGreeting: ChatMessage = {
      id: `welcome-${Date.now()}`,
      role: 'assistant',
      content: `**New Expedition Started with ${defaultAgent.name}**.
${defaultAgent.description}

You can converse in **English**, **বাংলা (Bengali)**, or **العربية (Arabic)**. What is your destination or goal?`,
      timestamp: Date.now(),
      agentId: defaultAgent.id,
    };

    newSession.messages = [initialGreeting];
    updateChatSession(newSession);

    const reloaded = loadChatSessions();
    setSessions(reloaded);
    setActiveSessionId(newSession.id);
    setMessages([initialGreeting]);
    setShowSessionsDrawer(false);
  };

  // Switch to an existing session
  const handleSelectSession = (session: ChatSession) => {
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
      setPlayingVoiceId(null);
    }
    setActiveSessionId(session.id);
    setSelectedAgentId(session.agentId || 'safar-travel');
    setMessages(session.messages || []);
    setShowSessionsDrawer(false);
    setErrorMessage(null);
    setLastFailedPrompt(null);
  };

  // Rename active session
  const handleSaveCurrentRename = () => {
    if (!currentRenameTitle.trim()) return;
    const res = renameChatSession(activeSessionId, currentRenameTitle.trim());
    if (res.success) {
      setSessions(res.sessions);
      setIsRenamingCurrent(false);
    }
  };

  // Delete session from drawer
  const handleConfirmDeleteSession = () => {
    if (!sessionToDelete) return;
    const targetId = sessionToDelete.id;
    const res = deleteChatSession(targetId);
    setSessionToDelete(null);
    setSessions(res.sessions);

    if (activeSessionId === targetId) {
      if (res.sessions.length > 0) {
        handleSelectSession(res.sessions[0]);
      } else {
        handleStartNewChat();
      }
    }
  };

  const copyToClipboard = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const playSpeech = (id: string, text: string) => {
    if (!('speechSynthesis' in window)) return;

    if (playingVoiceId === id) {
      window.speechSynthesis.cancel();
      setPlayingVoiceId(null);
      return;
    }

    window.speechSynthesis.cancel();
    const cleanSpeech = text
      .replace(/[*#`_\[\]]/g, '')
      .replace(/\n+/g, ' ');

    const utterance = new SpeechSynthesisUtterance(cleanSpeech);
    const s = loadSettings();
    utterance.rate = s.speechRate;
    utterance.pitch = s.speechPitch;

    if (isArabic(text)) {
      utterance.lang = 'ar-SA';
    } else if (isBengali(text)) {
      utterance.lang = 'bn-BD';
    } else {
      utterance.lang = 'en-US';
    }

    utterance.onend = () => setPlayingVoiceId(null);
    utterance.onerror = () => setPlayingVoiceId(null);

    setPlayingVoiceId(id);
    window.speechSynthesis.speak(utterance);
  };

  const renderFormattedContent = (content: string) => {
    const lines = content.split('\n');
    return lines.map((line, idx) => {
      const lineIsArabic = /[\u0600-\u06FF]/.test(line);
      const lineIsBengali = /[\u0980-\u09FF]/.test(line);
      const textDirClass = lineIsArabic ? 'text-right' : 'text-left';

      if (line.startsWith('### ')) {
        return (
          <h4 key={idx} className={`text-sm font-bold text-orange-400 mt-2 mb-1 ${textDirClass}`}>
            {line.replace('### ', '')}
          </h4>
        );
      }
      if (line.startsWith('## ')) {
        return (
          <h3 key={idx} className={`text-base font-bold mt-2.5 mb-1 ${textDirClass}`}>
            {line.replace('## ', '')}
          </h3>
        );
      }
      if (line.startsWith('# ')) {
        return (
          <h2 key={idx} className={`text-lg font-bold mt-3 mb-1.5 ${textDirClass}`}>
            {line.replace('# ', '')}
          </h2>
        );
      }
      if (line.startsWith('- ') || line.startsWith('* ')) {
        return (
          <div key={idx} className={`flex items-start gap-2 my-1 ml-1 ${lineIsArabic ? 'flex-row-reverse text-right mr-1' : ''}`}>
            <span className="text-orange-500 font-bold mt-1 text-xs">•</span>
            <span className="flex-1">{formatInline(line.substring(2))}</span>
          </div>
        );
      }
      if (/^\d+\.\s/.test(line)) {
        const num = line.match(/^(\d+\.)\s/)?.[1];
        const rest = line.replace(/^\d+\.\s/, '');
        return (
          <div key={idx} className={`flex items-start gap-1.5 my-1 ml-1 ${lineIsArabic ? 'flex-row-reverse text-right mr-1' : ''}`}>
            <span className="font-mono text-xs text-orange-400 font-semibold">{num}</span>
            <span className="flex-1">{formatInline(rest)}</span>
          </div>
        );
      }
      if (line.startsWith('```')) {
        return (
          <div key={idx} dir="ltr" className="my-2 p-2.5 rounded-xl bg-black/75 border border-white/10 font-mono text-xs text-orange-300 overflow-x-auto text-left">
            {line.replace(/```[a-z]*/g, '')}
          </div>
        );
      }
      if (!line.trim()) {
        return <div key={idx} className="h-1.5" />;
      }
      return (
        <p key={idx} className={`my-0.5 leading-relaxed ${textDirClass} ${lineIsBengali ? 'leading-loose font-bengali' : ''} ${lineIsArabic ? 'font-arabic' : ''}`}>
          {formatInline(line)}
        </p>
      );
    });
  };

  const formatInline = (text: string) => {
    const parts = text.split(/(\*\*.*?\*\*|\*.*?\*|`.*?`)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**')) {
        return <strong key={i} className="font-semibold">{part.slice(2, -2)}</strong>;
      }
      if (part.startsWith('*') && part.endsWith('*')) {
        return <em key={i} className="opacity-90">{part.slice(1, -1)}</em>;
      }
      if (part.startsWith('`') && part.endsWith('`')) {
        return <code key={i} className="px-1.5 py-0.5 rounded bg-white/10 text-orange-300 font-mono text-[11px]">{part.slice(1, -1)}</code>;
      }
      return part;
    });
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const filteredStarters = MULTILINGUAL_STARTERS.filter(s => 
    activeLang === 'auto' || s.code === activeLang
  );

  const filteredDrawerSessions = sessions.filter(s => 
    s.title.toLowerCase().includes(drawerSearch.toLowerCase())
  );

  return (
    <div className={`flex-1 flex flex-col overflow-hidden transition-colors ${
      isLight ? 'bg-slate-50 text-slate-900' : 'bg-[#0B0B0C] text-white'
    }`}>
      {/* Top Header Bar */}
      <header className={`px-3 py-2.5 border-b backdrop-blur-md flex items-center justify-between z-20 shrink-0 transition-colors ${
        isLight ? 'bg-white/95 border-slate-200' : 'bg-[#121215]/95 border-white/[0.08]'
      }`}>
        {/* Left: Agent Picker */}
        <div className="relative">
          <button
            onClick={() => setShowAgentPicker(!showAgentPicker)}
            className={`flex items-center gap-2 p-1.5 pr-2.5 rounded-xl border transition-all text-left ${
              isLight 
                ? 'bg-slate-100 border-slate-300 hover:border-orange-500' 
                : 'bg-[#1A1A20] border-white/10 hover:border-orange-500/50'
            }`}
            title="Switch Agent Persona"
          >
            <div className="w-6 h-6 rounded-lg bg-orange-500/20 text-orange-400 flex items-center justify-center font-bold text-xs">
              <Bot size={14} />
            </div>
            <div>
              <div className="flex items-center gap-1">
                <span className="text-xs font-semibold line-clamp-1 max-w-[90px]">{currentAgent.name}</span>
                <ChevronDown size={11} className="text-zinc-400" />
              </div>
              <span className="text-[9px] text-zinc-400 block line-clamp-1">{currentAgent.badge}</span>
            </div>
          </button>

          {/* Agent Picker Dropdown */}
          {showAgentPicker && (
            <div className={`absolute top-full left-0 mt-2 w-64 rounded-2xl border shadow-2xl p-2 z-50 space-y-1 ${
              isLight ? 'bg-white border-slate-300 text-slate-900' : 'bg-[#16161B] border-white/15 text-white'
            }`}>
              <div className="text-[10px] font-mono uppercase text-zinc-400 px-2 py-1 font-semibold">
                Switch Agent Persona
              </div>
              {SMART_AGENTS.map((agent) => (
                <button
                  key={agent.id}
                  onClick={() => {
                    setSelectedAgentId(agent.id);
                    setShowAgentPicker(false);
                    setMessages(prev => [
                      ...prev,
                      {
                        id: `switch-${Date.now()}`,
                        role: 'system',
                        content: `Switched active agent to ${agent.name} (${agent.title}).`,
                        timestamp: Date.now(),
                      }
                    ]);
                  }}
                  className={`w-full p-2 rounded-xl text-left flex items-center gap-2.5 transition-colors text-xs ${
                    selectedAgentId === agent.id
                      ? 'bg-orange-500/20 text-orange-500 font-semibold border border-orange-500/40'
                      : isLight ? 'hover:bg-slate-100' : 'text-zinc-300 hover:bg-white/5'
                  }`}
                >
                  <div className="w-7 h-7 rounded-lg bg-orange-500/10 flex items-center justify-center text-orange-400 shrink-0">
                    <Sparkles size={14} />
                  </div>
                  <div>
                    <div className="font-semibold text-xs">{agent.name}</div>
                    <div className="text-[10px] text-zinc-400 line-clamp-1">{agent.title}</div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Middle: Conversation Title Pill & History Switcher Trigger */}
        <div className="flex-1 mx-2 max-w-[170px] truncate">
          {isRenamingCurrent ? (
            <div className="flex items-center gap-1">
              <input
                type="text"
                value={currentRenameTitle}
                onChange={(e) => setCurrentRenameTitle(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleSaveCurrentRename();
                  if (e.key === 'Escape') setIsRenamingCurrent(false);
                }}
                autoFocus
                className={`w-full rounded px-1.5 py-0.5 text-xs font-semibold focus:outline-none border ${
                  isLight ? 'bg-slate-100 border-orange-400' : 'bg-black border-orange-500 text-white'
                }`}
              />
              <button onClick={handleSaveCurrentRename} className="text-orange-500 p-0.5">
                <Check size={12} />
              </button>
            </div>
          ) : (
            <button
              onClick={() => setShowSessionsDrawer(true)}
              className={`w-full py-1 px-2 rounded-lg text-left truncate flex items-center justify-between gap-1 text-xs font-semibold border transition-all ${
                isLight 
                  ? 'bg-slate-100 border-slate-200 text-slate-700 hover:border-slate-300' 
                  : 'bg-[#18181D] border-white/5 text-zinc-300 hover:border-white/20'
              }`}
              title="Click to switch or manage conversation history"
            >
              <span className="truncate text-[11px]">{activeSession.title}</span>
              <MessageSquare size={11} className="text-orange-400 shrink-0" />
            </button>
          )}
        </div>

        {/* Right: New Chat & Studio */}
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={handleStartNewChat}
            className="px-2.5 py-1.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white text-xs font-semibold shadow-md shadow-orange-500/20 flex items-center gap-1 transition-all active:scale-95"
            title="Start New Chat Session"
          >
            <Plus size={14} />
            <span className="text-[11px] font-bold">New</span>
          </button>

          <button
            onClick={() => onOpenImageStudio()}
            className={`p-1.5 rounded-xl border transition-colors ${
              isLight 
                ? 'bg-slate-100 border-slate-200 text-slate-600 hover:text-orange-500' 
                : 'bg-[#18181D] border-white/10 text-zinc-400 hover:text-orange-400'
            }`}
            title="Open Image Studio"
          >
            <ImageIcon size={16} />
          </button>
        </div>
      </header>

      {/* Multilingual Selector Strip */}
      <div className={`px-4 py-1.5 border-b flex items-center justify-between text-[11px] transition-colors ${
        isLight ? 'bg-slate-100/90 border-slate-200 text-slate-600' : 'bg-[#101013] border-white/[0.04] text-zinc-400'
      }`}>
        <div className="flex items-center gap-1.5">
          <Languages size={13} className="text-orange-400" />
          <span className="font-medium text-[10px] uppercase font-mono">Language:</span>
        </div>
        <div className="flex items-center gap-1">
          {[
            { id: 'auto', label: 'Auto' },
            { id: 'en', label: 'EN' },
            { id: 'bn', label: 'বাংলা' },
            { id: 'ar', label: 'العربية' },
          ].map((lang) => (
            <button
              key={lang.id}
              onClick={() => setActiveLang(lang.id as AppLanguage)}
              className={`px-2 py-0.5 rounded-md text-[10px] font-semibold transition-colors ${
                activeLang === lang.id
                  ? 'bg-orange-500 text-white shadow-sm'
                  : isLight ? 'text-slate-600 hover:text-slate-900' : 'text-zinc-400 hover:text-white'
              }`}
            >
              {lang.label}
            </button>
          ))}
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => {
          if (message.role === 'system') {
            return (
              <div key={message.id} className="text-center my-2">
                <span className={`text-[10px] font-mono px-2.5 py-1 rounded-full border ${
                  isLight ? 'bg-slate-200/60 border-slate-300 text-slate-600' : 'bg-white/5 border-white/10 text-zinc-400'
                }`}>
                  {message.content}
                </span>
              </div>
            );
          }

          const isUser = message.role === 'user';
          const isErrorMsg = message.isError;
          const msgIsArabic = isArabic(message.content);
          const msgIsBengali = isBengali(message.content);

          return (
            <div
              key={message.id}
              className={`flex items-start gap-2.5 ${isUser ? 'justify-end' : 'justify-start'}`}
            >
              {/* Assistant Avatar */}
              {!isUser && (
                <div
                  className={`w-7 h-7 rounded-xl flex items-center justify-center shrink-0 mt-0.5 shadow-sm ${
                    isErrorMsg
                      ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                      : 'bg-orange-500/15 border border-orange-500/30 text-orange-400'
                  }`}
                >
                  {isErrorMsg ? <AlertCircle size={14} /> : <Compass size={14} />}
                </div>
              )}

              {/* Message Bubble */}
              <div
                dir={msgIsArabic ? 'rtl' : 'ltr'}
                className={`max-w-[85%] sm:max-w-[78%] rounded-2xl p-3 text-xs shadow-md transition-all ${
                  isUser
                    ? 'bg-orange-500 text-white rounded-tr-sm shadow-orange-500/15'
                    : isErrorMsg
                    ? 'bg-red-950/40 text-red-200 border border-red-500/30 rounded-tl-sm'
                    : isLight
                    ? 'bg-white text-slate-800 border border-slate-200 rounded-tl-sm shadow-sm'
                    : 'bg-[#15151A] text-zinc-200 border border-white/[0.08] rounded-tl-sm'
                }`}
              >
                {/* Content */}
                <div className={`space-y-1 ${msgIsArabic ? 'font-arabic text-right' : ''} ${msgIsBengali ? 'font-bengali' : ''}`}>
                  {isErrorMsg ? (
                    <div className="space-y-2">
                      <div className="font-semibold text-red-300 flex items-center gap-1.5">
                        <AlertCircle size={13} />
                        <span>Generation Error</span>
                      </div>
                      <p className="text-red-200/90 text-xs">{message.content}</p>
                      <button
                        onClick={handleRetryLast}
                        className="mt-2 px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
                      >
                        <RotateCcw size={12} />
                        <span>Retry Request</span>
                      </button>
                    </div>
                  ) : (
                    renderFormattedContent(message.content)
                  )}
                </div>

                {/* Assistant Footer Toolbar */}
                {!isUser && !isErrorMsg && (
                  <div
                    dir="ltr"
                    className={`mt-2.5 pt-1.5 border-t flex items-center justify-between text-[10px] ${
                      isLight ? 'border-slate-100 text-slate-400' : 'border-white/5 text-zinc-400'
                    }`}
                  >
                    <span className="font-mono text-[9px]">gemini-3.8-flash</span>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleRegenerateFromMessage(message.id)}
                        className={`p-1 rounded hover:text-orange-400 transition-colors ${
                          isLight ? 'hover:bg-slate-100' : 'hover:bg-white/10'
                        }`}
                        title="Regenerate this response"
                      >
                        <RotateCcw size={12} />
                      </button>
                      <button
                        onClick={() => playSpeech(message.id, message.content)}
                        className={`p-1 rounded hover:text-orange-400 transition-colors ${
                          isLight ? 'hover:bg-slate-100' : 'hover:bg-white/10'
                        }`}
                        title="Read aloud"
                      >
                        {playingVoiceId === message.id ? (
                          <VolumeX size={12} className="text-orange-400 animate-pulse" />
                        ) : (
                          <Volume2 size={12} />
                        )}
                      </button>
                      <button
                        onClick={() => copyToClipboard(message.id, message.content)}
                        className={`p-1 rounded transition-colors ${
                          isLight ? 'hover:bg-slate-100 text-slate-500 hover:text-slate-900' : 'hover:bg-white/10 text-zinc-400 hover:text-white'
                        }`}
                        title="Copy content"
                      >
                        {copiedId === message.id ? (
                          <Check size={12} className="text-emerald-400" />
                        ) : (
                          <Copy size={12} />
                        )}
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* User Avatar */}
              {isUser && (
                <div className={`w-7 h-7 rounded-xl flex items-center justify-center shrink-0 mt-0.5 ${
                  isLight ? 'bg-slate-200 text-slate-700' : 'bg-zinc-800 text-zinc-300'
                }`}>
                  <User size={14} />
                </div>
              )}
            </div>
          );
        })}

        {/* Real Loading Indicator */}
        {isLoading && (
          <div className="flex items-start gap-2.5">
            <div className="w-7 h-7 rounded-xl bg-orange-500/20 text-orange-400 flex items-center justify-center shrink-0">
              <Compass size={14} className="animate-spin" />
            </div>
            <div className={`border rounded-2xl p-3 text-xs flex items-center gap-2 shadow-sm ${
              isLight ? 'bg-white border-slate-200 text-slate-700' : 'bg-[#15151A] border-white/[0.08] text-zinc-300'
            }`}>
              <span className="w-2 h-2 rounded-full bg-orange-500 animate-ping"></span>
              <span className="font-mono text-[11px] text-orange-400 font-medium">
                Safar is reasoning with Gemini 3.8 Flash...
              </span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Multilingual Starter Prompts */}
      {messages.length <= 2 && (
        <div className={`px-4 py-1.5 flex items-center gap-1.5 overflow-x-auto no-scrollbar shrink-0 border-t ${
          isLight ? 'bg-slate-100/60 border-slate-200' : 'bg-[#0E0E11] border-white/[0.04]'
        }`}>
          {filteredStarters.map((starter, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(starter.prompt)}
              className={`text-[11px] whitespace-nowrap shrink-0 px-2.5 py-1 rounded-xl border transition-colors flex items-center gap-1.5 ${
                isLight 
                  ? 'bg-white border-slate-200 text-slate-700 hover:border-orange-500' 
                  : 'bg-[#15151A] border-white/10 text-zinc-300 hover:text-white hover:border-orange-500/40'
              }`}
            >
              <span>{starter.flag}</span>
              <span className="line-clamp-1 max-w-[200px]">{starter.prompt}</span>
            </button>
          ))}
        </div>
      )}

      {/* Bottom Chat Input Form */}
      <div className={`p-3 border-t transition-colors ${
        isLight ? 'bg-white border-slate-200' : 'bg-[#0B0B0C] border-white/[0.08]'
      }`}>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className={`relative flex items-center border rounded-2xl p-1.5 pl-3 focus-within:border-orange-500 focus-within:ring-2 focus-within:ring-orange-500/20 transition-all shadow-md ${
            isLight ? 'bg-slate-50 border-slate-300' : 'bg-[#15151A] border-white/12'
          }`}
        >
          <textarea
            ref={inputRef}
            rows={1}
            dir={activeLang === 'ar' ? 'rtl' : 'ltr'}
            value={inputPrompt}
            onChange={(e) => setInputPrompt(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={
              activeLang === 'bn' 
                ? 'সফর এআই-কে জিজ্ঞাসা করুন (বাংলা)...' 
                : activeLang === 'ar' 
                ? 'اسأل سفر بالعربية...' 
                : 'Ask Safar in English, বাংলা, or العربية...'
            }
            className={`flex-1 bg-transparent text-xs focus:outline-none min-w-0 pr-2 resize-none max-h-24 py-1 ${
              isLight ? 'text-slate-900 placeholder-slate-400' : 'text-white placeholder-zinc-500'
            }`}
          />

          <button
            type="submit"
            disabled={!inputPrompt.trim() || isLoading}
            className={`w-8 h-8 rounded-xl flex items-center justify-center transition-all shrink-0 ${
              inputPrompt.trim() && !isLoading
                ? 'bg-orange-500 text-white shadow-md shadow-orange-500/30 hover:bg-orange-600 active:scale-95'
                : isLight ? 'bg-slate-200 text-slate-400 cursor-not-allowed' : 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
            }`}
            title="Send prompt (Enter)"
          >
            {isLoading ? (
              <Compass size={16} className="animate-spin text-zinc-400" />
            ) : (
              <ArrowUp size={16} strokeWidth={2.4} />
            )}
          </button>
        </form>

        <div className={`mt-1.5 flex items-center justify-between text-[10px] px-1 ${
          isLight ? 'text-slate-400' : 'text-zinc-500'
        }`}>
          <span>Press Enter to send, Shift+Enter for new line</span>
          <span className="font-mono">gemini-3.8-flash</span>
        </div>
      </div>

      {/* ----------------- Conversations Switcher Drawer ----------------- */}
      {showSessionsDrawer && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex justify-end">
          <div className={`w-full max-w-xs h-full flex flex-col p-4 shadow-2xl animate-slideIn ${
            isLight ? 'bg-white text-slate-900' : 'bg-[#15151B] text-white'
          }`}>
            {/* Drawer Header */}
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-2">
                <MessageSquare size={16} className="text-orange-400" />
                <h3 className="text-sm font-bold">Conversations ({sessions.length})</h3>
              </div>
              <button
                onClick={() => setShowSessionsDrawer(false)}
                className="p-1 rounded-lg text-zinc-400 hover:text-white"
              >
                <X size={16} />
              </button>
            </div>

            {/* Quick Actions */}
            <div className="py-2.5 flex items-center gap-2">
              <button
                onClick={handleStartNewChat}
                className="flex-1 py-2 px-3 rounded-xl bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-md shadow-orange-500/20"
              >
                <Plus size={14} />
                <span>New Chat</span>
              </button>
              <button
                onClick={() => {
                  setCurrentRenameTitle(activeSession.title);
                  setIsRenamingCurrent(true);
                  setShowSessionsDrawer(false);
                }}
                className={`py-2 px-2.5 rounded-xl border text-xs font-medium flex items-center gap-1 ${
                  isLight ? 'bg-slate-100 border-slate-300' : 'bg-[#1D1D24] border-white/10 text-zinc-300'
                }`}
                title="Rename current chat"
              >
                <Edit3 size={13} />
                <span className="text-[11px]">Rename</span>
              </button>
            </div>

            {/* Search sessions */}
            <div className="relative mb-2">
              <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-zinc-400" />
              <input
                type="text"
                value={drawerSearch}
                onChange={(e) => setDrawerSearch(e.target.value)}
                placeholder="Search past chats..."
                className={`w-full pl-8 pr-2.5 py-1.5 rounded-xl text-xs focus:outline-none border ${
                  isLight ? 'bg-slate-50 border-slate-200' : 'bg-[#101014] border-white/10 text-white'
                }`}
              />
            </div>

            {/* Sessions List */}
            <div className="flex-1 overflow-y-auto space-y-1.5 pr-1">
              {filteredDrawerSessions.map((s) => {
                const isCurrent = s.id === activeSessionId;
                const agent = SMART_AGENTS.find(a => a.id === s.agentId) || SMART_AGENTS[0];
                return (
                  <div
                    key={s.id}
                    onClick={() => handleSelectSession(s)}
                    className={`p-2.5 rounded-xl border cursor-pointer transition-all flex items-center justify-between group ${
                      isCurrent
                        ? 'bg-orange-500/15 border-orange-500 text-white font-semibold'
                        : isLight
                        ? 'bg-slate-50 border-slate-200 hover:border-slate-300 text-slate-700'
                        : 'bg-[#181820] border-white/5 hover:border-white/15 text-zinc-300'
                    }`}
                  >
                    <div className="flex-1 min-w-0 pr-2">
                      <div className="text-xs truncate font-medium">{s.title}</div>
                      <div className="text-[10px] text-zinc-500 flex items-center gap-1 mt-0.5">
                        <span className="text-orange-400">{agent.name}</span>
                        <span>•</span>
                        <span>{s.messages.length} msgs</span>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSessionToDelete(s);
                      }}
                      className="p-1.5 rounded text-zinc-500 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"
                      title="Delete conversation"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ----------------- Delete Session Confirmation Modal ----------------- */}
      {sessionToDelete && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className={`w-full max-w-sm rounded-2xl border p-4.5 space-y-3.5 shadow-2xl ${
            isLight ? 'bg-white border-slate-300 text-slate-900' : 'bg-[#16161C] border-white/15 text-white'
          }`}>
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-xl bg-red-500/20 text-red-400 flex items-center justify-center shrink-0">
                <Trash2 size={18} />
              </div>
              <div>
                <h3 className="text-sm font-bold">Delete Conversation?</h3>
                <p className={`text-xs mt-1 leading-relaxed ${isLight ? 'text-slate-600' : 'text-zinc-400'}`}>
                  Delete <strong className="text-orange-400">"{sessionToDelete.title}"</strong>? This will permanently remove its message history.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setSessionToDelete(null)}
                className={`flex-1 py-2 rounded-xl text-xs font-semibold border transition-all ${
                  isLight ? 'bg-slate-100 border-slate-300 text-slate-700' : 'bg-white/5 border-white/10 text-zinc-300'
                }`}
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDeleteSession}
                className="flex-1 py-2 rounded-xl text-xs font-bold bg-red-500 hover:bg-red-600 text-white shadow-md shadow-red-500/25 transition-all flex items-center justify-center gap-1"
              >
                <Trash2 size={13} />
                <span>Delete</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
