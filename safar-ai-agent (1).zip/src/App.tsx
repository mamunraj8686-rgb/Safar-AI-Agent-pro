/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { NavigationTab, WorkflowPresetId, AppTheme, AppLanguage } from './types';
import { AndroidFrame } from './components/AndroidFrame';
import { BottomNavBar } from './components/BottomNavBar';
import { HomeScreen } from './components/HomeScreen';
import { ChatScreen } from './components/ChatScreen';
import { LiveVoiceScreen } from './components/LiveVoiceScreen';
import { SmartAgentsScreen } from './components/SmartAgentsScreen';
import { ImageStudioScreen } from './components/ImageStudioScreen';
import { HistoryScreen } from './components/HistoryScreen';
import { SettingsScreen } from './components/SettingsScreen';
import { SafarFlowScreen } from './components/SafarFlowScreen';
import { loadSettings, saveSettings } from './services/storageService';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavigationTab>('home');
  const [chatInitialPrompt, setChatInitialPrompt] = useState<string>('');
  const [chatInitialAgentId, setChatInitialAgentId] = useState<string>('safar-travel');
  const [chatInitialSessionId, setChatInitialSessionId] = useState<string | undefined>(undefined);
  const [studioInitialPrompt, setStudioInitialPrompt] = useState<string>('');
  const [flowInitialPresetId, setFlowInitialPresetId] = useState<WorkflowPresetId>('business_writing');

  // Global settings state
  const [theme, setTheme] = useState<AppTheme>(() => loadSettings().theme);
  const [language, setLanguage] = useState<AppLanguage>(() => loadSettings().language);

  // Sync theme class to document body
  useEffect(() => {
    if (typeof document !== 'undefined') {
      if (theme === 'light') {
        document.body.classList.add('theme-light');
      } else {
        document.body.classList.remove('theme-light');
      }
    }
  }, [theme]);

  const handleToggleTheme = () => {
    const nextTheme: AppTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(nextTheme);
    const cur = loadSettings();
    saveSettings({ ...cur, theme: nextTheme });
  };

  const handleStartChatWithPrompt = (prompt: string, agentId?: string) => {
    setChatInitialPrompt(prompt);
    setChatInitialSessionId(undefined);
    if (agentId) {
      setChatInitialAgentId(agentId);
    }
    setActiveTab('chat');
  };

  const handleOpenVoice = () => {
    setActiveTab('voice');
  };

  const handleOpenImageStudio = (prompt?: string) => {
    if (prompt) {
      setStudioInitialPrompt(prompt);
    }
    setActiveTab('images');
  };

  const handleOpenSessionFromHistory = (sessionId: string, tab: NavigationTab, prompt?: string) => {
    if (tab === 'images') {
      if (prompt) setStudioInitialPrompt(prompt);
      setActiveTab('images');
    } else {
      setChatInitialSessionId(sessionId);
      if (prompt) setChatInitialPrompt(prompt);
      setActiveTab('chat');
    }
  };

  const handleStartNewChatFromHistory = () => {
    setChatInitialSessionId(undefined);
    setChatInitialPrompt('');
    setActiveTab('chat');
  };

  return (
    <AndroidFrame 
      activeTab={activeTab}
      theme={theme}
      language={language}
      onToggleTheme={handleToggleTheme}
    >
      <div className="flex-1 flex flex-col overflow-hidden relative">
        {/* Render Tab View */}
        {activeTab === 'home' && (
          <HomeScreen
            onNavigate={(tab) => setActiveTab(tab)}
            onStartChatWithPrompt={handleStartChatWithPrompt}
            onOpenVoice={handleOpenVoice}
            onOpenImageStudio={handleOpenImageStudio}
            onOpenSettings={() => setActiveTab('settings')}
            onOpenFlow={(presetId) => {
              if (presetId) setFlowInitialPresetId(presetId);
              setActiveTab('flow');
            }}
          />
        )}

        {activeTab === 'flow' && (
          <SafarFlowScreen
            initialPresetId={flowInitialPresetId}
            onSendToChat={(text) => {
              setChatInitialPrompt(text);
              setChatInitialSessionId(undefined);
              setActiveTab('chat');
            }}
            onBackToHome={() => setActiveTab('home')}
          />
        )}

        {activeTab === 'chat' && (
          <ChatScreen
            key={chatInitialSessionId || 'default-chat'}
            initialPrompt={chatInitialPrompt}
            initialAgentId={chatInitialAgentId}
            initialSessionId={chatInitialSessionId}
            onOpenImageStudio={handleOpenImageStudio}
          />
        )}

        {activeTab === 'voice' && (
          <LiveVoiceScreen
            onSwitchToChat={(prompt) => {
              if (prompt) setChatInitialPrompt(prompt);
              setChatInitialSessionId(undefined);
              setActiveTab('chat');
            }}
          />
        )}

        {activeTab === 'agents' && (
          <SmartAgentsScreen
            onSelectAgent={(agentId, prompt) => {
              setChatInitialAgentId(agentId);
              setChatInitialSessionId(undefined);
              if (prompt) setChatInitialPrompt(prompt);
              setActiveTab('chat');
            }}
            onOpenStudio={handleOpenImageStudio}
            onSendToChat={(text) => {
              setChatInitialPrompt(text);
              setChatInitialSessionId(undefined);
              setActiveTab('chat');
            }}
          />
        )}

        {activeTab === 'images' && (
          <ImageStudioScreen
            initialPrompt={studioInitialPrompt}
            onSendToChat={(imageUrl, prompt) => {
              setChatInitialPrompt(`I generated this image: "${prompt}". What do you think of this concept?`);
              setChatInitialSessionId(undefined);
              setActiveTab('chat');
            }}
            onBackToHome={() => setActiveTab('home')}
          />
        )}

        {activeTab === 'history' && (
          <HistoryScreen
            onOpenSession={handleOpenSessionFromHistory}
            onStartNewChat={handleStartNewChatFromHistory}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsScreen
            onBackToHome={() => setActiveTab('home')}
            onThemeChange={(newTheme) => setTheme(newTheme)}
            onLanguageChange={(newLang) => setLanguage(newLang)}
          />
        )}
      </div>

      {/* Android Bottom Navigation Dock */}
      <BottomNavBar
        currentTab={activeTab}
        theme={theme}
        onSelectTab={(tab) => setActiveTab(tab)}
        onOpenSettings={() => setActiveTab('settings')}
      />
    </AndroidFrame>
  );
}
